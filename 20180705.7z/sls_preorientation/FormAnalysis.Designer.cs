﻿namespace PreAddTech
{
    partial class FormAnalysis
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea11 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea12 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAnalysis));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            this.contextMenuStripHistogram = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItemTypeDiagram = new System.Windows.Forms.ToolStripComboBox();
            this.ToolStripMenuItemColorSсhemе = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.исходныеДанныепоказатьскрытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialogU = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialogU = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.checkBoxPreview = new System.Windows.Forms.CheckBox();
            this.checkBoxOneOrAll = new System.Windows.Forms.CheckBox();
            this.numericUpDownLayerInt = new System.Windows.Forms.NumericUpDown();
            this.labelRGB1 = new System.Windows.Forms.Label();
            this.numericUpDownIntVisual = new System.Windows.Forms.NumericUpDown();
            this.textBoxRazmahPar = new System.Windows.Forms.TextBox();
            this.textBoxSizeInt = new System.Windows.Forms.TextBox();
            this.numericUpDownR1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownG1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownB1 = new System.Windows.Forms.NumericUpDown();
            this.labelRGB2 = new System.Windows.Forms.Label();
            this.numericUpDownR2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownG2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownB2 = new System.Windows.Forms.NumericUpDown();
            this.labelStep = new System.Windows.Forms.Label();
            this.numericUpDownStep = new System.Windows.Forms.NumericUpDown();
            this.checkBoxGist = new System.Windows.Forms.CheckBox();
            this.buttonXls = new System.Windows.Forms.Button();
            this.label1var = new System.Windows.Forms.Label();
            this.label2var = new System.Windows.Forms.Label();
            this.numericUpDownIntOrientation = new System.Windows.Forms.NumericUpDown();
            this.textBoxRangeOrient = new System.Windows.Forms.TextBox();
            this.textBoxIntOrient = new System.Windows.Forms.TextBox();
            this.label3var = new System.Windows.Forms.Label();
            this.numericUpDown1varR = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1varG = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1varB = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varR = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varG = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varB = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varR = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varG = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varB = new System.Windows.Forms.NumericUpDown();
            this.label1varRangeAngle = new System.Windows.Forms.Label();
            this.label2varRangeAngle = new System.Windows.Forms.Label();
            this.label3varRangeAngle = new System.Windows.Forms.Label();
            this.checkBox1var = new System.Windows.Forms.CheckBox();
            this.checkBox2var = new System.Windows.Forms.CheckBox();
            this.checkBox3var = new System.Windows.Forms.CheckBox();
            this.numericUpDown1varAngleMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1varAngleMax = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varAngleMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varAngleMax = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varAngleMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varAngleMax = new System.Windows.Forms.NumericUpDown();
            this.label1varRelS = new System.Windows.Forms.Label();
            this.label2varRelS = new System.Windows.Forms.Label();
            this.label3varRelS = new System.Windows.Forms.Label();
            this.numericUpDown1varRelSMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1varRelSMax = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varRelSMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2varRelSMax = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varRelSMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3varRelSMax = new System.Windows.Forms.NumericUpDown();
            this.labelRangeH = new System.Windows.Forms.Label();
            this.numericUpDownHMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownHMax = new System.Windows.Forms.NumericUpDown();
            this.checkBox1varAddH = new System.Windows.Forms.CheckBox();
            this.checkBox2varAddH = new System.Windows.Forms.CheckBox();
            this.checkBox3varAddH = new System.Windows.Forms.CheckBox();
            this.checkBoxAndOrAddCondition = new System.Windows.Forms.CheckBox();
            this.buttonXlsOrient = new System.Windows.Forms.Button();
            this.checkBoxNumInterval = new System.Windows.Forms.CheckBox();
            this.numericUpDownNumIntX = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNumIntY = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNumIntZ = new System.Windows.Forms.NumericUpDown();
            this.textBoxMin = new System.Windows.Forms.TextBox();
            this.textBoxInterval = new System.Windows.Forms.TextBox();
            this.textBoxMax = new System.Windows.Forms.TextBox();
            this.chartHistogramVoxelYRelation = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelZRelation = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelXRelation = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelXYZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelXYZRelative = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelY = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartHistogramVoxelX = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTotalVoxRez = new System.Windows.Forms.TextBox();
            this.checkBoxVox = new System.Windows.Forms.CheckBox();
            this.numericUpDownVoxX = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownVoxY = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownVoxZ = new System.Windows.Forms.NumericUpDown();
            this.textBoxTotalVox = new System.Windows.Forms.TextBox();
            this.checkBoxAbsOrRel = new System.Windows.Forms.CheckBox();
            this.labelCountInt = new System.Windows.Forms.Label();
            this.numericUpDownCountFractalAnalysis = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCurentFractalAnalysis = new System.Windows.Forms.NumericUpDown();
            this.labelCountContour = new System.Windows.Forms.Label();
            this.numericUpDownRatioRtoL = new System.Windows.Forms.NumericUpDown();
            this.checkBoxVisualAnalysis = new System.Windows.Forms.CheckBox();
            this.checkBoxMethod = new System.Windows.Forms.CheckBox();
            this.contextMenuStripdataGrid = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemShow = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemReduce = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialogSelect = new System.Windows.Forms.ColorDialog();
            this.saveFileDialogPly = new System.Windows.Forms.SaveFileDialog();
            this.AnalLayer = new System.Windows.Forms.TabPage();
            this.dataGridViewSetLayer = new System.Windows.Forms.DataGridView();
            this.checkBoxFractalAnalysis = new System.Windows.Forms.CheckBox();
            this.statusStripLayerAnalysis = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarLayerAnalysis = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelLayerAnalysis = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelReviewContourSection = new System.Windows.Forms.Panel();
            this.toolStripLayerAnalysis = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonLayerCreate = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator55 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxLayerAnalysis = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator56 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxMinStep = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator57 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxMaxStep = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator38 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxError = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator70 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxLimitF = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripComboBoxTypeTrim = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator61 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator67 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonColorLine = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator68 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxScale = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator58 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator59 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLayerAnalysis = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator60 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator69 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLayerSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator64 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxCountColumnForSave = new System.Windows.Forms.ToolStripComboBox();
            this.AnalColorVisual = new System.Windows.Forms.TabPage();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarVisualization = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelColorVisual = new System.Windows.Forms.ToolStripStatusLabel();
            this.label40 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridViewIntervals = new System.Windows.Forms.DataGridView();
            this.Begin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.G = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.B = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.H = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.S = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.V = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SetColor = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label52 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.dataGridViewVariantsVisualization = new System.Windows.Forms.DataGridView();
            this.NomVar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parametr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ButtonOpenFile = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ReviewGist = new System.Windows.Forms.DataGridViewButtonColumn();
            this.R1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.G1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.B1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.G2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.B2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColIntervals = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Range = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dispersion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sigma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mean = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kasim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Keks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Meana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Moda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mediana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStripColorVisual = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonСalculate = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxStrategicVisual = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonColorVisual = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSavePLY = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxSelestFormatFile = new System.Windows.Forms.ToolStripComboBox();
            this.analOrient = new System.Windows.Forms.TabPage();
            this.statusStrip3 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarOrientation = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelInphoOrientation = new System.Windows.Forms.ToolStripStatusLabel();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.labelRelSMax = new System.Windows.Forms.Label();
            this.labelRelSMin = new System.Windows.Forms.Label();
            this.labelAngleMax = new System.Windows.Forms.Label();
            this.labelAngleMin = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelG = new System.Windows.Forms.Label();
            this.labelR = new System.Windows.Forms.Label();
            this.labelCountIntOrientation = new System.Windows.Forms.Label();
            this.dataGridViewOrientation = new System.Windows.Forms.DataGridView();
            this.VariantOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnHeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reaserch1varRelS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reaserch2varRelS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reaserch3varRelS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReviewGistOrient = new System.Windows.Forms.DataGridViewButtonColumn();
            this.CountIntOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinIntervalOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxIntervalOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RangeOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KaOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KeOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KvOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MeanaOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModaOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MedianaOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.XOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YOrient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Save = new System.Windows.Forms.DataGridViewButtonColumn();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonCalculateOrientation = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxVarCount = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripComboBoxDX = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripComboBoxDY = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator32 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonColorAnalysis = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonExpression = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator39 = new System.Windows.Forms.ToolStripSeparator();
            this.AnalLocation = new System.Windows.Forms.TabPage();
            this.pictureBoxTop = new System.Windows.Forms.PictureBox();
            this.pictureBoxFront = new System.Windows.Forms.PictureBox();
            this.pictureBoxRight = new System.Windows.Forms.PictureBox();
            this.labelXmin = new System.Windows.Forms.Label();
            this.labelYmin = new System.Windows.Forms.Label();
            this.labelZmin = new System.Windows.Forms.Label();
            this.labelYmax = new System.Windows.Forms.Label();
            this.labelXmax = new System.Windows.Forms.Label();
            this.labelZmax = new System.Windows.Forms.Label();
            this.labelX2 = new System.Windows.Forms.Label();
            this.labelY2 = new System.Windows.Forms.Label();
            this.labelX1 = new System.Windows.Forms.Label();
            this.labelY1 = new System.Windows.Forms.Label();
            this.labelZ2 = new System.Windows.Forms.Label();
            this.richTextBoxLocationInfo = new System.Windows.Forms.RichTextBox();
            this.statusStrip5 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarLocation = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelLocation = new System.Windows.Forms.ToolStripStatusLabel();
            this.labelZ1 = new System.Windows.Forms.Label();
            this.toolStripLocation = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonPack = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator42 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator43 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxListModels = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripButtonDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator44 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator45 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLocalAnalysis = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator46 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator47 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLocalSettings = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator48 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator49 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBoxStep = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator51 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator50 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRGB1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator54 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRGB2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator52 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator53 = new System.Windows.Forms.ToolStripSeparator();
            this.AnalVox = new System.Windows.Forms.TabPage();
            this.textBoxDataHistogram = new System.Windows.Forms.TextBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonStatAnal = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBoxShowAnalysis = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonShowStatisticalDataX = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonShowStatisticalDataY = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonShowStatisticalDataZ = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonShowHistogramXYZ = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator66 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonShowHistogram3D = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonAbsolute = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator65 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRelative = new System.Windows.Forms.ToolStripButton();
            this.label29 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxDispersion = new System.Windows.Forms.TextBox();
            this.textBoxStandardDeviation = new System.Windows.Forms.TextBox();
            this.textBoxAverage = new System.Windows.Forms.TextBox();
            this.textBoxMean = new System.Windows.Forms.TextBox();
            this.textBoxSkewness = new System.Windows.Forms.TextBox();
            this.textBoxMedian = new System.Windows.Forms.TextBox();
            this.textBoxMode = new System.Windows.Forms.TextBox();
            this.textBoxCoefficientOfVariation = new System.Windows.Forms.TextBox();
            this.textBoxCoefficientOfExcess = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxSizeY2 = new System.Windows.Forms.TextBox();
            this.textBoxSizeX2 = new System.Windows.Forms.TextBox();
            this.textBoxSizeZ2 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxSizeIntervalsZ = new System.Windows.Forms.TextBox();
            this.textBoxSizeIntervalsY = new System.Windows.Forms.TextBox();
            this.textBoxSizeIntervalsX = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.Vox_model = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxSizeZ = new System.Windows.Forms.TextBox();
            this.textBoxSizeY = new System.Windows.Forms.TextBox();
            this.textBoxSizeX = new System.Windows.Forms.TextBox();
            this.textBoxMaxZ = new System.Windows.Forms.TextBox();
            this.textBoxMaxY = new System.Windows.Forms.TextBox();
            this.textBoxMaxX = new System.Windows.Forms.TextBox();
            this.textBoxMinY = new System.Windows.Forms.TextBox();
            this.textBoxMinX = new System.Windows.Forms.TextBox();
            this.textBoxMinZ = new System.Windows.Forms.TextBox();
            this.richTextBoxInfo = new System.Windows.Forms.RichTextBox();
            this.statusStrip_CreateVox = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarCreateVoxel = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabelCreateVoxel = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Calculate_size = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCreateVoxModel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonASC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonVerification = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSaveVoxModel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator41 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonOpenVoxModel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator40 = new System.Windows.Forms.ToolStripSeparator();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBoxErrorZ = new System.Windows.Forms.TextBox();
            this.textBoxErrorY = new System.Windows.Forms.TextBox();
            this.textBoxErrorX = new System.Windows.Forms.TextBox();
            this.textBoxVoxSizeZ = new System.Windows.Forms.TextBox();
            this.textBoxVoxSizeY = new System.Windows.Forms.TextBox();
            this.textBoxVoxSizeX = new System.Windows.Forms.TextBox();
            this.textBoxVoxMaxZ = new System.Windows.Forms.TextBox();
            this.textBoxVoxMaxY = new System.Windows.Forms.TextBox();
            this.textBoxVoxMaxX = new System.Windows.Forms.TextBox();
            this.textBoxVoxMinY = new System.Windows.Forms.TextBox();
            this.textBoxVoxMinX = new System.Windows.Forms.TextBox();
            this.textBoxVoxMinZ = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ImportSTL = new System.Windows.Forms.TabPage();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarCreateTable = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBox3 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.OpenSTL = new System.Windows.Forms.TabPage();
            this.richTextBox_review = new System.Windows.Forms.RichTextBox();
            this.toolStrip_OpenSTL = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator62 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxFileName = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBoxVol = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBox2 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.блокнотToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.magicsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator63 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip_OpenSTL = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBarOpenSTL = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel_time_loud = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControlCreationVoxelModel = new System.Windows.Forms.TabControl();
            this.NumLayer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HeightLayer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HeightPlaсement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.P = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ssection = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.centroidOfArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fractal_Size_Scale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fractal_Size_Square = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nz = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Aadjacent = new System.Windows.Forms.DataGridViewButtonColumn();
            this.NzMinInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzMaxInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzRange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzDispersion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzSigma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzMean = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzKasim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzKeks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzKv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzMeana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzModa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NzMediana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AMinInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AMaxInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ARange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ADispersion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ASigma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AMean = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AKasim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AKeks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AKv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AMeana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AModa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AMediana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMinInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMaxInterval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ERange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EDispersion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESigma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMean = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EKasim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EKeks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EKv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMeana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EModa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMediana = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkBoxAnalysisErrorForm = new System.Windows.Forms.CheckBox();
            this.contextMenuStripHistogram.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLayerInt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntVisual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownG1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownG2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownStep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntOrientation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varAngleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varAngleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varAngleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varAngleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varAngleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varAngleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varRelSMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varRelSMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varRelSMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varRelSMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varRelSMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varRelSMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelYRelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelZRelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXRelation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXYZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXYZRelative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountFractalAnalysis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCurentFractalAnalysis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRatioRtoL)).BeginInit();
            this.contextMenuStripdataGrid.SuspendLayout();
            this.AnalLayer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSetLayer)).BeginInit();
            this.statusStripLayerAnalysis.SuspendLayout();
            this.panelReviewContourSection.SuspendLayout();
            this.toolStripLayerAnalysis.SuspendLayout();
            this.AnalColorVisual.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIntervals)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVariantsVisualization)).BeginInit();
            this.toolStripColorVisual.SuspendLayout();
            this.analOrient.SuspendLayout();
            this.statusStrip3.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrientation)).BeginInit();
            this.toolStrip3.SuspendLayout();
            this.AnalLocation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFront)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRight)).BeginInit();
            this.statusStrip5.SuspendLayout();
            this.toolStripLocation.SuspendLayout();
            this.AnalVox.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Vox_model.SuspendLayout();
            this.statusStrip_CreateVox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.ImportSTL.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.OpenSTL.SuspendLayout();
            this.toolStrip_OpenSTL.SuspendLayout();
            this.statusStrip_OpenSTL.SuspendLayout();
            this.tabControlCreationVoxelModel.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStripHistogram
            // 
            this.contextMenuStripHistogram.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStripHistogram.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemTypeDiagram,
            this.ToolStripMenuItemColorSсhemе,
            this.toolStripMenuItem5,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.исходныеДанныепоказатьскрытьToolStripMenuItem});
            this.contextMenuStripHistogram.Name = "contextMenuStripHistogram";
            this.contextMenuStripHistogram.ShowImageMargin = false;
            this.contextMenuStripHistogram.Size = new System.Drawing.Size(403, 188);
            // 
            // ToolStripMenuItemTypeDiagram
            // 
            this.ToolStripMenuItemTypeDiagram.DropDownWidth = 300;
            this.ToolStripMenuItemTypeDiagram.Name = "ToolStripMenuItemTypeDiagram";
            this.ToolStripMenuItemTypeDiagram.Size = new System.Drawing.Size(300, 28);
            this.ToolStripMenuItemTypeDiagram.Text = "Тип диаграммы";
            this.ToolStripMenuItemTypeDiagram.Click += new System.EventHandler(this.ToolStripMenuItemTypeDiagram_Click);
            this.ToolStripMenuItemTypeDiagram.TextChanged += new System.EventHandler(this.ToolStripMenuItemTypeDiagram_TextChanged);
            // 
            // ToolStripMenuItemColorSсhemе
            // 
            this.ToolStripMenuItemColorSсhemе.DropDownWidth = 300;
            this.ToolStripMenuItemColorSсhemе.MaxDropDownItems = 20;
            this.ToolStripMenuItemColorSсhemе.Name = "ToolStripMenuItemColorSсhemе";
            this.ToolStripMenuItemColorSсhemе.Size = new System.Drawing.Size(300, 28);
            this.ToolStripMenuItemColorSсhemе.Text = "Цветовая палитра гистограммы";
            this.ToolStripMenuItemColorSсhemе.Click += new System.EventHandler(this.ColorHistogramToolStripMenuItem_Click);
            this.ToolStripMenuItemColorSсhemе.TextChanged += new System.EventHandler(this.ToolStripMenuItemColorSсhemе_TextChanged);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.ShowShortcutKeys = false;
            this.toolStripMenuItem5.Size = new System.Drawing.Size(402, 24);
            this.toolStripMenuItem5.Text = "Растянуть/Исходный размер гистограммы";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.ToolStripMenuItem5_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.ShowShortcutKeys = false;
            this.toolStripMenuItem2.Size = new System.Drawing.Size(402, 24);
            this.toolStripMenuItem2.Text = "Скрыть гистограмму по оси X для XYZ";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.ToolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.ShowShortcutKeys = false;
            this.toolStripMenuItem3.Size = new System.Drawing.Size(402, 24);
            this.toolStripMenuItem3.Text = "Скрыть гистограмму по оси Y для XYZ";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.ToolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.ShowShortcutKeys = false;
            this.toolStripMenuItem4.Size = new System.Drawing.Size(402, 24);
            this.toolStripMenuItem4.Text = "Скрыть гистограмму по оси Z для XYZ";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.ToolStripMenuItem4_Click);
            // 
            // исходныеДанныепоказатьскрытьToolStripMenuItem
            // 
            this.исходныеДанныепоказатьскрытьToolStripMenuItem.Name = "исходныеДанныепоказатьскрытьToolStripMenuItem";
            this.исходныеДанныепоказатьскрытьToolStripMenuItem.ShowShortcutKeys = false;
            this.исходныеДанныепоказатьскрытьToolStripMenuItem.Size = new System.Drawing.Size(402, 24);
            this.исходныеДанныепоказатьскрытьToolStripMenuItem.Text = "Исходные данные гистограммы (Скрыть/Показать)";
            this.исходныеДанныепоказатьскрытьToolStripMenuItem.Click += new System.EventHandler(this.ShowHideToolStripMenuItem_Click);
            // 
            // saveFileDialogU
            // 
            this.saveFileDialogU.FileOk += new System.ComponentModel.CancelEventHandler(this.SaveFileDialog1_FileOk);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // checkBoxPreview
            // 
            this.checkBoxPreview.AutoSize = true;
            this.checkBoxPreview.Location = new System.Drawing.Point(15, 438);
            this.checkBoxPreview.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxPreview.Name = "checkBoxPreview";
            this.checkBoxPreview.Size = new System.Drawing.Size(178, 21);
            this.checkBoxPreview.TabIndex = 18;
            this.checkBoxPreview.Text = "Не показывать контур";
            this.toolTip1.SetToolTip(this.checkBoxPreview, "Не отображать контур для активного слоя");
            this.checkBoxPreview.UseVisualStyleBackColor = true;
            this.checkBoxPreview.CheckStateChanged += new System.EventHandler(this.CheckBoxPreview_CheckStateChanged);
            // 
            // checkBoxOneOrAll
            // 
            this.checkBoxOneOrAll.AutoSize = true;
            this.checkBoxOneOrAll.Location = new System.Drawing.Point(15, 465);
            this.checkBoxOneOrAll.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxOneOrAll.Name = "checkBoxOneOrAll";
            this.checkBoxOneOrAll.Size = new System.Drawing.Size(182, 21);
            this.checkBoxOneOrAll.TabIndex = 19;
            this.checkBoxOneOrAll.Text = "Отображать один слой";
            this.toolTip1.SetToolTip(this.checkBoxOneOrAll, "Отображать один или несколько слоев одновременно ");
            this.checkBoxOneOrAll.UseVisualStyleBackColor = true;
            this.checkBoxOneOrAll.CheckStateChanged += new System.EventHandler(this.CheckBoxOneOrAll_CheckStateChanged);
            // 
            // numericUpDownLayerInt
            // 
            this.numericUpDownLayerInt.Location = new System.Drawing.Point(272, 586);
            this.numericUpDownLayerInt.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownLayerInt.Name = "numericUpDownLayerInt";
            this.numericUpDownLayerInt.Size = new System.Drawing.Size(112, 22);
            this.numericUpDownLayerInt.TabIndex = 20;
            this.numericUpDownLayerInt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownLayerInt, "Количество интервалов гистограммы");
            this.numericUpDownLayerInt.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // labelRGB1
            // 
            this.labelRGB1.AutoSize = true;
            this.labelRGB1.BackColor = System.Drawing.Color.Transparent;
            this.labelRGB1.Location = new System.Drawing.Point(8, 31);
            this.labelRGB1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRGB1.Name = "labelRGB1";
            this.labelRGB1.Size = new System.Drawing.Size(189, 17);
            this.labelRGB1.TabIndex = 2;
            this.labelRGB1.Text = "Цвет визуализации (RGB1)";
            this.toolTip1.SetToolTip(this.labelRGB1, "Настройка цвета (Double click mouse)");
            this.labelRGB1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LabelRGB1_MouseDoubleClick);
            // 
            // numericUpDownIntVisual
            // 
            this.numericUpDownIntVisual.Location = new System.Drawing.Point(212, 100);
            this.numericUpDownIntVisual.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownIntVisual.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownIntVisual.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownIntVisual.Name = "numericUpDownIntVisual";
            this.numericUpDownIntVisual.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownIntVisual.TabIndex = 14;
            this.numericUpDownIntVisual.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownIntVisual, "Количество интервалов");
            this.numericUpDownIntVisual.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownIntVisual.ValueChanged += new System.EventHandler(this.NumericUpDownIntVisual_ValueChanged);
            // 
            // textBoxRazmahPar
            // 
            this.textBoxRazmahPar.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxRazmahPar.Location = new System.Drawing.Point(319, 100);
            this.textBoxRazmahPar.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRazmahPar.MaxLength = 8;
            this.textBoxRazmahPar.Name = "textBoxRazmahPar";
            this.textBoxRazmahPar.ReadOnly = true;
            this.textBoxRazmahPar.Size = new System.Drawing.Size(68, 22);
            this.textBoxRazmahPar.TabIndex = 20;
            this.textBoxRazmahPar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxRazmahPar, "Размах исследуемого признака");
            // 
            // textBoxSizeInt
            // 
            this.textBoxSizeInt.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxSizeInt.Location = new System.Drawing.Point(425, 100);
            this.textBoxSizeInt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeInt.MaxLength = 8;
            this.textBoxSizeInt.Name = "textBoxSizeInt";
            this.textBoxSizeInt.ReadOnly = true;
            this.textBoxSizeInt.Size = new System.Drawing.Size(68, 22);
            this.textBoxSizeInt.TabIndex = 22;
            this.textBoxSizeInt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxSizeInt, "Размер интервала");
            // 
            // numericUpDownR1
            // 
            this.numericUpDownR1.Location = new System.Drawing.Point(212, 27);
            this.numericUpDownR1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownR1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownR1.Name = "numericUpDownR1";
            this.numericUpDownR1.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownR1.TabIndex = 23;
            this.numericUpDownR1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownR1, "Компонента R аддитивной цветовой модели RGB");
            this.numericUpDownR1.ValueChanged += new System.EventHandler(this.NumericUpDownG1_ValueChanged);
            // 
            // numericUpDownG1
            // 
            this.numericUpDownG1.Location = new System.Drawing.Point(319, 27);
            this.numericUpDownG1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownG1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownG1.Name = "numericUpDownG1";
            this.numericUpDownG1.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownG1.TabIndex = 24;
            this.numericUpDownG1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownG1, "Компонента G аддитивной цветовой модели RGB");
            this.numericUpDownG1.ValueChanged += new System.EventHandler(this.NumericUpDownG1_ValueChanged);
            // 
            // numericUpDownB1
            // 
            this.numericUpDownB1.Location = new System.Drawing.Point(425, 27);
            this.numericUpDownB1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownB1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownB1.Name = "numericUpDownB1";
            this.numericUpDownB1.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownB1.TabIndex = 25;
            this.numericUpDownB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownB1, "Компонента B аддитивной цветовой модели RGB");
            this.numericUpDownB1.ValueChanged += new System.EventHandler(this.NumericUpDownG1_ValueChanged);
            // 
            // labelRGB2
            // 
            this.labelRGB2.AutoSize = true;
            this.labelRGB2.Location = new System.Drawing.Point(8, 66);
            this.labelRGB2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRGB2.Name = "labelRGB2";
            this.labelRGB2.Size = new System.Drawing.Size(189, 17);
            this.labelRGB2.TabIndex = 26;
            this.labelRGB2.Text = "Цвет визуализации (RGB2)";
            this.toolTip1.SetToolTip(this.labelRGB2, "Настройка цвета (Double click mouse)");
            this.labelRGB2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LabelRGB2_MouseDoubleClick);
            // 
            // numericUpDownR2
            // 
            this.numericUpDownR2.Location = new System.Drawing.Point(212, 63);
            this.numericUpDownR2.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownR2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownR2.Name = "numericUpDownR2";
            this.numericUpDownR2.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownR2.TabIndex = 27;
            this.numericUpDownR2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownR2, "Компонента R аддитивной цветовой модели RGB");
            this.numericUpDownR2.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownR2.ValueChanged += new System.EventHandler(this.NumericUpDownR2_ValueChanged);
            // 
            // numericUpDownG2
            // 
            this.numericUpDownG2.Location = new System.Drawing.Point(319, 63);
            this.numericUpDownG2.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownG2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownG2.Name = "numericUpDownG2";
            this.numericUpDownG2.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownG2.TabIndex = 28;
            this.numericUpDownG2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownG2, "Компонента G аддитивной цветовой модели RGB");
            this.numericUpDownG2.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownG2.ValueChanged += new System.EventHandler(this.NumericUpDownR2_ValueChanged);
            // 
            // numericUpDownB2
            // 
            this.numericUpDownB2.Location = new System.Drawing.Point(425, 63);
            this.numericUpDownB2.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownB2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownB2.Name = "numericUpDownB2";
            this.numericUpDownB2.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownB2.TabIndex = 29;
            this.numericUpDownB2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownB2, "Компонента B аддитивной цветовой модели RGB");
            this.numericUpDownB2.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownB2.ValueChanged += new System.EventHandler(this.NumericUpDownR2_ValueChanged);
            // 
            // labelStep
            // 
            this.labelStep.AutoSize = true;
            this.labelStep.Location = new System.Drawing.Point(9, 139);
            this.labelStep.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStep.Name = "labelStep";
            this.labelStep.Size = new System.Drawing.Size(114, 17);
            this.labelStep.TabIndex = 30;
            this.labelStep.Text = "Шаг построения";
            this.toolTip1.SetToolTip(this.labelStep, "Шаг построения при послойном изготовлении по оси Z");
            // 
            // numericUpDownStep
            // 
            this.numericUpDownStep.DecimalPlaces = 3;
            this.numericUpDownStep.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownStep.Location = new System.Drawing.Point(212, 135);
            this.numericUpDownStep.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownStep.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownStep.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numericUpDownStep.Name = "numericUpDownStep";
            this.numericUpDownStep.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownStep.TabIndex = 31;
            this.numericUpDownStep.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownStep, "Шаг построения (глубина слоя)");
            this.numericUpDownStep.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // checkBoxGist
            // 
            this.checkBoxGist.AutoSize = true;
            this.checkBoxGist.Location = new System.Drawing.Point(319, 139);
            this.checkBoxGist.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxGist.Name = "checkBoxGist";
            this.checkBoxGist.Size = new System.Drawing.Size(124, 21);
            this.checkBoxGist.TabIndex = 33;
            this.checkBoxGist.Text = "Кол-во граней";
            this.toolTip1.SetToolTip(this.checkBoxGist, "Построение гистограммы по количеству или площади граней (задание перед просмотром" +
        ")");
            this.checkBoxGist.UseVisualStyleBackColor = true;
            this.checkBoxGist.CheckStateChanged += new System.EventHandler(this.CheckBoxGist_CheckStateChanged);
            // 
            // buttonXls
            // 
            this.buttonXls.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonXls.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonXls.Location = new System.Drawing.Point(13, 247);
            this.buttonXls.Margin = new System.Windows.Forms.Padding(4);
            this.buttonXls.Name = "buttonXls";
            this.buttonXls.Size = new System.Drawing.Size(51, 26);
            this.buttonXls.TabIndex = 43;
            this.buttonXls.Text = "XLS";
            this.toolTip1.SetToolTip(this.buttonXls, "Сохранение таблицы результатов статистического анализа в XLS (или буфер обмена)");
            this.buttonXls.UseVisualStyleBackColor = true;
            this.buttonXls.Click += new System.EventHandler(this.ButtonXls_Click);
            // 
            // label1var
            // 
            this.label1var.AutoSize = true;
            this.label1var.BackColor = System.Drawing.Color.Transparent;
            this.label1var.Location = new System.Drawing.Point(13, 27);
            this.label1var.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1var.Name = "label1var";
            this.label1var.Size = new System.Drawing.Size(87, 17);
            this.label1var.TabIndex = 2;
            this.label1var.Text = "1-й вариант";
            this.toolTip1.SetToolTip(this.label1var, "Настройка цвета (Double click mouse)");
            this.label1var.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Label1var_MouseDoubleClick);
            // 
            // label2var
            // 
            this.label2var.AutoSize = true;
            this.label2var.BackColor = System.Drawing.Color.Transparent;
            this.label2var.Location = new System.Drawing.Point(13, 64);
            this.label2var.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2var.Name = "label2var";
            this.label2var.Size = new System.Drawing.Size(87, 17);
            this.label2var.TabIndex = 26;
            this.label2var.Text = "2-й вариант";
            this.toolTip1.SetToolTip(this.label2var, "Настройка цвета (Double click mouse)");
            this.label2var.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Label2var_MouseDoubleClick);
            // 
            // numericUpDownIntOrientation
            // 
            this.numericUpDownIntOrientation.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownIntOrientation.Location = new System.Drawing.Point(216, 133);
            this.numericUpDownIntOrientation.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownIntOrientation.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDownIntOrientation.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownIntOrientation.Name = "numericUpDownIntOrientation";
            this.numericUpDownIntOrientation.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownIntOrientation.TabIndex = 28;
            this.numericUpDownIntOrientation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownIntOrientation, "Количество интервалов");
            this.numericUpDownIntOrientation.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownIntOrientation.ValueChanged += new System.EventHandler(this.NumericUpDownIntOrientation_ValueChanged);
            // 
            // textBoxRangeOrient
            // 
            this.textBoxRangeOrient.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxRangeOrient.Location = new System.Drawing.Point(323, 133);
            this.textBoxRangeOrient.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRangeOrient.MaxLength = 8;
            this.textBoxRangeOrient.Name = "textBoxRangeOrient";
            this.textBoxRangeOrient.ReadOnly = true;
            this.textBoxRangeOrient.Size = new System.Drawing.Size(68, 22);
            this.textBoxRangeOrient.TabIndex = 29;
            this.textBoxRangeOrient.Text = "180";
            this.textBoxRangeOrient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxRangeOrient, "Размах угла наклона грани относительно оси Z");
            // 
            // textBoxIntOrient
            // 
            this.textBoxIntOrient.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxIntOrient.Location = new System.Drawing.Point(429, 133);
            this.textBoxIntOrient.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIntOrient.MaxLength = 8;
            this.textBoxIntOrient.Name = "textBoxIntOrient";
            this.textBoxIntOrient.ReadOnly = true;
            this.textBoxIntOrient.Size = new System.Drawing.Size(68, 22);
            this.textBoxIntOrient.TabIndex = 30;
            this.textBoxIntOrient.Text = "9,0";
            this.textBoxIntOrient.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxIntOrient, "Размер интервала");
            // 
            // label3var
            // 
            this.label3var.AutoSize = true;
            this.label3var.BackColor = System.Drawing.Color.Transparent;
            this.label3var.Location = new System.Drawing.Point(13, 101);
            this.label3var.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3var.Name = "label3var";
            this.label3var.Size = new System.Drawing.Size(87, 17);
            this.label3var.TabIndex = 31;
            this.label3var.Text = "3-й вариант";
            this.toolTip1.SetToolTip(this.label3var, "Настройка цвета (Double click mouse)");
            this.label3var.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Label3var_MouseDoubleClick);
            // 
            // numericUpDown1varR
            // 
            this.numericUpDown1varR.Location = new System.Drawing.Point(216, 25);
            this.numericUpDown1varR.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varR.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1varR.Name = "numericUpDown1varR";
            this.numericUpDown1varR.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varR.TabIndex = 35;
            this.numericUpDown1varR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varR, "Компонента R аддитивной цветовой модели RGB");
            this.numericUpDown1varR.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1varR.ValueChanged += new System.EventHandler(this.NumericUpDown1varR_ValueChanged);
            // 
            // numericUpDown1varG
            // 
            this.numericUpDown1varG.Location = new System.Drawing.Point(323, 25);
            this.numericUpDown1varG.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varG.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1varG.Name = "numericUpDown1varG";
            this.numericUpDown1varG.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varG.TabIndex = 36;
            this.numericUpDown1varG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varG, "Компонента G аддитивной цветовой модели RGB");
            this.numericUpDown1varG.ValueChanged += new System.EventHandler(this.NumericUpDown1varR_ValueChanged);
            // 
            // numericUpDown1varB
            // 
            this.numericUpDown1varB.Location = new System.Drawing.Point(429, 25);
            this.numericUpDown1varB.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varB.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1varB.Name = "numericUpDown1varB";
            this.numericUpDown1varB.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varB.TabIndex = 37;
            this.numericUpDown1varB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varB, "Компонента B аддитивной цветовой модели RGB");
            this.numericUpDown1varB.ValueChanged += new System.EventHandler(this.NumericUpDown1varR_ValueChanged);
            // 
            // numericUpDown2varR
            // 
            this.numericUpDown2varR.Location = new System.Drawing.Point(216, 62);
            this.numericUpDown2varR.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varR.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown2varR.Name = "numericUpDown2varR";
            this.numericUpDown2varR.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varR.TabIndex = 38;
            this.numericUpDown2varR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varR, "Компонента R аддитивной цветовой модели RGB");
            this.numericUpDown2varR.ValueChanged += new System.EventHandler(this.NumericUpDown2varR_ValueChanged);
            // 
            // numericUpDown2varG
            // 
            this.numericUpDown2varG.Location = new System.Drawing.Point(323, 62);
            this.numericUpDown2varG.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varG.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown2varG.Name = "numericUpDown2varG";
            this.numericUpDown2varG.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varG.TabIndex = 39;
            this.numericUpDown2varG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varG, "Компонента G аддитивной цветовой модели RGB");
            this.numericUpDown2varG.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown2varG.ValueChanged += new System.EventHandler(this.NumericUpDown2varR_ValueChanged);
            // 
            // numericUpDown2varB
            // 
            this.numericUpDown2varB.Location = new System.Drawing.Point(429, 62);
            this.numericUpDown2varB.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varB.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown2varB.Name = "numericUpDown2varB";
            this.numericUpDown2varB.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varB.TabIndex = 40;
            this.numericUpDown2varB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varB, "Компонента B аддитивной цветовой модели RGB");
            this.numericUpDown2varB.ValueChanged += new System.EventHandler(this.NumericUpDown2varR_ValueChanged);
            // 
            // numericUpDown3varR
            // 
            this.numericUpDown3varR.Location = new System.Drawing.Point(216, 98);
            this.numericUpDown3varR.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varR.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown3varR.Name = "numericUpDown3varR";
            this.numericUpDown3varR.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varR.TabIndex = 41;
            this.numericUpDown3varR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varR, "Компонента R аддитивной цветовой модели RGB");
            this.numericUpDown3varR.ValueChanged += new System.EventHandler(this.NumericUpDown3varR_ValueChanged);
            // 
            // numericUpDown3varG
            // 
            this.numericUpDown3varG.Location = new System.Drawing.Point(323, 98);
            this.numericUpDown3varG.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varG.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown3varG.Name = "numericUpDown3varG";
            this.numericUpDown3varG.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varG.TabIndex = 42;
            this.numericUpDown3varG.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varG, "Компонента G аддитивной цветовой модели RGB");
            this.numericUpDown3varG.ValueChanged += new System.EventHandler(this.NumericUpDown3varR_ValueChanged);
            // 
            // numericUpDown3varB
            // 
            this.numericUpDown3varB.Location = new System.Drawing.Point(429, 98);
            this.numericUpDown3varB.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varB.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown3varB.Name = "numericUpDown3varB";
            this.numericUpDown3varB.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varB.TabIndex = 43;
            this.numericUpDown3varB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varB, "Компонента B аддитивной цветовой модели RGB");
            this.numericUpDown3varB.Value = new decimal(new int[] {
            190,
            0,
            0,
            0});
            this.numericUpDown3varB.ValueChanged += new System.EventHandler(this.NumericUpDown3varR_ValueChanged);
            // 
            // label1varRangeAngle
            // 
            this.label1varRangeAngle.AutoSize = true;
            this.label1varRangeAngle.BackColor = System.Drawing.Color.Transparent;
            this.label1varRangeAngle.Location = new System.Drawing.Point(511, 27);
            this.label1varRangeAngle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1varRangeAngle.Name = "label1varRangeAngle";
            this.label1varRangeAngle.Size = new System.Drawing.Size(113, 17);
            this.label1varRangeAngle.TabIndex = 44;
            this.label1varRangeAngle.Text = "Диапазон углов";
            this.toolTip1.SetToolTip(this.label1varRangeAngle, "Диапазон исследуемого признака");
            // 
            // label2varRangeAngle
            // 
            this.label2varRangeAngle.AutoSize = true;
            this.label2varRangeAngle.Location = new System.Drawing.Point(511, 64);
            this.label2varRangeAngle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2varRangeAngle.Name = "label2varRangeAngle";
            this.label2varRangeAngle.Size = new System.Drawing.Size(113, 17);
            this.label2varRangeAngle.TabIndex = 45;
            this.label2varRangeAngle.Text = "Диапазон углов";
            this.toolTip1.SetToolTip(this.label2varRangeAngle, "Диапазон исследуемого признака");
            // 
            // label3varRangeAngle
            // 
            this.label3varRangeAngle.AutoSize = true;
            this.label3varRangeAngle.Location = new System.Drawing.Point(511, 101);
            this.label3varRangeAngle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3varRangeAngle.Name = "label3varRangeAngle";
            this.label3varRangeAngle.Size = new System.Drawing.Size(113, 17);
            this.label3varRangeAngle.TabIndex = 46;
            this.label3varRangeAngle.Text = "Диапазон углов";
            this.toolTip1.SetToolTip(this.label3varRangeAngle, "Диапазон исследуемого признака");
            // 
            // checkBox1var
            // 
            this.checkBox1var.AutoSize = true;
            this.checkBox1var.Location = new System.Drawing.Point(173, 27);
            this.checkBox1var.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1var.Name = "checkBox1var";
            this.checkBox1var.Size = new System.Drawing.Size(18, 17);
            this.checkBox1var.TabIndex = 47;
            this.toolTip1.SetToolTip(this.checkBox1var, "Учитывать 1-й вариант");
            this.checkBox1var.UseVisualStyleBackColor = true;
            this.checkBox1var.CheckStateChanged += new System.EventHandler(this.NumericUpDown1varR_ValueChanged);
            // 
            // checkBox2var
            // 
            this.checkBox2var.AutoSize = true;
            this.checkBox2var.Location = new System.Drawing.Point(173, 64);
            this.checkBox2var.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox2var.Name = "checkBox2var";
            this.checkBox2var.Size = new System.Drawing.Size(18, 17);
            this.checkBox2var.TabIndex = 48;
            this.toolTip1.SetToolTip(this.checkBox2var, "Учитывать 2-й вариант");
            this.checkBox2var.UseVisualStyleBackColor = true;
            this.checkBox2var.CheckStateChanged += new System.EventHandler(this.NumericUpDown2varR_ValueChanged);
            // 
            // checkBox3var
            // 
            this.checkBox3var.AutoSize = true;
            this.checkBox3var.Location = new System.Drawing.Point(173, 101);
            this.checkBox3var.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox3var.Name = "checkBox3var";
            this.checkBox3var.Size = new System.Drawing.Size(18, 17);
            this.checkBox3var.TabIndex = 49;
            this.toolTip1.SetToolTip(this.checkBox3var, "Учитывать 3-й вариант");
            this.checkBox3var.UseVisualStyleBackColor = true;
            this.checkBox3var.CheckStateChanged += new System.EventHandler(this.NumericUpDown3varR_ValueChanged);
            // 
            // numericUpDown1varAngleMin
            // 
            this.numericUpDown1varAngleMin.Location = new System.Drawing.Point(647, 25);
            this.numericUpDown1varAngleMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varAngleMin.Maximum = new decimal(new int[] {
            179,
            0,
            0,
            0});
            this.numericUpDown1varAngleMin.Name = "numericUpDown1varAngleMin";
            this.numericUpDown1varAngleMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varAngleMin.TabIndex = 50;
            this.numericUpDown1varAngleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varAngleMin, "Минимальное значение");
            this.numericUpDown1varAngleMin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1varAngleMin.ValueChanged += new System.EventHandler(this.NumericUpDown1varAngleMin_ValueChanged);
            // 
            // numericUpDown1varAngleMax
            // 
            this.numericUpDown1varAngleMax.Location = new System.Drawing.Point(753, 25);
            this.numericUpDown1varAngleMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varAngleMax.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDown1varAngleMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1varAngleMax.Name = "numericUpDown1varAngleMax";
            this.numericUpDown1varAngleMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varAngleMax.TabIndex = 51;
            this.numericUpDown1varAngleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varAngleMax, "Максимальное значение");
            this.numericUpDown1varAngleMax.Value = new decimal(new int[] {
            45,
            0,
            0,
            0});
            this.numericUpDown1varAngleMax.ValueChanged += new System.EventHandler(this.NumericUpDown1varAngleMin_ValueChanged);
            // 
            // numericUpDown2varAngleMin
            // 
            this.numericUpDown2varAngleMin.Location = new System.Drawing.Point(647, 62);
            this.numericUpDown2varAngleMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varAngleMin.Maximum = new decimal(new int[] {
            179,
            0,
            0,
            0});
            this.numericUpDown2varAngleMin.Name = "numericUpDown2varAngleMin";
            this.numericUpDown2varAngleMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varAngleMin.TabIndex = 52;
            this.numericUpDown2varAngleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varAngleMin, "Минимальное значение");
            this.numericUpDown2varAngleMin.Value = new decimal(new int[] {
            89,
            0,
            0,
            0});
            this.numericUpDown2varAngleMin.ValueChanged += new System.EventHandler(this.NumericUpDown2varAngleMin_ValueChanged);
            // 
            // numericUpDown2varAngleMax
            // 
            this.numericUpDown2varAngleMax.Location = new System.Drawing.Point(753, 62);
            this.numericUpDown2varAngleMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varAngleMax.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDown2varAngleMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2varAngleMax.Name = "numericUpDown2varAngleMax";
            this.numericUpDown2varAngleMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varAngleMax.TabIndex = 53;
            this.numericUpDown2varAngleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varAngleMax, "Максимальное значение");
            this.numericUpDown2varAngleMax.Value = new decimal(new int[] {
            91,
            0,
            0,
            0});
            this.numericUpDown2varAngleMax.ValueChanged += new System.EventHandler(this.NumericUpDown2varAngleMin_ValueChanged);
            // 
            // numericUpDown3varAngleMin
            // 
            this.numericUpDown3varAngleMin.Location = new System.Drawing.Point(647, 98);
            this.numericUpDown3varAngleMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varAngleMin.Maximum = new decimal(new int[] {
            179,
            0,
            0,
            0});
            this.numericUpDown3varAngleMin.Name = "numericUpDown3varAngleMin";
            this.numericUpDown3varAngleMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varAngleMin.TabIndex = 54;
            this.numericUpDown3varAngleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varAngleMin, "Минимальное значение");
            this.numericUpDown3varAngleMin.Value = new decimal(new int[] {
            136,
            0,
            0,
            0});
            this.numericUpDown3varAngleMin.ValueChanged += new System.EventHandler(this.NumericUpDown3varAngleMin_ValueChanged);
            // 
            // numericUpDown3varAngleMax
            // 
            this.numericUpDown3varAngleMax.Location = new System.Drawing.Point(753, 98);
            this.numericUpDown3varAngleMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varAngleMax.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDown3varAngleMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3varAngleMax.Name = "numericUpDown3varAngleMax";
            this.numericUpDown3varAngleMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varAngleMax.TabIndex = 55;
            this.numericUpDown3varAngleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varAngleMax, "Максимальное значение");
            this.numericUpDown3varAngleMax.Value = new decimal(new int[] {
            179,
            0,
            0,
            0});
            this.numericUpDown3varAngleMax.ValueChanged += new System.EventHandler(this.NumericUpDown3varAngleMin_ValueChanged);
            // 
            // label1varRelS
            // 
            this.label1varRelS.AutoSize = true;
            this.label1varRelS.BackColor = System.Drawing.Color.Transparent;
            this.label1varRelS.Location = new System.Drawing.Point(841, 27);
            this.label1varRelS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1varRelS.Name = "label1varRelS";
            this.label1varRelS.Size = new System.Drawing.Size(96, 17);
            this.label1varRelS.TabIndex = 58;
            this.label1varRelS.Text = "Отн.площадь";
            this.toolTip1.SetToolTip(this.label1varRelS, "Относительная площадь граней");
            // 
            // label2varRelS
            // 
            this.label2varRelS.AutoSize = true;
            this.label2varRelS.BackColor = System.Drawing.Color.Transparent;
            this.label2varRelS.Location = new System.Drawing.Point(841, 64);
            this.label2varRelS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2varRelS.Name = "label2varRelS";
            this.label2varRelS.Size = new System.Drawing.Size(96, 17);
            this.label2varRelS.TabIndex = 59;
            this.label2varRelS.Text = "Отн.площадь";
            this.toolTip1.SetToolTip(this.label2varRelS, "Относительная площадь граней");
            // 
            // label3varRelS
            // 
            this.label3varRelS.AutoSize = true;
            this.label3varRelS.BackColor = System.Drawing.Color.Transparent;
            this.label3varRelS.Location = new System.Drawing.Point(841, 101);
            this.label3varRelS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3varRelS.Name = "label3varRelS";
            this.label3varRelS.Size = new System.Drawing.Size(96, 17);
            this.label3varRelS.TabIndex = 60;
            this.label3varRelS.Text = "Отн.площадь";
            this.toolTip1.SetToolTip(this.label3varRelS, "Относительная площадь граней");
            // 
            // numericUpDown1varRelSMin
            // 
            this.numericUpDown1varRelSMin.Location = new System.Drawing.Point(977, 25);
            this.numericUpDown1varRelSMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varRelSMin.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.numericUpDown1varRelSMin.Name = "numericUpDown1varRelSMin";
            this.numericUpDown1varRelSMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varRelSMin.TabIndex = 63;
            this.numericUpDown1varRelSMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varRelSMin, "Минимальное значение");
            this.numericUpDown1varRelSMin.ValueChanged += new System.EventHandler(this.NumericUpDown1varRelSMin_ValueChanged);
            // 
            // numericUpDown1varRelSMax
            // 
            this.numericUpDown1varRelSMax.Location = new System.Drawing.Point(1084, 25);
            this.numericUpDown1varRelSMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1varRelSMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1varRelSMax.Name = "numericUpDown1varRelSMax";
            this.numericUpDown1varRelSMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown1varRelSMax.TabIndex = 64;
            this.numericUpDown1varRelSMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown1varRelSMax, "Максимальное значение");
            this.numericUpDown1varRelSMax.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown1varRelSMax.ValueChanged += new System.EventHandler(this.NumericUpDown1varRelSMin_ValueChanged);
            // 
            // numericUpDown2varRelSMin
            // 
            this.numericUpDown2varRelSMin.Location = new System.Drawing.Point(977, 62);
            this.numericUpDown2varRelSMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varRelSMin.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.numericUpDown2varRelSMin.Name = "numericUpDown2varRelSMin";
            this.numericUpDown2varRelSMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varRelSMin.TabIndex = 65;
            this.numericUpDown2varRelSMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varRelSMin, "Минимальное значение");
            this.numericUpDown2varRelSMin.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown2varRelSMin.ValueChanged += new System.EventHandler(this.NumericUpDown2varRelSMin_ValueChanged);
            // 
            // numericUpDown2varRelSMax
            // 
            this.numericUpDown2varRelSMax.Location = new System.Drawing.Point(1084, 62);
            this.numericUpDown2varRelSMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2varRelSMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2varRelSMax.Name = "numericUpDown2varRelSMax";
            this.numericUpDown2varRelSMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown2varRelSMax.TabIndex = 66;
            this.numericUpDown2varRelSMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown2varRelSMax, "Максимальное значение");
            this.numericUpDown2varRelSMax.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown2varRelSMax.ValueChanged += new System.EventHandler(this.NumericUpDown2varRelSMin_ValueChanged);
            // 
            // numericUpDown3varRelSMin
            // 
            this.numericUpDown3varRelSMin.Location = new System.Drawing.Point(977, 98);
            this.numericUpDown3varRelSMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varRelSMin.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.numericUpDown3varRelSMin.Name = "numericUpDown3varRelSMin";
            this.numericUpDown3varRelSMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varRelSMin.TabIndex = 67;
            this.numericUpDown3varRelSMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varRelSMin, "Минимальное значение");
            this.numericUpDown3varRelSMin.ValueChanged += new System.EventHandler(this.NumericUpDown3varRelSMin_ValueChanged);
            // 
            // numericUpDown3varRelSMax
            // 
            this.numericUpDown3varRelSMax.Location = new System.Drawing.Point(1084, 98);
            this.numericUpDown3varRelSMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3varRelSMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3varRelSMax.Name = "numericUpDown3varRelSMax";
            this.numericUpDown3varRelSMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDown3varRelSMax.TabIndex = 68;
            this.numericUpDown3varRelSMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDown3varRelSMax, "Максимальное значение");
            this.numericUpDown3varRelSMax.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown3varRelSMax.ValueChanged += new System.EventHandler(this.NumericUpDown3varRelSMin_ValueChanged);
            // 
            // labelRangeH
            // 
            this.labelRangeH.AutoSize = true;
            this.labelRangeH.Location = new System.Drawing.Point(511, 138);
            this.labelRangeH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRangeH.Name = "labelRangeH";
            this.labelRangeH.Size = new System.Drawing.Size(127, 17);
            this.labelRangeH.TabIndex = 69;
            this.labelRangeH.Text = "Диапазон высоты";
            this.toolTip1.SetToolTip(this.labelRangeH, "Диапазон исследуемого признака");
            // 
            // numericUpDownHMin
            // 
            this.numericUpDownHMin.Location = new System.Drawing.Point(647, 133);
            this.numericUpDownHMin.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownHMin.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.numericUpDownHMin.Name = "numericUpDownHMin";
            this.numericUpDownHMin.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownHMin.TabIndex = 70;
            this.numericUpDownHMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownHMin, "Минимальное относительное значение");
            this.numericUpDownHMin.ValueChanged += new System.EventHandler(this.NumericUpDownHMin_ValueChanged);
            // 
            // numericUpDownHMax
            // 
            this.numericUpDownHMax.Location = new System.Drawing.Point(753, 133);
            this.numericUpDownHMax.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownHMax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHMax.Name = "numericUpDownHMax";
            this.numericUpDownHMax.Size = new System.Drawing.Size(69, 22);
            this.numericUpDownHMax.TabIndex = 71;
            this.numericUpDownHMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownHMax, "Максимальное относительное значение");
            this.numericUpDownHMax.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // checkBox1varAddH
            // 
            this.checkBox1varAddH.AutoSize = true;
            this.checkBox1varAddH.Location = new System.Drawing.Point(847, 137);
            this.checkBox1varAddH.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1varAddH.Name = "checkBox1varAddH";
            this.checkBox1varAddH.Size = new System.Drawing.Size(51, 21);
            this.checkBox1varAddH.TabIndex = 72;
            this.checkBox1varAddH.Text = "1-й";
            this.toolTip1.SetToolTip(this.checkBox1varAddH, "Учитывать для 1-го варианта");
            this.checkBox1varAddH.UseVisualStyleBackColor = true;
            // 
            // checkBox2varAddH
            // 
            this.checkBox2varAddH.AutoSize = true;
            this.checkBox2varAddH.Location = new System.Drawing.Point(925, 137);
            this.checkBox2varAddH.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox2varAddH.Name = "checkBox2varAddH";
            this.checkBox2varAddH.Size = new System.Drawing.Size(51, 21);
            this.checkBox2varAddH.TabIndex = 73;
            this.checkBox2varAddH.Text = "2-й";
            this.toolTip1.SetToolTip(this.checkBox2varAddH, "Учитывать для 2-го варианта");
            this.checkBox2varAddH.UseVisualStyleBackColor = true;
            // 
            // checkBox3varAddH
            // 
            this.checkBox3varAddH.AutoSize = true;
            this.checkBox3varAddH.Location = new System.Drawing.Point(1004, 137);
            this.checkBox3varAddH.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox3varAddH.Name = "checkBox3varAddH";
            this.checkBox3varAddH.Size = new System.Drawing.Size(51, 21);
            this.checkBox3varAddH.TabIndex = 74;
            this.checkBox3varAddH.Text = "3-й";
            this.toolTip1.SetToolTip(this.checkBox3varAddH, "Учитывать для 3-го варианта");
            this.checkBox3varAddH.UseVisualStyleBackColor = true;
            // 
            // checkBoxAndOrAddCondition
            // 
            this.checkBoxAndOrAddCondition.AutoSize = true;
            this.checkBoxAndOrAddCondition.Location = new System.Drawing.Point(1083, 137);
            this.checkBoxAndOrAddCondition.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxAndOrAddCondition.Name = "checkBoxAndOrAddCondition";
            this.checkBoxAndOrAddCondition.Size = new System.Drawing.Size(59, 21);
            this.checkBoxAndOrAddCondition.TabIndex = 75;
            this.checkBoxAndOrAddCondition.Text = "AND";
            this.toolTip1.SetToolTip(this.checkBoxAndOrAddCondition, "Учитывать условие - AND/OR");
            this.checkBoxAndOrAddCondition.UseVisualStyleBackColor = true;
            this.checkBoxAndOrAddCondition.CheckStateChanged += new System.EventHandler(this.CheckBoxAndOrAddCondition_CheckStateChanged);
            // 
            // buttonXlsOrient
            // 
            this.buttonXlsOrient.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonXlsOrient.Location = new System.Drawing.Point(13, 245);
            this.buttonXlsOrient.Margin = new System.Windows.Forms.Padding(4);
            this.buttonXlsOrient.Name = "buttonXlsOrient";
            this.buttonXlsOrient.Size = new System.Drawing.Size(51, 26);
            this.buttonXlsOrient.TabIndex = 48;
            this.buttonXlsOrient.Text = "XLS";
            this.toolTip1.SetToolTip(this.buttonXlsOrient, "Сохранение таблицы результатов статистического анализа в XLS (или буфер обмена)");
            this.buttonXlsOrient.UseVisualStyleBackColor = true;
            this.buttonXlsOrient.Click += new System.EventHandler(this.ButtonXlsOrient_Click);
            // 
            // checkBoxNumInterval
            // 
            this.checkBoxNumInterval.AutoSize = true;
            this.checkBoxNumInterval.Checked = true;
            this.checkBoxNumInterval.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxNumInterval.Location = new System.Drawing.Point(124, 85);
            this.checkBoxNumInterval.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxNumInterval.Name = "checkBoxNumInterval";
            this.checkBoxNumInterval.Size = new System.Drawing.Size(18, 17);
            this.checkBoxNumInterval.TabIndex = 10;
            this.toolTip1.SetToolTip(this.checkBoxNumInterval, "Вкл/откл. ReadOnly");
            this.checkBoxNumInterval.UseVisualStyleBackColor = true;
            this.checkBoxNumInterval.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // numericUpDownNumIntX
            // 
            this.numericUpDownNumIntX.Location = new System.Drawing.Point(155, 81);
            this.numericUpDownNumIntX.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownNumIntX.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDownNumIntX.Name = "numericUpDownNumIntX";
            this.numericUpDownNumIntX.Size = new System.Drawing.Size(104, 22);
            this.numericUpDownNumIntX.TabIndex = 14;
            this.numericUpDownNumIntX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownNumIntX, "Количество интервалов гистограммы по оси X");
            this.numericUpDownNumIntX.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownNumIntX.ValueChanged += new System.EventHandler(this.NumericUpDownNumIntX_ValueChanged);
            // 
            // numericUpDownNumIntY
            // 
            this.numericUpDownNumIntY.Location = new System.Drawing.Point(279, 80);
            this.numericUpDownNumIntY.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownNumIntY.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDownNumIntY.Name = "numericUpDownNumIntY";
            this.numericUpDownNumIntY.ReadOnly = true;
            this.numericUpDownNumIntY.Size = new System.Drawing.Size(104, 22);
            this.numericUpDownNumIntY.TabIndex = 15;
            this.numericUpDownNumIntY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownNumIntY, "Количество интервалов гистограммы по оси Y");
            this.numericUpDownNumIntY.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownNumIntY.ValueChanged += new System.EventHandler(this.NumericUpDownNumIntY_ValueChanged);
            // 
            // numericUpDownNumIntZ
            // 
            this.numericUpDownNumIntZ.Location = new System.Drawing.Point(404, 80);
            this.numericUpDownNumIntZ.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownNumIntZ.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDownNumIntZ.Name = "numericUpDownNumIntZ";
            this.numericUpDownNumIntZ.ReadOnly = true;
            this.numericUpDownNumIntZ.Size = new System.Drawing.Size(104, 22);
            this.numericUpDownNumIntZ.TabIndex = 16;
            this.numericUpDownNumIntZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownNumIntZ, "Количество интервалов гистограммы по оси Z");
            this.numericUpDownNumIntZ.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownNumIntZ.ValueChanged += new System.EventHandler(this.NumericUpDownNumIntZ_ValueChanged);
            // 
            // textBoxMin
            // 
            this.textBoxMin.Location = new System.Drawing.Point(16, 27);
            this.textBoxMin.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMin.Name = "textBoxMin";
            this.textBoxMin.ReadOnly = true;
            this.textBoxMin.Size = new System.Drawing.Size(137, 22);
            this.textBoxMin.TabIndex = 32;
            this.textBoxMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxMin, "Минимальное значение исследуемой выборки");
            // 
            // textBoxInterval
            // 
            this.textBoxInterval.Location = new System.Drawing.Point(16, 133);
            this.textBoxInterval.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxInterval.Name = "textBoxInterval";
            this.textBoxInterval.ReadOnly = true;
            this.textBoxInterval.Size = new System.Drawing.Size(137, 22);
            this.textBoxInterval.TabIndex = 41;
            this.textBoxInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxInterval, "Размах значений");
            // 
            // textBoxMax
            // 
            this.textBoxMax.Location = new System.Drawing.Point(16, 80);
            this.textBoxMax.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMax.Name = "textBoxMax";
            this.textBoxMax.ReadOnly = true;
            this.textBoxMax.Size = new System.Drawing.Size(137, 22);
            this.textBoxMax.TabIndex = 42;
            this.textBoxMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxMax, "Максимальное значение исследуемой выборки");
            // 
            // chartHistogramVoxelYRelation
            // 
            this.chartHistogramVoxelYRelation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelYRelation.BorderlineWidth = 2;
            chartArea1.Name = "ChartArea1";
            this.chartHistogramVoxelYRelation.ChartAreas.Add(chartArea1);
            this.chartHistogramVoxelYRelation.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelYRelation.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelYRelation.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelYRelation.Name = "chartHistogramVoxelYRelation";
            this.chartHistogramVoxelYRelation.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chartHistogramVoxelYRelation.Size = new System.Drawing.Size(1195, 415);
            this.chartHistogramVoxelYRelation.TabIndex = 41;
            this.chartHistogramVoxelYRelation.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelYRelation, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelYRelation.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelZRelation
            // 
            this.chartHistogramVoxelZRelation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelZRelation.BorderlineWidth = 2;
            chartArea2.Name = "ChartArea1";
            this.chartHistogramVoxelZRelation.ChartAreas.Add(chartArea2);
            this.chartHistogramVoxelZRelation.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelZRelation.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelZRelation.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelZRelation.Name = "chartHistogramVoxelZRelation";
            this.chartHistogramVoxelZRelation.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chartHistogramVoxelZRelation.Size = new System.Drawing.Size(1195, 415);
            this.chartHistogramVoxelZRelation.TabIndex = 42;
            this.chartHistogramVoxelZRelation.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelZRelation, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelZRelation.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelXRelation
            // 
            this.chartHistogramVoxelXRelation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelXRelation.BorderlineWidth = 2;
            chartArea3.Name = "ChartArea1";
            this.chartHistogramVoxelXRelation.ChartAreas.Add(chartArea3);
            this.chartHistogramVoxelXRelation.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelXRelation.Location = new System.Drawing.Point(11, 230);
            this.chartHistogramVoxelXRelation.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelXRelation.Name = "chartHistogramVoxelXRelation";
            this.chartHistogramVoxelXRelation.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chartHistogramVoxelXRelation.Size = new System.Drawing.Size(1195, 420);
            this.chartHistogramVoxelXRelation.TabIndex = 40;
            this.chartHistogramVoxelXRelation.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelXRelation, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelXRelation.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelXYZ
            // 
            this.chartHistogramVoxelXYZ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelXYZ.BorderlineWidth = 2;
            chartArea4.AlignWithChartArea = "ChartAreaX";
            chartArea4.Name = "ChartAreaX";
            chartArea5.AlignWithChartArea = "ChartAreaX";
            chartArea5.Name = "ChartAreaY";
            chartArea6.AlignWithChartArea = "ChartAreaX";
            chartArea6.Name = "ChartAreaZ";
            this.chartHistogramVoxelXYZ.ChartAreas.Add(chartArea4);
            this.chartHistogramVoxelXYZ.ChartAreas.Add(chartArea5);
            this.chartHistogramVoxelXYZ.ChartAreas.Add(chartArea6);
            this.chartHistogramVoxelXYZ.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelXYZ.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelXYZ.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelXYZ.Name = "chartHistogramVoxelXYZ";
            this.chartHistogramVoxelXYZ.Size = new System.Drawing.Size(1195, 421);
            this.chartHistogramVoxelXYZ.TabIndex = 39;
            this.chartHistogramVoxelXYZ.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelXYZ, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelXYZ.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelXYZRelative
            // 
            this.chartHistogramVoxelXYZRelative.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelXYZRelative.BorderlineWidth = 2;
            chartArea7.AlignWithChartArea = "ChartAreaX";
            chartArea7.Name = "ChartAreaX";
            chartArea8.AlignWithChartArea = "ChartAreaX";
            chartArea8.Name = "ChartAreaY";
            chartArea9.AlignWithChartArea = "ChartAreaX";
            chartArea9.Name = "ChartAreaZ";
            this.chartHistogramVoxelXYZRelative.ChartAreas.Add(chartArea7);
            this.chartHistogramVoxelXYZRelative.ChartAreas.Add(chartArea8);
            this.chartHistogramVoxelXYZRelative.ChartAreas.Add(chartArea9);
            this.chartHistogramVoxelXYZRelative.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelXYZRelative.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelXYZRelative.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelXYZRelative.Name = "chartHistogramVoxelXYZRelative";
            this.chartHistogramVoxelXYZRelative.Size = new System.Drawing.Size(1195, 421);
            this.chartHistogramVoxelXYZRelative.TabIndex = 43;
            this.chartHistogramVoxelXYZRelative.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelXYZRelative, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelXYZRelative.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelY
            // 
            this.chartHistogramVoxelY.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelY.BorderlineWidth = 2;
            chartArea10.Name = "ChartArea1";
            this.chartHistogramVoxelY.ChartAreas.Add(chartArea10);
            this.chartHistogramVoxelY.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelY.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelY.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelY.Name = "chartHistogramVoxelY";
            this.chartHistogramVoxelY.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chartHistogramVoxelY.Size = new System.Drawing.Size(1195, 421);
            this.chartHistogramVoxelY.TabIndex = 37;
            this.chartHistogramVoxelY.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelY, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelY.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelZ
            // 
            this.chartHistogramVoxelZ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelZ.BorderlineWidth = 2;
            chartArea11.Name = "ChartArea1";
            this.chartHistogramVoxelZ.ChartAreas.Add(chartArea11);
            this.chartHistogramVoxelZ.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelZ.Location = new System.Drawing.Point(11, 228);
            this.chartHistogramVoxelZ.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelZ.Name = "chartHistogramVoxelZ";
            this.chartHistogramVoxelZ.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.ChartArea = "ChartArea1";
            series1.Name = "Series1";
            this.chartHistogramVoxelZ.Series.Add(series1);
            this.chartHistogramVoxelZ.Size = new System.Drawing.Size(1195, 416);
            this.chartHistogramVoxelZ.TabIndex = 38;
            this.chartHistogramVoxelZ.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelZ, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelZ.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // chartHistogramVoxelX
            // 
            this.chartHistogramVoxelX.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartHistogramVoxelX.BorderlineWidth = 2;
            chartArea12.Name = "ChartArea1";
            this.chartHistogramVoxelX.ChartAreas.Add(chartArea12);
            this.chartHistogramVoxelX.ContextMenuStrip = this.contextMenuStripHistogram;
            this.chartHistogramVoxelX.Location = new System.Drawing.Point(11, 229);
            this.chartHistogramVoxelX.Margin = new System.Windows.Forms.Padding(4);
            this.chartHistogramVoxelX.Name = "chartHistogramVoxelX";
            this.chartHistogramVoxelX.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chartHistogramVoxelX.Size = new System.Drawing.Size(1195, 421);
            this.chartHistogramVoxelX.TabIndex = 0;
            this.chartHistogramVoxelX.Text = "chart1";
            this.toolTip1.SetToolTip(this.chartHistogramVoxelX, "Настройки графика в контекстном меню");
            this.chartHistogramVoxelX.DoubleClick += new System.EventHandler(this.ChartHistogramVoxel_DoubleClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(157, 6);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "Ось Х, мм";
            this.toolTip1.SetToolTip(this.label14, "для центров/с учетом размеров вокселя");
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(300, 5);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "Ось Y, мм";
            this.toolTip1.SetToolTip(this.label13, "для центров/с учетом размеров вокселя");
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(444, 6);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Ось Z, мм";
            this.toolTip1.SetToolTip(this.label12, "для центров/с учетом размеров вокселя");
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 166);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 17);
            this.label8.TabIndex = 5;
            this.label8.Text = "Отклонения";
            this.toolTip1.SetToolTip(this.label8, "Отклонения по размерам (абс./отн.)");
            // 
            // textBoxTotalVoxRez
            // 
            this.textBoxTotalVoxRez.ForeColor = System.Drawing.Color.Red;
            this.textBoxTotalVoxRez.Location = new System.Drawing.Point(233, 209);
            this.textBoxTotalVoxRez.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTotalVoxRez.Name = "textBoxTotalVoxRez";
            this.textBoxTotalVoxRez.ReadOnly = true;
            this.textBoxTotalVoxRez.Size = new System.Drawing.Size(308, 22);
            this.textBoxTotalVoxRez.TabIndex = 25;
            this.textBoxTotalVoxRez.Text = "??? ??? ???";
            this.textBoxTotalVoxRez.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxTotalVoxRez, "Общее количество вокселей для заполнения объема");
            // 
            // checkBoxVox
            // 
            this.checkBoxVox.AutoSize = true;
            this.checkBoxVox.Checked = true;
            this.checkBoxVox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxVox.Location = new System.Drawing.Point(103, 162);
            this.checkBoxVox.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxVox.Name = "checkBoxVox";
            this.checkBoxVox.Size = new System.Drawing.Size(18, 17);
            this.checkBoxVox.TabIndex = 10;
            this.toolTip1.SetToolTip(this.checkBoxVox, "Вкл/откл. ReadOnly");
            this.checkBoxVox.UseVisualStyleBackColor = true;
            this.checkBoxVox.CheckedChanged += new System.EventHandler(this.CheckBox4_CheckedChanged);
            // 
            // numericUpDownVoxX
            // 
            this.numericUpDownVoxX.DecimalPlaces = 2;
            this.numericUpDownVoxX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownVoxX.Location = new System.Drawing.Point(135, 159);
            this.numericUpDownVoxX.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownVoxX.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownVoxX.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownVoxX.Name = "numericUpDownVoxX";
            this.numericUpDownVoxX.Size = new System.Drawing.Size(127, 22);
            this.numericUpDownVoxX.TabIndex = 11;
            this.numericUpDownVoxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownVoxX, "Размер вокселя по оси X");
            this.numericUpDownVoxX.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownVoxX.ValueChanged += new System.EventHandler(this.NumericUpDownVoxX_ValueChanged);
            // 
            // numericUpDownVoxY
            // 
            this.numericUpDownVoxY.DecimalPlaces = 2;
            this.numericUpDownVoxY.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownVoxY.Location = new System.Drawing.Point(279, 158);
            this.numericUpDownVoxY.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownVoxY.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownVoxY.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownVoxY.Name = "numericUpDownVoxY";
            this.numericUpDownVoxY.ReadOnly = true;
            this.numericUpDownVoxY.Size = new System.Drawing.Size(127, 22);
            this.numericUpDownVoxY.TabIndex = 12;
            this.numericUpDownVoxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownVoxY, "Размер вокселя по оси Y");
            this.numericUpDownVoxY.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownVoxY.ValueChanged += new System.EventHandler(this.NumericUpDownVoxX_ValueChanged);
            // 
            // numericUpDownVoxZ
            // 
            this.numericUpDownVoxZ.DecimalPlaces = 2;
            this.numericUpDownVoxZ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownVoxZ.Location = new System.Drawing.Point(423, 158);
            this.numericUpDownVoxZ.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownVoxZ.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownVoxZ.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownVoxZ.Name = "numericUpDownVoxZ";
            this.numericUpDownVoxZ.ReadOnly = true;
            this.numericUpDownVoxZ.Size = new System.Drawing.Size(127, 22);
            this.numericUpDownVoxZ.TabIndex = 13;
            this.numericUpDownVoxZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownVoxZ, "Размер вокселя по оси Z");
            this.numericUpDownVoxZ.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownVoxZ.ValueChanged += new System.EventHandler(this.NumericUpDownVoxX_ValueChanged);
            // 
            // textBoxTotalVox
            // 
            this.textBoxTotalVox.ForeColor = System.Drawing.Color.Red;
            this.textBoxTotalVox.Location = new System.Drawing.Point(276, 566);
            this.textBoxTotalVox.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTotalVox.Name = "textBoxTotalVox";
            this.textBoxTotalVox.ReadOnly = true;
            this.textBoxTotalVox.Size = new System.Drawing.Size(289, 22);
            this.textBoxTotalVox.TabIndex = 15;
            this.textBoxTotalVox.Text = "??? ??? ???";
            this.textBoxTotalVox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.textBoxTotalVox, "Общее количество вокселей для заполнения объема");
            // 
            // checkBoxAbsOrRel
            // 
            this.checkBoxAbsOrRel.AutoSize = true;
            this.checkBoxAbsOrRel.Location = new System.Drawing.Point(15, 492);
            this.checkBoxAbsOrRel.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxAbsOrRel.Name = "checkBoxAbsOrRel";
            this.checkBoxAbsOrRel.Size = new System.Drawing.Size(202, 21);
            this.checkBoxAbsOrRel.TabIndex = 29;
            this.checkBoxAbsOrRel.Text = "Относительные значения";
            this.toolTip1.SetToolTip(this.checkBoxAbsOrRel, "Анализ оценки сложности контура (абс./отн. исходные значения)");
            this.checkBoxAbsOrRel.UseVisualStyleBackColor = true;
            this.checkBoxAbsOrRel.CheckStateChanged += new System.EventHandler(this.CheckBoxAbsOrRel_CheckStateChanged);
            // 
            // labelCountInt
            // 
            this.labelCountInt.AutoSize = true;
            this.labelCountInt.Location = new System.Drawing.Point(20, 591);
            this.labelCountInt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCountInt.Name = "labelCountInt";
            this.labelCountInt.Size = new System.Drawing.Size(222, 17);
            this.labelCountInt.TabIndex = 28;
            this.labelCountInt.Text = "Кол-во интервалов гистограммы";
            this.toolTip1.SetToolTip(this.labelCountInt, "Количество интервалов для построения гистограмм");
            // 
            // numericUpDownCountFractalAnalysis
            // 
            this.numericUpDownCountFractalAnalysis.Enabled = false;
            this.numericUpDownCountFractalAnalysis.Location = new System.Drawing.Point(144, 551);
            this.numericUpDownCountFractalAnalysis.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownCountFractalAnalysis.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownCountFractalAnalysis.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownCountFractalAnalysis.Name = "numericUpDownCountFractalAnalysis";
            this.numericUpDownCountFractalAnalysis.Size = new System.Drawing.Size(112, 22);
            this.numericUpDownCountFractalAnalysis.TabIndex = 30;
            this.numericUpDownCountFractalAnalysis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownCountFractalAnalysis, "Количество итераций при определении фрактальной размерности");
            this.numericUpDownCountFractalAnalysis.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownCountFractalAnalysis.ValueChanged += new System.EventHandler(this.NumericUpDownCountFractalAnalysis_ValueChanged);
            // 
            // numericUpDownCurentFractalAnalysis
            // 
            this.numericUpDownCurentFractalAnalysis.Enabled = false;
            this.numericUpDownCurentFractalAnalysis.Location = new System.Drawing.Point(272, 551);
            this.numericUpDownCurentFractalAnalysis.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownCurentFractalAnalysis.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownCurentFractalAnalysis.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCurentFractalAnalysis.Name = "numericUpDownCurentFractalAnalysis";
            this.numericUpDownCurentFractalAnalysis.Size = new System.Drawing.Size(112, 22);
            this.numericUpDownCurentFractalAnalysis.TabIndex = 31;
            this.numericUpDownCurentFractalAnalysis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownCurentFractalAnalysis, "Номер меры для визуализации");
            this.numericUpDownCurentFractalAnalysis.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCurentFractalAnalysis.ValueChanged += new System.EventHandler(this.NumericUpDownCurentFractalAnalysis_ValueChanged);
            // 
            // labelCountContour
            // 
            this.labelCountContour.AutoSize = true;
            this.labelCountContour.Location = new System.Drawing.Point(4, 542);
            this.labelCountContour.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCountContour.Name = "labelCountContour";
            this.labelCountContour.Size = new System.Drawing.Size(166, 17);
            this.labelCountContour.TabIndex = 29;
            this.labelCountContour.Text = "Количество контуров: 0";
            this.toolTip1.SetToolTip(this.labelCountContour, "Обновляется по результатам стат.анализа");
            // 
            // numericUpDownRatioRtoL
            // 
            this.numericUpDownRatioRtoL.DecimalPlaces = 2;
            this.numericUpDownRatioRtoL.Enabled = false;
            this.numericUpDownRatioRtoL.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownRatioRtoL.Location = new System.Drawing.Point(15, 551);
            this.numericUpDownRatioRtoL.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDownRatioRtoL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownRatioRtoL.Name = "numericUpDownRatioRtoL";
            this.numericUpDownRatioRtoL.Size = new System.Drawing.Size(112, 22);
            this.numericUpDownRatioRtoL.TabIndex = 32;
            this.numericUpDownRatioRtoL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownRatioRtoL, "Отношение первой размерности к длине контура (или абсолютное значение меры)");
            this.numericUpDownRatioRtoL.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // checkBoxVisualAnalysis
            // 
            this.checkBoxVisualAnalysis.AutoSize = true;
            this.checkBoxVisualAnalysis.Enabled = false;
            this.checkBoxVisualAnalysis.Location = new System.Drawing.Point(15, 522);
            this.checkBoxVisualAnalysis.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxVisualAnalysis.Name = "checkBoxVisualAnalysis";
            this.checkBoxVisualAnalysis.Size = new System.Drawing.Size(280, 21);
            this.checkBoxVisualAnalysis.TabIndex = 33;
            this.checkBoxVisualAnalysis.Text = "Визуализация фрактального анализа";
            this.toolTip1.SetToolTip(this.checkBoxVisualAnalysis, "Визуализация анализа");
            this.checkBoxVisualAnalysis.UseVisualStyleBackColor = true;
            // 
            // checkBoxMethod
            // 
            this.checkBoxMethod.AutoSize = true;
            this.checkBoxMethod.Checked = true;
            this.checkBoxMethod.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxMethod.Location = new System.Drawing.Point(227, 493);
            this.checkBoxMethod.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxMethod.Name = "checkBoxMethod";
            this.checkBoxMethod.Size = new System.Drawing.Size(148, 21);
            this.checkBoxMethod.TabIndex = 34;
            this.checkBoxMethod.Text = "Клеточный метод";
            this.toolTip1.SetToolTip(this.checkBoxMethod, "Метод фрактального анализа");
            this.checkBoxMethod.UseVisualStyleBackColor = true;
            this.checkBoxMethod.CheckStateChanged += new System.EventHandler(this.CheckBoxMethod_CheckStateChanged);
            // 
            // contextMenuStripdataGrid
            // 
            this.contextMenuStripdataGrid.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStripdataGrid.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemShow,
            this.toolStripMenuItemReduce});
            this.contextMenuStripdataGrid.Name = "contextMenuStripdataGrid";
            this.contextMenuStripdataGrid.Size = new System.Drawing.Size(231, 52);
            // 
            // toolStripMenuItemShow
            // 
            this.toolStripMenuItemShow.Name = "toolStripMenuItemShow";
            this.toolStripMenuItemShow.Size = new System.Drawing.Size(230, 24);
            this.toolStripMenuItemShow.Text = "Развернуть";
            this.toolStripMenuItemShow.Click += new System.EventHandler(this.ToolStripMenuItemShow_Click);
            // 
            // toolStripMenuItemReduce
            // 
            this.toolStripMenuItemReduce.Name = "toolStripMenuItemReduce";
            this.toolStripMenuItemReduce.Size = new System.Drawing.Size(230, 24);
            this.toolStripMenuItemReduce.Text = "Исходное положение";
            this.toolStripMenuItemReduce.Click += new System.EventHandler(this.ToolStripMenuItemReduce_Click);
            // 
            // colorDialogSelect
            // 
            this.colorDialogSelect.AnyColor = true;
            this.colorDialogSelect.FullOpen = true;
            // 
            // AnalLayer
            // 
            this.AnalLayer.Controls.Add(this.checkBoxAnalysisErrorForm);
            this.AnalLayer.Controls.Add(this.dataGridViewSetLayer);
            this.AnalLayer.Controls.Add(this.checkBoxFractalAnalysis);
            this.AnalLayer.Controls.Add(this.checkBoxMethod);
            this.AnalLayer.Controls.Add(this.checkBoxVisualAnalysis);
            this.AnalLayer.Controls.Add(this.numericUpDownRatioRtoL);
            this.AnalLayer.Controls.Add(this.numericUpDownCurentFractalAnalysis);
            this.AnalLayer.Controls.Add(this.numericUpDownCountFractalAnalysis);
            this.AnalLayer.Controls.Add(this.checkBoxAbsOrRel);
            this.AnalLayer.Controls.Add(this.statusStripLayerAnalysis);
            this.AnalLayer.Controls.Add(this.labelCountInt);
            this.AnalLayer.Controls.Add(this.numericUpDownLayerInt);
            this.AnalLayer.Controls.Add(this.checkBoxOneOrAll);
            this.AnalLayer.Controls.Add(this.checkBoxPreview);
            this.AnalLayer.Controls.Add(this.panelReviewContourSection);
            this.AnalLayer.Controls.Add(this.toolStripLayerAnalysis);
            this.AnalLayer.Location = new System.Drawing.Point(4, 25);
            this.AnalLayer.Margin = new System.Windows.Forms.Padding(4);
            this.AnalLayer.Name = "AnalLayer";
            this.AnalLayer.Padding = new System.Windows.Forms.Padding(4);
            this.AnalLayer.Size = new System.Drawing.Size(1219, 658);
            this.AnalLayer.TabIndex = 10;
            this.AnalLayer.Text = "Послойный анализ";
            this.AnalLayer.UseVisualStyleBackColor = true;
            // 
            // dataGridViewSetLayer
            // 
            this.dataGridViewSetLayer.AllowUserToAddRows = false;
            this.dataGridViewSetLayer.AllowUserToDeleteRows = false;
            this.dataGridViewSetLayer.AllowUserToResizeColumns = false;
            this.dataGridViewSetLayer.AllowUserToResizeRows = false;
            this.dataGridViewSetLayer.CausesValidation = false;
            this.dataGridViewSetLayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSetLayer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NumLayer,
            this.HeightLayer,
            this.HeightPlaсement,
            this.P,
            this.Ssection,
            this.centroidOfArea,
            this.Delta,
            this.Fractal_Size_Scale,
            this.Fractal_Size_Square,
            this.Nz,
            this.Aadjacent,
            this.NzMinInterval,
            this.NzMaxInterval,
            this.NzRange,
            this.NzDispersion,
            this.NzSigma,
            this.NzMean,
            this.NzKasim,
            this.NzKeks,
            this.NzKv,
            this.NzMeana,
            this.NzModa,
            this.NzMediana,
            this.AMinInterval,
            this.AMaxInterval,
            this.ARange,
            this.ADispersion,
            this.ASigma,
            this.AMean,
            this.AKasim,
            this.AKeks,
            this.AKv,
            this.AMeana,
            this.AModa,
            this.AMediana,
            this.EMinInterval,
            this.EMaxInterval,
            this.ERange,
            this.EDispersion,
            this.ESigma,
            this.EMean,
            this.EKasim,
            this.EKeks,
            this.EKv,
            this.EMeana,
            this.EModa,
            this.EMediana});
            this.dataGridViewSetLayer.ContextMenuStrip = this.contextMenuStripdataGrid;
            this.dataGridViewSetLayer.Location = new System.Drawing.Point(15, 44);
            this.dataGridViewSetLayer.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewSetLayer.MultiSelect = false;
            this.dataGridViewSetLayer.Name = "dataGridViewSetLayer";
            this.dataGridViewSetLayer.ReadOnly = true;
            this.dataGridViewSetLayer.RowHeadersVisible = false;
            this.dataGridViewSetLayer.Size = new System.Drawing.Size(368, 383);
            this.dataGridViewSetLayer.TabIndex = 16;
            this.dataGridViewSetLayer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewSetLayer_CellClick);
            this.dataGridViewSetLayer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewSetLayer_CellDoubleClick);
            this.dataGridViewSetLayer.ColumnHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGridViewSetLayer_ColumnHeaderMouseDoubleClick);
            this.dataGridViewSetLayer.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewSetLayer_RowEnter);
            // 
            // checkBoxFractalAnalysis
            // 
            this.checkBoxFractalAnalysis.AutoSize = true;
            this.checkBoxFractalAnalysis.Location = new System.Drawing.Point(227, 466);
            this.checkBoxFractalAnalysis.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxFractalAnalysis.Name = "checkBoxFractalAnalysis";
            this.checkBoxFractalAnalysis.Size = new System.Drawing.Size(173, 21);
            this.checkBoxFractalAnalysis.TabIndex = 35;
            this.checkBoxFractalAnalysis.Text = "Фрактальный анализ";
            this.checkBoxFractalAnalysis.UseVisualStyleBackColor = true;
            // 
            // statusStripLayerAnalysis
            // 
            this.statusStripLayerAnalysis.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStripLayerAnalysis.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarLayerAnalysis,
            this.toolStripStatusLabelLayerAnalysis});
            this.statusStripLayerAnalysis.Location = new System.Drawing.Point(4, 625);
            this.statusStripLayerAnalysis.Name = "statusStripLayerAnalysis";
            this.statusStripLayerAnalysis.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStripLayerAnalysis.Size = new System.Drawing.Size(1211, 29);
            this.statusStripLayerAnalysis.TabIndex = 15;
            this.statusStripLayerAnalysis.Text = "statusStrip6";
            // 
            // toolStripProgressBarLayerAnalysis
            // 
            this.toolStripProgressBarLayerAnalysis.Name = "toolStripProgressBarLayerAnalysis";
            this.toolStripProgressBarLayerAnalysis.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarLayerAnalysis.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // toolStripStatusLabelLayerAnalysis
            // 
            this.toolStripStatusLabelLayerAnalysis.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelLayerAnalysis.Name = "toolStripStatusLabelLayerAnalysis";
            this.toolStripStatusLabelLayerAnalysis.Size = new System.Drawing.Size(153, 24);
            this.toolStripStatusLabelLayerAnalysis.Text = "Расчет не выполнен.";
            // 
            // panelReviewContourSection
            // 
            this.panelReviewContourSection.AutoScroll = true;
            this.panelReviewContourSection.BackColor = System.Drawing.Color.OldLace;
            this.panelReviewContourSection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelReviewContourSection.Controls.Add(this.labelCountContour);
            this.panelReviewContourSection.Location = new System.Drawing.Point(401, 44);
            this.panelReviewContourSection.Margin = new System.Windows.Forms.Padding(4);
            this.panelReviewContourSection.Name = "panelReviewContourSection";
            this.panelReviewContourSection.Size = new System.Drawing.Size(799, 566);
            this.panelReviewContourSection.TabIndex = 17;
            this.panelReviewContourSection.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelReviewContourSection_Paint);
            // 
            // toolStripLayerAnalysis
            // 
            this.toolStripLayerAnalysis.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripLayerAnalysis.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonLayerCreate,
            this.toolStripSeparator55,
            this.toolStripComboBoxLayerAnalysis,
            this.toolStripSeparator56,
            this.toolStripTextBoxMinStep,
            this.toolStripSeparator57,
            this.toolStripTextBoxMaxStep,
            this.toolStripSeparator38,
            this.toolStripTextBoxError,
            this.toolStripSeparator70,
            this.toolStripTextBoxLimitF,
            this.toolStripComboBoxTypeTrim,
            this.toolStripSeparator61,
            this.toolStripSeparator67,
            this.toolStripButtonColorLine,
            this.toolStripSeparator68,
            this.toolStripComboBoxScale,
            this.toolStripSeparator58,
            this.toolStripSeparator59,
            this.toolStripButtonLayerAnalysis,
            this.toolStripSeparator60,
            this.toolStripSeparator69,
            this.toolStripButtonLayerSave,
            this.toolStripSeparator64,
            this.toolStripComboBoxCountColumnForSave});
            this.toolStripLayerAnalysis.Location = new System.Drawing.Point(4, 4);
            this.toolStripLayerAnalysis.Name = "toolStripLayerAnalysis";
            this.toolStripLayerAnalysis.Size = new System.Drawing.Size(1211, 32);
            this.toolStripLayerAnalysis.TabIndex = 14;
            this.toolStripLayerAnalysis.Text = "toolStrip3";
            // 
            // toolStripButtonLayerCreate
            // 
            this.toolStripButtonLayerCreate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLayerCreate.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLayerCreate.Image")));
            this.toolStripButtonLayerCreate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLayerCreate.Name = "toolStripButtonLayerCreate";
            this.toolStripButtonLayerCreate.Size = new System.Drawing.Size(92, 29);
            this.toolStripButtonLayerCreate.Text = "Рассекание";
            this.toolStripButtonLayerCreate.ToolTipText = "Формирование слоев по заданной стратегии";
            this.toolStripButtonLayerCreate.Click += new System.EventHandler(this.ToolStripButtonLayerCreate_Click);
            // 
            // toolStripSeparator55
            // 
            this.toolStripSeparator55.Name = "toolStripSeparator55";
            this.toolStripSeparator55.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripComboBoxLayerAnalysis
            // 
            this.toolStripComboBoxLayerAnalysis.DropDownWidth = 350;
            this.toolStripComboBoxLayerAnalysis.Items.AddRange(new object[] {
            "Постоянный шаг",
            "Переменный шаг (упрощенный расчет)",
            "Переменный шаг (по микросечениям)",
            "Переменный шаг (усечение интервала углов)"});
            this.toolStripComboBoxLayerAnalysis.MaxDropDownItems = 16;
            this.toolStripComboBoxLayerAnalysis.Name = "toolStripComboBoxLayerAnalysis";
            this.toolStripComboBoxLayerAnalysis.Size = new System.Drawing.Size(239, 32);
            this.toolStripComboBoxLayerAnalysis.Text = "Постоянный шаг";
            this.toolStripComboBoxLayerAnalysis.ToolTipText = "Выбор стратегии задания шага построения";
            // 
            // toolStripSeparator56
            // 
            this.toolStripSeparator56.Name = "toolStripSeparator56";
            this.toolStripSeparator56.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripTextBoxMinStep
            // 
            this.toolStripTextBoxMinStep.MaxLength = 10;
            this.toolStripTextBoxMinStep.Name = "toolStripTextBoxMinStep";
            this.toolStripTextBoxMinStep.Size = new System.Drawing.Size(45, 32);
            this.toolStripTextBoxMinStep.Text = "0,1";
            this.toolStripTextBoxMinStep.ToolTipText = "Минимальный шаг построения";
            this.toolStripTextBoxMinStep.TextChanged += new System.EventHandler(this.ToolStripTextBoxMinStep_TextChanged);
            // 
            // toolStripSeparator57
            // 
            this.toolStripSeparator57.Name = "toolStripSeparator57";
            this.toolStripSeparator57.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripTextBoxMaxStep
            // 
            this.toolStripTextBoxMaxStep.MaxLength = 10;
            this.toolStripTextBoxMaxStep.Name = "toolStripTextBoxMaxStep";
            this.toolStripTextBoxMaxStep.Size = new System.Drawing.Size(45, 32);
            this.toolStripTextBoxMaxStep.Text = "0,3";
            this.toolStripTextBoxMaxStep.ToolTipText = "Максимальный шаг построения";
            this.toolStripTextBoxMaxStep.TextChanged += new System.EventHandler(this.ToolStripTextBoxMinStep_TextChanged);
            // 
            // toolStripSeparator38
            // 
            this.toolStripSeparator38.Name = "toolStripSeparator38";
            this.toolStripSeparator38.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripTextBoxError
            // 
            this.toolStripTextBoxError.MaxLength = 10;
            this.toolStripTextBoxError.Name = "toolStripTextBoxError";
            this.toolStripTextBoxError.Size = new System.Drawing.Size(72, 32);
            this.toolStripTextBoxError.Text = "0,1 мм";
            this.toolStripTextBoxError.ToolTipText = "Максимальная величина отклонения формы";
            this.toolStripTextBoxError.TextChanged += new System.EventHandler(this.ToolStripTextBoxError_TextChanged);
            // 
            // toolStripSeparator70
            // 
            this.toolStripSeparator70.Name = "toolStripSeparator70";
            this.toolStripSeparator70.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripTextBoxLimitF
            // 
            this.toolStripTextBoxLimitF.MaxLength = 10;
            this.toolStripTextBoxLimitF.Name = "toolStripTextBoxLimitF";
            this.toolStripTextBoxLimitF.Size = new System.Drawing.Size(59, 32);
            this.toolStripTextBoxLimitF.Text = "5 %";
            this.toolStripTextBoxLimitF.ToolTipText = "Величина относительного усечения гистограммы по площади поверхности";
            this.toolStripTextBoxLimitF.TextChanged += new System.EventHandler(this.ToolStripTextBoxLimitF_TextChanged);
            // 
            // toolStripComboBoxTypeTrim
            // 
            this.toolStripComboBoxTypeTrim.DropDownHeight = 80;
            this.toolStripComboBoxTypeTrim.IntegralHeight = false;
            this.toolStripComboBoxTypeTrim.Items.AddRange(new object[] {
            "Мин. и макс. углы",
            "Мин. углы",
            "Макс. углы"});
            this.toolStripComboBoxTypeTrim.MaxDropDownItems = 3;
            this.toolStripComboBoxTypeTrim.Name = "toolStripComboBoxTypeTrim";
            this.toolStripComboBoxTypeTrim.Size = new System.Drawing.Size(165, 32);
            this.toolStripComboBoxTypeTrim.Text = "Мин. и макс. углы";
            this.toolStripComboBoxTypeTrim.ToolTipText = "Вид усечения гистограммы распределения углов наклона нормалей";
            // 
            // toolStripSeparator61
            // 
            this.toolStripSeparator61.Name = "toolStripSeparator61";
            this.toolStripSeparator61.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripSeparator67
            // 
            this.toolStripSeparator67.Name = "toolStripSeparator67";
            this.toolStripSeparator67.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripButtonColorLine
            // 
            this.toolStripButtonColorLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonColorLine.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonColorLine.Image")));
            this.toolStripButtonColorLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColorLine.Name = "toolStripButtonColorLine";
            this.toolStripButtonColorLine.Size = new System.Drawing.Size(46, 29);
            this.toolStripButtonColorLine.Text = "Цвет";
            this.toolStripButtonColorLine.ToolTipText = "Цвет контура";
            this.toolStripButtonColorLine.Click += new System.EventHandler(this.ToolStripButtonColorLine_Click);
            // 
            // toolStripSeparator68
            // 
            this.toolStripSeparator68.Name = "toolStripSeparator68";
            this.toolStripSeparator68.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripComboBoxScale
            // 
            this.toolStripComboBoxScale.Items.AddRange(new object[] {
            "0,1",
            "0,2",
            "0,3",
            "0,4",
            "0,5",
            "1,0",
            "1,5",
            "2,0",
            "4,0",
            "5,0",
            "8,0",
            "10"});
            this.toolStripComboBoxScale.Name = "toolStripComboBoxScale";
            this.toolStripComboBoxScale.Size = new System.Drawing.Size(99, 32);
            this.toolStripComboBoxScale.Text = "1,0";
            this.toolStripComboBoxScale.ToolTipText = "Масштаб отображения";
            this.toolStripComboBoxScale.TextChanged += new System.EventHandler(this.ToolStripComboBoxScale_TextChanged);
            // 
            // toolStripSeparator58
            // 
            this.toolStripSeparator58.Name = "toolStripSeparator58";
            this.toolStripSeparator58.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripSeparator59
            // 
            this.toolStripSeparator59.Name = "toolStripSeparator59";
            this.toolStripSeparator59.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripButtonLayerAnalysis
            // 
            this.toolStripButtonLayerAnalysis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLayerAnalysis.Enabled = false;
            this.toolStripButtonLayerAnalysis.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLayerAnalysis.Image")));
            this.toolStripButtonLayerAnalysis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLayerAnalysis.Name = "toolStripButtonLayerAnalysis";
            this.toolStripButtonLayerAnalysis.Size = new System.Drawing.Size(64, 29);
            this.toolStripButtonLayerAnalysis.Text = "Анализ";
            this.toolStripButtonLayerAnalysis.ToolTipText = "Статистический анализ ";
            this.toolStripButtonLayerAnalysis.Click += new System.EventHandler(this.ToolStripButtonLayerAnalysis_Click);
            // 
            // toolStripSeparator60
            // 
            this.toolStripSeparator60.Name = "toolStripSeparator60";
            this.toolStripSeparator60.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripSeparator69
            // 
            this.toolStripSeparator69.Name = "toolStripSeparator69";
            this.toolStripSeparator69.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripButtonLayerSave
            // 
            this.toolStripButtonLayerSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLayerSave.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLayerSave.Image")));
            this.toolStripButtonLayerSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLayerSave.Name = "toolStripButtonLayerSave";
            this.toolStripButtonLayerSave.Size = new System.Drawing.Size(87, 29);
            this.toolStripButtonLayerSave.Text = "Сохранить";
            this.toolStripButtonLayerSave.ToolTipText = "Сохранить данные анализа в файл XLS-формата";
            this.toolStripButtonLayerSave.Click += new System.EventHandler(this.ToolStripButtonLayerSave_Click);
            // 
            // toolStripSeparator64
            // 
            this.toolStripSeparator64.Name = "toolStripSeparator64";
            this.toolStripSeparator64.Size = new System.Drawing.Size(6, 32);
            // 
            // toolStripComboBoxCountColumnForSave
            // 
            this.toolStripComboBoxCountColumnForSave.AutoToolTip = true;
            this.toolStripComboBoxCountColumnForSave.Items.AddRange(new object[] {
            "5",
            "7",
            "9",
            "23",
            "35",
            "47"});
            this.toolStripComboBoxCountColumnForSave.Name = "toolStripComboBoxCountColumnForSave";
            this.toolStripComboBoxCountColumnForSave.Size = new System.Drawing.Size(75, 28);
            this.toolStripComboBoxCountColumnForSave.Text = "5";
            this.toolStripComboBoxCountColumnForSave.ToolTipText = "Количество колонок для сохранения данных";
            // 
            // AnalColorVisual
            // 
            this.AnalColorVisual.Controls.Add(this.statusStrip2);
            this.AnalColorVisual.Controls.Add(this.buttonXls);
            this.AnalColorVisual.Controls.Add(this.label40);
            this.AnalColorVisual.Controls.Add(this.label21);
            this.AnalColorVisual.Controls.Add(this.panel5);
            this.AnalColorVisual.Controls.Add(this.label52);
            this.AnalColorVisual.Controls.Add(this.panel6);
            this.AnalColorVisual.Controls.Add(this.dataGridViewVariantsVisualization);
            this.AnalColorVisual.Controls.Add(this.toolStripColorVisual);
            this.AnalColorVisual.Location = new System.Drawing.Point(4, 25);
            this.AnalColorVisual.Margin = new System.Windows.Forms.Padding(4);
            this.AnalColorVisual.Name = "AnalColorVisual";
            this.AnalColorVisual.Padding = new System.Windows.Forms.Padding(4);
            this.AnalColorVisual.Size = new System.Drawing.Size(1219, 658);
            this.AnalColorVisual.TabIndex = 5;
            this.AnalColorVisual.Text = "Цветовая визуализация модели";
            this.AnalColorVisual.UseVisualStyleBackColor = true;
            this.AnalColorVisual.Click += new System.EventHandler(this.AnalColorVisual_Click);
            this.AnalColorVisual.Enter += new System.EventHandler(this.AnalColorVisual_Enter);
            // 
            // statusStrip2
            // 
            this.statusStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarVisualization,
            this.toolStripStatusLabelColorVisual});
            this.statusStrip2.Location = new System.Drawing.Point(4, 625);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip2.Size = new System.Drawing.Size(1211, 29);
            this.statusStrip2.TabIndex = 12;
            this.statusStrip2.Text = "statusStrip2";
            // 
            // toolStripProgressBarVisualization
            // 
            this.toolStripProgressBarVisualization.Name = "toolStripProgressBarVisualization";
            this.toolStripProgressBarVisualization.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarVisualization.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // toolStripStatusLabelColorVisual
            // 
            this.toolStripStatusLabelColorVisual.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelColorVisual.Name = "toolStripStatusLabelColorVisual";
            this.toolStripStatusLabelColorVisual.Size = new System.Drawing.Size(153, 24);
            this.toolStripStatusLabelColorVisual.Text = "Расчет не выполнен.";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label40.Location = new System.Drawing.Point(25, 226);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(757, 17);
            this.label40.TabIndex = 42;
            this.label40.Text = "Варианты визуализации и статистические характеристики распределения исследуемого " +
    "признака";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(565, 38);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(499, 17);
            this.label21.TabIndex = 41;
            this.label21.Text = "Цветовая шкала соответсвия значениям исследуемого признака";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dataGridViewIntervals);
            this.panel5.Location = new System.Drawing.Point(547, 49);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(658, 172);
            this.panel5.TabIndex = 40;
            // 
            // dataGridViewIntervals
            // 
            this.dataGridViewIntervals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIntervals.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Begin,
            this.R,
            this.G,
            this.B,
            this.H,
            this.S,
            this.V,
            this.SetColor});
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewIntervals.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewIntervals.Location = new System.Drawing.Point(4, 6);
            this.dataGridViewIntervals.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewIntervals.Name = "dataGridViewIntervals";
            this.dataGridViewIntervals.Size = new System.Drawing.Size(648, 160);
            this.dataGridViewIntervals.TabIndex = 0;
            this.dataGridViewIntervals.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewIntervals_CellClick);
            // 
            // Begin
            // 
            this.Begin.HeaderText = "Начало интервала";
            this.Begin.MaxInputLength = 10;
            this.Begin.MinimumWidth = 100;
            this.Begin.Name = "Begin";
            this.Begin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Begin.Width = 125;
            // 
            // R
            // 
            this.R.HeaderText = "R";
            this.R.MaxInputLength = 3;
            this.R.MinimumWidth = 20;
            this.R.Name = "R";
            this.R.ReadOnly = true;
            this.R.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.R.Width = 40;
            // 
            // G
            // 
            this.G.HeaderText = "G";
            this.G.MaxInputLength = 3;
            this.G.MinimumWidth = 20;
            this.G.Name = "G";
            this.G.ReadOnly = true;
            this.G.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.G.Width = 40;
            // 
            // B
            // 
            this.B.HeaderText = "B";
            this.B.MaxInputLength = 3;
            this.B.MinimumWidth = 20;
            this.B.Name = "B";
            this.B.ReadOnly = true;
            this.B.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.B.Width = 40;
            // 
            // H
            // 
            this.H.HeaderText = "H";
            this.H.MaxInputLength = 3;
            this.H.MinimumWidth = 20;
            this.H.Name = "H";
            this.H.ReadOnly = true;
            this.H.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.H.Width = 40;
            // 
            // S
            // 
            this.S.HeaderText = "S";
            this.S.MaxInputLength = 3;
            this.S.MinimumWidth = 20;
            this.S.Name = "S";
            this.S.ReadOnly = true;
            this.S.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.S.Width = 35;
            // 
            // V
            // 
            this.V.HeaderText = "V";
            this.V.MaxInputLength = 3;
            this.V.MinimumWidth = 20;
            this.V.Name = "V";
            this.V.ReadOnly = true;
            this.V.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.V.Width = 40;
            // 
            // SetColor
            // 
            this.SetColor.HeaderText = "Задание цвета";
            this.SetColor.MinimumWidth = 60;
            this.SetColor.Name = "SetColor";
            this.SetColor.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.SetColor.Width = 90;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label52.Location = new System.Drawing.Point(25, 38);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(283, 17);
            this.label52.TabIndex = 39;
            this.label52.Text = "Исходные данные для визуализации";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.checkBoxGist);
            this.panel6.Controls.Add(this.numericUpDownStep);
            this.panel6.Controls.Add(this.labelStep);
            this.panel6.Controls.Add(this.numericUpDownB2);
            this.panel6.Controls.Add(this.numericUpDownG2);
            this.panel6.Controls.Add(this.numericUpDownR2);
            this.panel6.Controls.Add(this.labelRGB2);
            this.panel6.Controls.Add(this.numericUpDownB1);
            this.panel6.Controls.Add(this.numericUpDownG1);
            this.panel6.Controls.Add(this.numericUpDownR1);
            this.panel6.Controls.Add(this.label53);
            this.panel6.Controls.Add(this.textBoxSizeInt);
            this.panel6.Controls.Add(this.textBoxRazmahPar);
            this.panel6.Controls.Add(this.numericUpDownIntVisual);
            this.panel6.Controls.Add(this.label55);
            this.panel6.Controls.Add(this.labelRGB1);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.label58);
            this.panel6.Location = new System.Drawing.Point(11, 49);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(527, 172);
            this.panel6.TabIndex = 38;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label53.ForeColor = System.Drawing.Color.Blue;
            this.label53.Location = new System.Drawing.Point(448, 6);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(18, 17);
            this.label53.TabIndex = 1;
            this.label53.Text = "B";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 105);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(167, 17);
            this.label55.TabIndex = 4;
            this.label55.Text = "Количество интервалов";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label57.ForeColor = System.Drawing.Color.Green;
            this.label57.Location = new System.Drawing.Point(340, 6);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(20, 17);
            this.label57.TabIndex = 1;
            this.label57.Text = "G";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label58.ForeColor = System.Drawing.Color.Red;
            this.label58.Location = new System.Drawing.Point(232, 6);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(19, 17);
            this.label58.TabIndex = 0;
            this.label58.Text = "R";
            // 
            // dataGridViewVariantsVisualization
            // 
            this.dataGridViewVariantsVisualization.AllowUserToAddRows = false;
            this.dataGridViewVariantsVisualization.AllowUserToDeleteRows = false;
            this.dataGridViewVariantsVisualization.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVariantsVisualization.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NomVar,
            this.Parametr,
            this.NameFile,
            this.ButtonOpenFile,
            this.ReviewGist,
            this.R1,
            this.G1,
            this.B1,
            this.R2,
            this.G2,
            this.B2,
            this.ColIntervals,
            this.MinInterval,
            this.MaxInterval,
            this.Range,
            this.Dispersion,
            this.Sigma,
            this.Mean,
            this.Kasim,
            this.Keks,
            this.Kv,
            this.Meana,
            this.Moda,
            this.Mediana});
            this.dataGridViewVariantsVisualization.Location = new System.Drawing.Point(11, 246);
            this.dataGridViewVariantsVisualization.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewVariantsVisualization.Name = "dataGridViewVariantsVisualization";
            this.dataGridViewVariantsVisualization.ReadOnly = true;
            this.dataGridViewVariantsVisualization.Size = new System.Drawing.Size(1195, 373);
            this.dataGridViewVariantsVisualization.TabIndex = 11;
            this.dataGridViewVariantsVisualization.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewVariantsVisualization_CellClick);
            // 
            // NomVar
            // 
            this.NomVar.HeaderText = "Вариант";
            this.NomVar.MaxInputLength = 10;
            this.NomVar.MinimumWidth = 25;
            this.NomVar.Name = "NomVar";
            this.NomVar.ReadOnly = true;
            this.NomVar.Width = 60;
            // 
            // Parametr
            // 
            this.Parametr.HeaderText = "Исслед. параметр";
            this.Parametr.MaxInputLength = 120;
            this.Parametr.Name = "Parametr";
            this.Parametr.ReadOnly = true;
            this.Parametr.Width = 250;
            // 
            // NameFile
            // 
            this.NameFile.HeaderText = "Имя файла";
            this.NameFile.MaxInputLength = 327;
            this.NameFile.MinimumWidth = 50;
            this.NameFile.Name = "NameFile";
            this.NameFile.ReadOnly = true;
            this.NameFile.Width = 220;
            // 
            // ButtonOpenFile
            // 
            this.ButtonOpenFile.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ButtonOpenFile.HeaderText = "Модель";
            this.ButtonOpenFile.MinimumWidth = 50;
            this.ButtonOpenFile.Name = "ButtonOpenFile";
            this.ButtonOpenFile.ReadOnly = true;
            this.ButtonOpenFile.Width = 110;
            // 
            // ReviewGist
            // 
            this.ReviewGist.HeaderText = "Гистограмма";
            this.ReviewGist.MinimumWidth = 35;
            this.ReviewGist.Name = "ReviewGist";
            this.ReviewGist.ReadOnly = true;
            this.ReviewGist.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ReviewGist.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ReviewGist.Width = 80;
            // 
            // R1
            // 
            this.R1.HeaderText = "R1";
            this.R1.MaxInputLength = 3;
            this.R1.MinimumWidth = 35;
            this.R1.Name = "R1";
            this.R1.ReadOnly = true;
            this.R1.Width = 40;
            // 
            // G1
            // 
            this.G1.HeaderText = "G1";
            this.G1.MaxInputLength = 3;
            this.G1.MinimumWidth = 35;
            this.G1.Name = "G1";
            this.G1.ReadOnly = true;
            this.G1.Width = 40;
            // 
            // B1
            // 
            this.B1.HeaderText = "B1";
            this.B1.MaxInputLength = 3;
            this.B1.MinimumWidth = 35;
            this.B1.Name = "B1";
            this.B1.ReadOnly = true;
            this.B1.Width = 40;
            // 
            // R2
            // 
            this.R2.HeaderText = "R2";
            this.R2.MinimumWidth = 35;
            this.R2.Name = "R2";
            this.R2.ReadOnly = true;
            this.R2.Width = 40;
            // 
            // G2
            // 
            this.G2.HeaderText = "G2";
            this.G2.MinimumWidth = 35;
            this.G2.Name = "G2";
            this.G2.ReadOnly = true;
            this.G2.Width = 40;
            // 
            // B2
            // 
            this.B2.HeaderText = "B2";
            this.B2.MinimumWidth = 35;
            this.B2.Name = "B2";
            this.B2.ReadOnly = true;
            this.B2.Width = 40;
            // 
            // ColIntervals
            // 
            this.ColIntervals.HeaderText = "Кол.интерв.";
            this.ColIntervals.MaxInputLength = 3;
            this.ColIntervals.Name = "ColIntervals";
            this.ColIntervals.ReadOnly = true;
            this.ColIntervals.Width = 80;
            // 
            // MinInterval
            // 
            this.MinInterval.HeaderText = "Мин.";
            this.MinInterval.MaxInputLength = 30;
            this.MinInterval.MinimumWidth = 35;
            this.MinInterval.Name = "MinInterval";
            this.MinInterval.ReadOnly = true;
            this.MinInterval.Width = 80;
            // 
            // MaxInterval
            // 
            this.MaxInterval.HeaderText = "Макс.";
            this.MaxInterval.MaxInputLength = 30;
            this.MaxInterval.MinimumWidth = 35;
            this.MaxInterval.Name = "MaxInterval";
            this.MaxInterval.ReadOnly = true;
            this.MaxInterval.Width = 80;
            // 
            // Range
            // 
            this.Range.HeaderText = "Размах";
            this.Range.Name = "Range";
            this.Range.ReadOnly = true;
            // 
            // Dispersion
            // 
            this.Dispersion.HeaderText = "Дисперсия";
            this.Dispersion.Name = "Dispersion";
            this.Dispersion.ReadOnly = true;
            // 
            // Sigma
            // 
            this.Sigma.HeaderText = "Среднекв.отклон.";
            this.Sigma.Name = "Sigma";
            this.Sigma.ReadOnly = true;
            // 
            // Mean
            // 
            this.Mean.HeaderText = "Ср. арифмет.";
            this.Mean.Name = "Mean";
            this.Mean.ReadOnly = true;
            // 
            // Kasim
            // 
            this.Kasim.HeaderText = "Коэф.асиметрии";
            this.Kasim.MaxInputLength = 32;
            this.Kasim.Name = "Kasim";
            this.Kasim.ReadOnly = true;
            this.Kasim.Width = 120;
            // 
            // Keks
            // 
            this.Keks.HeaderText = "Коэф. эксцесса";
            this.Keks.MaxInputLength = 32;
            this.Keks.Name = "Keks";
            this.Keks.ReadOnly = true;
            this.Keks.Width = 120;
            // 
            // Kv
            // 
            this.Kv.HeaderText = "Коэф. вариации";
            this.Kv.MaxInputLength = 32;
            this.Kv.Name = "Kv";
            this.Kv.ReadOnly = true;
            this.Kv.Width = 120;
            // 
            // Meana
            // 
            this.Meana.HeaderText = "Меана";
            this.Meana.Name = "Meana";
            this.Meana.ReadOnly = true;
            // 
            // Moda
            // 
            this.Moda.HeaderText = "Мода";
            this.Moda.Name = "Moda";
            this.Moda.ReadOnly = true;
            // 
            // Mediana
            // 
            this.Mediana.HeaderText = "Медиана";
            this.Mediana.Name = "Mediana";
            this.Mediana.ReadOnly = true;
            // 
            // toolStripColorVisual
            // 
            this.toolStripColorVisual.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripColorVisual.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonСalculate,
            this.toolStripSeparator23,
            this.toolStripComboBoxStrategicVisual,
            this.toolStripSeparator26,
            this.toolStripButtonColorVisual,
            this.toolStripSeparator30,
            this.toolStripSeparator29,
            this.toolStripButtonSavePLY,
            this.toolStripSeparator27,
            this.toolStripSeparator28,
            this.toolStripComboBoxSelestFormatFile});
            this.toolStripColorVisual.Location = new System.Drawing.Point(4, 4);
            this.toolStripColorVisual.Name = "toolStripColorVisual";
            this.toolStripColorVisual.Size = new System.Drawing.Size(1211, 28);
            this.toolStripColorVisual.TabIndex = 10;
            this.toolStripColorVisual.Text = "toolStrip3";
            // 
            // toolStripButtonСalculate
            // 
            this.toolStripButtonСalculate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonСalculate.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonСalculate.Image")));
            this.toolStripButtonСalculate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonСalculate.Name = "toolStripButtonСalculate";
            this.toolStripButtonСalculate.Size = new System.Drawing.Size(235, 25);
            this.toolStripButtonСalculate.Text = "Анализ исследуемого признака";
            this.toolStripButtonСalculate.ToolTipText = "Статистический анализ исследуемого признака";
            this.toolStripButtonСalculate.Click += new System.EventHandler(this.ToolStripButtonColorVisual_Click);
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBoxStrategicVisual
            // 
            this.toolStripComboBoxStrategicVisual.DropDownWidth = 520;
            this.toolStripComboBoxStrategicVisual.Items.AddRange(new object[] {
            "Количество смежных граней по общим ребрам",
            "Количество смежных граней по общим вершинам",
            "Коэффициент вектора нормали по оси Z (угол в градусах)",
            "Коэффициент вектора нормали по оси Z в текущем слое (миним. значение угла в граду" +
                "сах)",
            "Коэффициент вектора нормали по оси Z в текущем слое (размах значений угла в граду" +
                "сах)",
            "Коэффициент вектора нормали по оси X (угол в градусах)",
            "Коэффициент вектора нормали по оси Y (угол в градусах)",
            "Отображение граней модели изделия на сферу",
            "Двугранный угол между смежными гранями (минимальное значение)",
            "Двугранный угол между смежными гранями (максимальное значение)",
            "Двугранный угол между смежными гранями (среднеарифметическое значение)",
            "Площадь треугольной грани",
            "Отношение радиусов вписанной и описанной окружности для треугольной грани",
            "Толщина материала по оси Z",
            "Последовательность триангуляции",
            "Плотность граней по интервалам",
            "Разнообразие треугольников по площади  (количество граней на единицу площади пове" +
                "рхности)"});
            this.toolStripComboBoxStrategicVisual.MaxDropDownItems = 16;
            this.toolStripComboBoxStrategicVisual.Name = "toolStripComboBoxStrategicVisual";
            this.toolStripComboBoxStrategicVisual.Size = new System.Drawing.Size(599, 28);
            this.toolStripComboBoxStrategicVisual.Text = "Количество смежных граней по общим ребрам";
            this.toolStripComboBoxStrategicVisual.ToolTipText = "Выбор исследуемого признака";
            this.toolStripComboBoxStrategicVisual.TextChanged += new System.EventHandler(this.ToolStripComboBoxStrategicVisual_TextChanged);
            // 
            // toolStripSeparator26
            // 
            this.toolStripSeparator26.Name = "toolStripSeparator26";
            this.toolStripSeparator26.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonColorVisual
            // 
            this.toolStripButtonColorVisual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonColorVisual.Enabled = false;
            this.toolStripButtonColorVisual.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonColorVisual.Image")));
            this.toolStripButtonColorVisual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColorVisual.Name = "toolStripButtonColorVisual";
            this.toolStripButtonColorVisual.Size = new System.Drawing.Size(58, 25);
            this.toolStripButtonColorVisual.Text = "Расчет";
            this.toolStripButtonColorVisual.ToolTipText = "Расчет компонент цвета для визуализации";
            this.toolStripButtonColorVisual.Click += new System.EventHandler(this.ToolStripButtonColorVisual_Click_1);
            // 
            // toolStripSeparator30
            // 
            this.toolStripSeparator30.Name = "toolStripSeparator30";
            this.toolStripSeparator30.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator29
            // 
            this.toolStripSeparator29.Name = "toolStripSeparator29";
            this.toolStripSeparator29.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonSavePLY
            // 
            this.toolStripButtonSavePLY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonSavePLY.Enabled = false;
            this.toolStripButtonSavePLY.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSavePLY.Image")));
            this.toolStripButtonSavePLY.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSavePLY.Name = "toolStripButtonSavePLY";
            this.toolStripButtonSavePLY.Size = new System.Drawing.Size(98, 25);
            this.toolStripButtonSavePLY.Text = "Сохранение";
            this.toolStripButtonSavePLY.ToolTipText = "Сохранение файла для визуального анализа";
            this.toolStripButtonSavePLY.Click += new System.EventHandler(this.ToolStripButtonSavePLY_Click);
            // 
            // toolStripSeparator27
            // 
            this.toolStripSeparator27.Name = "toolStripSeparator27";
            this.toolStripSeparator27.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator28
            // 
            this.toolStripSeparator28.Name = "toolStripSeparator28";
            this.toolStripSeparator28.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBoxSelestFormatFile
            // 
            this.toolStripComboBoxSelestFormatFile.DropDownHeight = 50;
            this.toolStripComboBoxSelestFormatFile.DropDownWidth = 50;
            this.toolStripComboBoxSelestFormatFile.IntegralHeight = false;
            this.toolStripComboBoxSelestFormatFile.Items.AddRange(new object[] {
            "AMF",
            "PLY",
            "XLS"});
            this.toolStripComboBoxSelestFormatFile.MaxDropDownItems = 3;
            this.toolStripComboBoxSelestFormatFile.Name = "toolStripComboBoxSelestFormatFile";
            this.toolStripComboBoxSelestFormatFile.Size = new System.Drawing.Size(75, 28);
            this.toolStripComboBoxSelestFormatFile.Text = "PLY";
            this.toolStripComboBoxSelestFormatFile.ToolTipText = "Выбор формата файла для сохранения";
            // 
            // analOrient
            // 
            this.analOrient.Controls.Add(this.statusStrip3);
            this.analOrient.Controls.Add(this.buttonXlsOrient);
            this.analOrient.Controls.Add(this.label41);
            this.analOrient.Controls.Add(this.label42);
            this.analOrient.Controls.Add(this.panel7);
            this.analOrient.Controls.Add(this.dataGridViewOrientation);
            this.analOrient.Controls.Add(this.toolStrip3);
            this.analOrient.Location = new System.Drawing.Point(4, 25);
            this.analOrient.Margin = new System.Windows.Forms.Padding(4);
            this.analOrient.Name = "analOrient";
            this.analOrient.Size = new System.Drawing.Size(1219, 658);
            this.analOrient.TabIndex = 7;
            this.analOrient.Text = "Ориентация изделия";
            this.analOrient.UseVisualStyleBackColor = true;
            // 
            // statusStrip3
            // 
            this.statusStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarOrientation,
            this.toolStripStatusLabelInphoOrientation});
            this.statusStrip3.Location = new System.Drawing.Point(0, 629);
            this.statusStrip3.Name = "statusStrip3";
            this.statusStrip3.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip3.Size = new System.Drawing.Size(1219, 29);
            this.statusStrip3.TabIndex = 1;
            this.statusStrip3.Text = "statusStrip3";
            // 
            // toolStripProgressBarOrientation
            // 
            this.toolStripProgressBarOrientation.Name = "toolStripProgressBarOrientation";
            this.toolStripProgressBarOrientation.Size = new System.Drawing.Size(533, 23);
            // 
            // toolStripStatusLabelInphoOrientation
            // 
            this.toolStripStatusLabelInphoOrientation.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelInphoOrientation.Name = "toolStripStatusLabelInphoOrientation";
            this.toolStripStatusLabelInphoOrientation.Size = new System.Drawing.Size(261, 24);
            this.toolStripStatusLabelInphoOrientation.Text = "Массив исходных данных не создан";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label41.Location = new System.Drawing.Point(25, 224);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(950, 17);
            this.label41.TabIndex = 47;
            this.label41.Text = "Варианты ориентации (статистические характеристики распределения угла наклона век" +
    "тора нормали относительно оси Z)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label42.Location = new System.Drawing.Point(25, 36);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(241, 17);
            this.label42.TabIndex = 46;
            this.label42.Text = "Исходные данные для анализа";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.checkBoxAndOrAddCondition);
            this.panel7.Controls.Add(this.checkBox3varAddH);
            this.panel7.Controls.Add(this.checkBox2varAddH);
            this.panel7.Controls.Add(this.checkBox1varAddH);
            this.panel7.Controls.Add(this.numericUpDownHMax);
            this.panel7.Controls.Add(this.numericUpDownHMin);
            this.panel7.Controls.Add(this.labelRangeH);
            this.panel7.Controls.Add(this.numericUpDown3varRelSMax);
            this.panel7.Controls.Add(this.numericUpDown3varRelSMin);
            this.panel7.Controls.Add(this.numericUpDown2varRelSMax);
            this.panel7.Controls.Add(this.numericUpDown2varRelSMin);
            this.panel7.Controls.Add(this.numericUpDown1varRelSMax);
            this.panel7.Controls.Add(this.numericUpDown1varRelSMin);
            this.panel7.Controls.Add(this.labelRelSMax);
            this.panel7.Controls.Add(this.labelRelSMin);
            this.panel7.Controls.Add(this.label3varRelS);
            this.panel7.Controls.Add(this.label2varRelS);
            this.panel7.Controls.Add(this.label1varRelS);
            this.panel7.Controls.Add(this.labelAngleMax);
            this.panel7.Controls.Add(this.labelAngleMin);
            this.panel7.Controls.Add(this.numericUpDown3varAngleMax);
            this.panel7.Controls.Add(this.numericUpDown3varAngleMin);
            this.panel7.Controls.Add(this.numericUpDown2varAngleMax);
            this.panel7.Controls.Add(this.numericUpDown2varAngleMin);
            this.panel7.Controls.Add(this.numericUpDown1varAngleMax);
            this.panel7.Controls.Add(this.numericUpDown1varAngleMin);
            this.panel7.Controls.Add(this.checkBox3var);
            this.panel7.Controls.Add(this.checkBox2var);
            this.panel7.Controls.Add(this.checkBox1var);
            this.panel7.Controls.Add(this.label3varRangeAngle);
            this.panel7.Controls.Add(this.label2varRangeAngle);
            this.panel7.Controls.Add(this.label1varRangeAngle);
            this.panel7.Controls.Add(this.numericUpDown3varB);
            this.panel7.Controls.Add(this.numericUpDown3varG);
            this.panel7.Controls.Add(this.numericUpDown3varR);
            this.panel7.Controls.Add(this.numericUpDown2varB);
            this.panel7.Controls.Add(this.numericUpDown2varG);
            this.panel7.Controls.Add(this.numericUpDown2varR);
            this.panel7.Controls.Add(this.numericUpDown1varB);
            this.panel7.Controls.Add(this.numericUpDown1varG);
            this.panel7.Controls.Add(this.numericUpDown1varR);
            this.panel7.Controls.Add(this.labelB);
            this.panel7.Controls.Add(this.labelG);
            this.panel7.Controls.Add(this.labelR);
            this.panel7.Controls.Add(this.label3var);
            this.panel7.Controls.Add(this.textBoxIntOrient);
            this.panel7.Controls.Add(this.textBoxRangeOrient);
            this.panel7.Controls.Add(this.numericUpDownIntOrientation);
            this.panel7.Controls.Add(this.labelCountIntOrientation);
            this.panel7.Controls.Add(this.label2var);
            this.panel7.Controls.Add(this.label1var);
            this.panel7.Location = new System.Drawing.Point(11, 47);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1194, 173);
            this.panel7.TabIndex = 45;
            // 
            // labelRelSMax
            // 
            this.labelRelSMax.AutoSize = true;
            this.labelRelSMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelRelSMax.ForeColor = System.Drawing.Color.Blue;
            this.labelRelSMax.Location = new System.Drawing.Point(1097, 4);
            this.labelRelSMax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRelSMax.Name = "labelRelSMax";
            this.labelRelSMax.Size = new System.Drawing.Size(36, 17);
            this.labelRelSMax.TabIndex = 62;
            this.labelRelSMax.Text = "Max";
            // 
            // labelRelSMin
            // 
            this.labelRelSMin.AutoSize = true;
            this.labelRelSMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelRelSMin.ForeColor = System.Drawing.Color.Red;
            this.labelRelSMin.Location = new System.Drawing.Point(993, 4);
            this.labelRelSMin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRelSMin.Name = "labelRelSMin";
            this.labelRelSMin.Size = new System.Drawing.Size(33, 17);
            this.labelRelSMin.TabIndex = 61;
            this.labelRelSMin.Text = "Min";
            // 
            // labelAngleMax
            // 
            this.labelAngleMax.AutoSize = true;
            this.labelAngleMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAngleMax.ForeColor = System.Drawing.Color.Blue;
            this.labelAngleMax.Location = new System.Drawing.Point(764, 4);
            this.labelAngleMax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAngleMax.Name = "labelAngleMax";
            this.labelAngleMax.Size = new System.Drawing.Size(36, 17);
            this.labelAngleMax.TabIndex = 57;
            this.labelAngleMax.Text = "Max";
            // 
            // labelAngleMin
            // 
            this.labelAngleMin.AutoSize = true;
            this.labelAngleMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAngleMin.ForeColor = System.Drawing.Color.Red;
            this.labelAngleMin.Location = new System.Drawing.Point(660, 4);
            this.labelAngleMin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAngleMin.Name = "labelAngleMin";
            this.labelAngleMin.Size = new System.Drawing.Size(33, 17);
            this.labelAngleMin.TabIndex = 56;
            this.labelAngleMin.Text = "Min";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelB.ForeColor = System.Drawing.Color.Blue;
            this.labelB.Location = new System.Drawing.Point(452, 4);
            this.labelB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(18, 17);
            this.labelB.TabIndex = 33;
            this.labelB.Text = "B";
            // 
            // labelG
            // 
            this.labelG.AutoSize = true;
            this.labelG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelG.ForeColor = System.Drawing.Color.Green;
            this.labelG.Location = new System.Drawing.Point(344, 4);
            this.labelG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelG.Name = "labelG";
            this.labelG.Size = new System.Drawing.Size(20, 17);
            this.labelG.TabIndex = 34;
            this.labelG.Text = "G";
            // 
            // labelR
            // 
            this.labelR.AutoSize = true;
            this.labelR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelR.ForeColor = System.Drawing.Color.Red;
            this.labelR.Location = new System.Drawing.Point(236, 4);
            this.labelR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelR.Name = "labelR";
            this.labelR.Size = new System.Drawing.Size(19, 17);
            this.labelR.TabIndex = 32;
            this.labelR.Text = "R";
            // 
            // labelCountIntOrientation
            // 
            this.labelCountIntOrientation.AutoSize = true;
            this.labelCountIntOrientation.Location = new System.Drawing.Point(13, 138);
            this.labelCountIntOrientation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCountIntOrientation.Name = "labelCountIntOrientation";
            this.labelCountIntOrientation.Size = new System.Drawing.Size(134, 17);
            this.labelCountIntOrientation.TabIndex = 27;
            this.labelCountIntOrientation.Text = "Кол-во интервалов";
            // 
            // dataGridViewOrientation
            // 
            this.dataGridViewOrientation.AllowUserToAddRows = false;
            this.dataGridViewOrientation.AllowUserToDeleteRows = false;
            this.dataGridViewOrientation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOrientation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.VariantOrient,
            this.ColumnHeight,
            this.Reaserch1varRelS,
            this.Reaserch2varRelS,
            this.Reaserch3varRelS,
            this.ReviewGistOrient,
            this.CountIntOrient,
            this.MinIntervalOrient,
            this.MaxIntervalOrient,
            this.RangeOrient,
            this.dOrient,
            this.sOrient,
            this.EOrient,
            this.KaOrient,
            this.KeOrient,
            this.KvOrient,
            this.MeanaOrient,
            this.ModaOrient,
            this.MedianaOrient,
            this.XOrient,
            this.YOrient,
            this.Save});
            this.dataGridViewOrientation.Location = new System.Drawing.Point(11, 244);
            this.dataGridViewOrientation.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewOrientation.Name = "dataGridViewOrientation";
            this.dataGridViewOrientation.ReadOnly = true;
            this.dataGridViewOrientation.Size = new System.Drawing.Size(1195, 373);
            this.dataGridViewOrientation.TabIndex = 44;
            this.dataGridViewOrientation.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewOrientation_CellClick);
            // 
            // VariantOrient
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.VariantOrient.DefaultCellStyle = dataGridViewCellStyle35;
            this.VariantOrient.Frozen = true;
            this.VariantOrient.HeaderText = "№";
            this.VariantOrient.MaxInputLength = 10;
            this.VariantOrient.MinimumWidth = 25;
            this.VariantOrient.Name = "VariantOrient";
            this.VariantOrient.ReadOnly = true;
            this.VariantOrient.Width = 50;
            // 
            // ColumnHeight
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnHeight.DefaultCellStyle = dataGridViewCellStyle36;
            this.ColumnHeight.HeaderText = "Высота изделия";
            this.ColumnHeight.MaxInputLength = 10;
            this.ColumnHeight.Name = "ColumnHeight";
            this.ColumnHeight.ReadOnly = true;
            this.ColumnHeight.Width = 140;
            // 
            // Reaserch1varRelS
            // 
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Reaserch1varRelS.DefaultCellStyle = dataGridViewCellStyle37;
            this.Reaserch1varRelS.HeaderText = "Площадь 1-й вар.";
            this.Reaserch1varRelS.MaxInputLength = 12;
            this.Reaserch1varRelS.Name = "Reaserch1varRelS";
            this.Reaserch1varRelS.ReadOnly = true;
            this.Reaserch1varRelS.ToolTipText = "Относительная площадь граней для 1-го варианта";
            this.Reaserch1varRelS.Width = 130;
            // 
            // Reaserch2varRelS
            // 
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Reaserch2varRelS.DefaultCellStyle = dataGridViewCellStyle38;
            this.Reaserch2varRelS.HeaderText = "Площадь 2-й вар.";
            this.Reaserch2varRelS.MaxInputLength = 12;
            this.Reaserch2varRelS.Name = "Reaserch2varRelS";
            this.Reaserch2varRelS.ReadOnly = true;
            this.Reaserch2varRelS.ToolTipText = "Относительная площадь граней для 2-го варианта";
            this.Reaserch2varRelS.Width = 130;
            // 
            // Reaserch3varRelS
            // 
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Reaserch3varRelS.DefaultCellStyle = dataGridViewCellStyle39;
            this.Reaserch3varRelS.HeaderText = "Площадь 3-й вар.";
            this.Reaserch3varRelS.MaxInputLength = 12;
            this.Reaserch3varRelS.Name = "Reaserch3varRelS";
            this.Reaserch3varRelS.ReadOnly = true;
            this.Reaserch3varRelS.ToolTipText = "Относительная площадь граней для 3-го варианта";
            this.Reaserch3varRelS.Width = 130;
            // 
            // ReviewGistOrient
            // 
            this.ReviewGistOrient.HeaderText = "Гистограмма";
            this.ReviewGistOrient.MinimumWidth = 35;
            this.ReviewGistOrient.Name = "ReviewGistOrient";
            this.ReviewGistOrient.ReadOnly = true;
            this.ReviewGistOrient.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ReviewGistOrient.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ReviewGistOrient.Width = 80;
            // 
            // CountIntOrient
            // 
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CountIntOrient.DefaultCellStyle = dataGridViewCellStyle40;
            this.CountIntOrient.HeaderText = "Кол.интерв.";
            this.CountIntOrient.MaxInputLength = 3;
            this.CountIntOrient.Name = "CountIntOrient";
            this.CountIntOrient.ReadOnly = true;
            this.CountIntOrient.Width = 80;
            // 
            // MinIntervalOrient
            // 
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.MinIntervalOrient.DefaultCellStyle = dataGridViewCellStyle41;
            this.MinIntervalOrient.HeaderText = "Мин.";
            this.MinIntervalOrient.MaxInputLength = 10;
            this.MinIntervalOrient.MinimumWidth = 35;
            this.MinIntervalOrient.Name = "MinIntervalOrient";
            this.MinIntervalOrient.ReadOnly = true;
            this.MinIntervalOrient.Width = 80;
            // 
            // MaxIntervalOrient
            // 
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.MaxIntervalOrient.DefaultCellStyle = dataGridViewCellStyle42;
            this.MaxIntervalOrient.HeaderText = "Макс.";
            this.MaxIntervalOrient.MaxInputLength = 10;
            this.MaxIntervalOrient.MinimumWidth = 35;
            this.MaxIntervalOrient.Name = "MaxIntervalOrient";
            this.MaxIntervalOrient.ReadOnly = true;
            this.MaxIntervalOrient.Width = 80;
            // 
            // RangeOrient
            // 
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RangeOrient.DefaultCellStyle = dataGridViewCellStyle43;
            this.RangeOrient.HeaderText = "Размах";
            this.RangeOrient.MaxInputLength = 10;
            this.RangeOrient.Name = "RangeOrient";
            this.RangeOrient.ReadOnly = true;
            // 
            // dOrient
            // 
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dOrient.DefaultCellStyle = dataGridViewCellStyle44;
            this.dOrient.HeaderText = "Дисперсия";
            this.dOrient.MaxInputLength = 10;
            this.dOrient.Name = "dOrient";
            this.dOrient.ReadOnly = true;
            // 
            // sOrient
            // 
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.sOrient.DefaultCellStyle = dataGridViewCellStyle45;
            this.sOrient.HeaderText = "Среднекв.отклон.";
            this.sOrient.MaxInputLength = 10;
            this.sOrient.Name = "sOrient";
            this.sOrient.ReadOnly = true;
            // 
            // EOrient
            // 
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.EOrient.DefaultCellStyle = dataGridViewCellStyle46;
            this.EOrient.HeaderText = "Ср. арифмет.";
            this.EOrient.MaxInputLength = 12;
            this.EOrient.Name = "EOrient";
            this.EOrient.ReadOnly = true;
            // 
            // KaOrient
            // 
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.KaOrient.DefaultCellStyle = dataGridViewCellStyle47;
            this.KaOrient.HeaderText = "Коэф.асиметрии";
            this.KaOrient.MaxInputLength = 32;
            this.KaOrient.Name = "KaOrient";
            this.KaOrient.ReadOnly = true;
            this.KaOrient.Width = 120;
            // 
            // KeOrient
            // 
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.KeOrient.DefaultCellStyle = dataGridViewCellStyle48;
            this.KeOrient.HeaderText = "Коэф. эксцесса";
            this.KeOrient.MaxInputLength = 32;
            this.KeOrient.Name = "KeOrient";
            this.KeOrient.ReadOnly = true;
            this.KeOrient.Width = 120;
            // 
            // KvOrient
            // 
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.KvOrient.DefaultCellStyle = dataGridViewCellStyle49;
            this.KvOrient.HeaderText = "Коэф. вариации";
            this.KvOrient.MaxInputLength = 32;
            this.KvOrient.Name = "KvOrient";
            this.KvOrient.ReadOnly = true;
            this.KvOrient.Width = 120;
            // 
            // MeanaOrient
            // 
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.MeanaOrient.DefaultCellStyle = dataGridViewCellStyle50;
            this.MeanaOrient.HeaderText = "Меана";
            this.MeanaOrient.MaxInputLength = 32;
            this.MeanaOrient.Name = "MeanaOrient";
            this.MeanaOrient.ReadOnly = true;
            // 
            // ModaOrient
            // 
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ModaOrient.DefaultCellStyle = dataGridViewCellStyle51;
            this.ModaOrient.HeaderText = "Мода";
            this.ModaOrient.MaxInputLength = 32;
            this.ModaOrient.Name = "ModaOrient";
            this.ModaOrient.ReadOnly = true;
            // 
            // MedianaOrient
            // 
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.MedianaOrient.DefaultCellStyle = dataGridViewCellStyle52;
            this.MedianaOrient.HeaderText = "Медиана";
            this.MedianaOrient.MaxInputLength = 32;
            this.MedianaOrient.Name = "MedianaOrient";
            this.MedianaOrient.ReadOnly = true;
            // 
            // XOrient
            // 
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.XOrient.DefaultCellStyle = dataGridViewCellStyle53;
            this.XOrient.HeaderText = "Угол поворота вокруг оси X";
            this.XOrient.MaxInputLength = 10;
            this.XOrient.MinimumWidth = 35;
            this.XOrient.Name = "XOrient";
            this.XOrient.ReadOnly = true;
            this.XOrient.Width = 180;
            // 
            // YOrient
            // 
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.YOrient.DefaultCellStyle = dataGridViewCellStyle54;
            this.YOrient.HeaderText = "Угол поворота вокруг оси Y";
            this.YOrient.MaxInputLength = 10;
            this.YOrient.MinimumWidth = 35;
            this.YOrient.Name = "YOrient";
            this.YOrient.ReadOnly = true;
            this.YOrient.Width = 180;
            // 
            // Save
            // 
            this.Save.HeaderText = "Сохранение в STL-файл";
            this.Save.Name = "Save";
            this.Save.ReadOnly = true;
            this.Save.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Save.Width = 180;
            // 
            // toolStrip3
            // 
            this.toolStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonCalculateOrientation,
            this.toolStripSeparator25,
            this.toolStripSeparator24,
            this.toolStripTextBoxVarCount,
            this.toolStripSeparator31,
            this.toolStripLabel1,
            this.toolStripComboBoxDX,
            this.toolStripLabel2,
            this.toolStripComboBoxDY,
            this.toolStripSeparator33,
            this.toolStripSeparator32,
            this.toolStripButtonColorAnalysis,
            this.toolStripSeparator34,
            this.toolStripButtonExpression,
            this.toolStripSeparator39});
            this.toolStrip3.Location = new System.Drawing.Point(0, 0);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(1219, 28);
            this.toolStrip3.TabIndex = 0;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // toolStripButtonCalculateOrientation
            // 
            this.toolStripButtonCalculateOrientation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonCalculateOrientation.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCalculateOrientation.Image")));
            this.toolStripButtonCalculateOrientation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCalculateOrientation.Name = "toolStripButtonCalculateOrientation";
            this.toolStripButtonCalculateOrientation.Size = new System.Drawing.Size(74, 25);
            this.toolStripButtonCalculateOrientation.Text = "  Расчет  ";
            this.toolStripButtonCalculateOrientation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripButtonCalculateOrientation.ToolTipText = "Расчет (статистический анализ) всех вариантов ориентации";
            this.toolStripButtonCalculateOrientation.Click += new System.EventHandler(this.ToolStripButtonCalculateOrientation_Click);
            // 
            // toolStripSeparator25
            // 
            this.toolStripSeparator25.Name = "toolStripSeparator25";
            this.toolStripSeparator25.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator24
            // 
            this.toolStripSeparator24.Name = "toolStripSeparator24";
            this.toolStripSeparator24.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripTextBoxVarCount
            // 
            this.toolStripTextBoxVarCount.MaxLength = 32;
            this.toolStripTextBoxVarCount.Name = "toolStripTextBoxVarCount";
            this.toolStripTextBoxVarCount.Size = new System.Drawing.Size(159, 28);
            this.toolStripTextBoxVarCount.Text = "4 варианта(ов)";
            this.toolStripTextBoxVarCount.ToolTipText = "Количество вариантов ";
            // 
            // toolStripSeparator31
            // 
            this.toolStripSeparator31.Name = "toolStripSeparator31";
            this.toolStripSeparator31.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(267, 25);
            this.toolStripLabel1.Text = "Дискретность поворота вокруг оси X";
            // 
            // toolStripComboBoxDX
            // 
            this.toolStripComboBoxDX.Items.AddRange(new object[] {
            "90",
            "45",
            "30",
            "20",
            "10",
            "5",
            "3",
            "2",
            "1",
            "0,5",
            "0,3",
            "0,2",
            "0,1"});
            this.toolStripComboBoxDX.Name = "toolStripComboBoxDX";
            this.toolStripComboBoxDX.Size = new System.Drawing.Size(99, 28);
            this.toolStripComboBoxDX.Text = "90";
            this.toolStripComboBoxDX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ToolStripComboBoxDX_KeyPress);
            this.toolStripComboBoxDX.TextChanged += new System.EventHandler(this.ToolStripComboBoxDX_TextChanged);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(29, 25);
            this.toolStripLabel2.Text = "  Y ";
            // 
            // toolStripComboBoxDY
            // 
            this.toolStripComboBoxDY.Items.AddRange(new object[] {
            "90",
            "45",
            "30",
            "20",
            "10",
            "5",
            "3",
            "2",
            "1",
            "0,5",
            "0,3",
            "0,2",
            "0,1"});
            this.toolStripComboBoxDY.Name = "toolStripComboBoxDY";
            this.toolStripComboBoxDY.Size = new System.Drawing.Size(99, 28);
            this.toolStripComboBoxDY.Text = "90";
            this.toolStripComboBoxDY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ToolStripComboBoxDY_KeyPress);
            this.toolStripComboBoxDY.TextChanged += new System.EventHandler(this.ToolStripComboBoxDX_TextChanged);
            // 
            // toolStripSeparator33
            // 
            this.toolStripSeparator33.Name = "toolStripSeparator33";
            this.toolStripSeparator33.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator32
            // 
            this.toolStripSeparator32.Name = "toolStripSeparator32";
            this.toolStripSeparator32.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonColorAnalysis
            // 
            this.toolStripButtonColorAnalysis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonColorAnalysis.Enabled = false;
            this.toolStripButtonColorAnalysis.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonColorAnalysis.Image")));
            this.toolStripButtonColorAnalysis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColorAnalysis.Name = "toolStripButtonColorAnalysis";
            this.toolStripButtonColorAnalysis.Size = new System.Drawing.Size(120, 25);
            this.toolStripButtonColorAnalysis.Text = "Анализ данных";
            this.toolStripButtonColorAnalysis.Click += new System.EventHandler(this.ToolStripButtonColorAnalysis_Click);
            // 
            // toolStripSeparator34
            // 
            this.toolStripSeparator34.Name = "toolStripSeparator34";
            this.toolStripSeparator34.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonExpression
            // 
            this.toolStripButtonExpression.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonExpression.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExpression.Image")));
            this.toolStripButtonExpression.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExpression.Name = "toolStripButtonExpression";
            this.toolStripButtonExpression.Size = new System.Drawing.Size(167, 25);
            this.toolStripButtonExpression.Text = "Исследуемая функция";
            this.toolStripButtonExpression.ToolTipText = "Задание зависимости угла наклона грани от исследуемого признака";
            this.toolStripButtonExpression.Visible = false;
            this.toolStripButtonExpression.Click += new System.EventHandler(this.ToolStripButtonExpression_Click);
            // 
            // toolStripSeparator39
            // 
            this.toolStripSeparator39.Name = "toolStripSeparator39";
            this.toolStripSeparator39.Size = new System.Drawing.Size(6, 28);
            // 
            // AnalLocation
            // 
            this.AnalLocation.Controls.Add(this.pictureBoxTop);
            this.AnalLocation.Controls.Add(this.pictureBoxFront);
            this.AnalLocation.Controls.Add(this.pictureBoxRight);
            this.AnalLocation.Controls.Add(this.labelXmin);
            this.AnalLocation.Controls.Add(this.labelYmin);
            this.AnalLocation.Controls.Add(this.labelZmin);
            this.AnalLocation.Controls.Add(this.labelYmax);
            this.AnalLocation.Controls.Add(this.labelXmax);
            this.AnalLocation.Controls.Add(this.labelZmax);
            this.AnalLocation.Controls.Add(this.labelX2);
            this.AnalLocation.Controls.Add(this.labelY2);
            this.AnalLocation.Controls.Add(this.labelX1);
            this.AnalLocation.Controls.Add(this.labelY1);
            this.AnalLocation.Controls.Add(this.labelZ2);
            this.AnalLocation.Controls.Add(this.richTextBoxLocationInfo);
            this.AnalLocation.Controls.Add(this.statusStrip5);
            this.AnalLocation.Controls.Add(this.labelZ1);
            this.AnalLocation.Controls.Add(this.toolStripLocation);
            this.AnalLocation.Location = new System.Drawing.Point(4, 25);
            this.AnalLocation.Margin = new System.Windows.Forms.Padding(4);
            this.AnalLocation.Name = "AnalLocation";
            this.AnalLocation.Padding = new System.Windows.Forms.Padding(4);
            this.AnalLocation.Size = new System.Drawing.Size(1219, 658);
            this.AnalLocation.TabIndex = 9;
            this.AnalLocation.Text = "Размещение изделий";
            this.AnalLocation.ToolTipText = "Рациональное размещение в рабочей области построения установки";
            this.AnalLocation.UseVisualStyleBackColor = true;
            // 
            // pictureBoxTop
            // 
            this.pictureBoxTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxTop.Location = new System.Drawing.Point(27, 331);
            this.pictureBoxTop.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxTop.Name = "pictureBoxTop";
            this.pictureBoxTop.Size = new System.Drawing.Size(572, 270);
            this.pictureBoxTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxTop.TabIndex = 27;
            this.pictureBoxTop.TabStop = false;
            this.pictureBoxTop.Click += new System.EventHandler(this.PictureBoxTop_Click);
            // 
            // pictureBoxFront
            // 
            this.pictureBoxFront.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxFront.Location = new System.Drawing.Point(636, 39);
            this.pictureBoxFront.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxFront.Name = "pictureBoxFront";
            this.pictureBoxFront.Size = new System.Drawing.Size(572, 270);
            this.pictureBoxFront.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxFront.TabIndex = 22;
            this.pictureBoxFront.TabStop = false;
            this.pictureBoxFront.DoubleClick += new System.EventHandler(this.PictureBoxFront_DoubleClick);
            // 
            // pictureBoxRight
            // 
            this.pictureBoxRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxRight.Location = new System.Drawing.Point(27, 38);
            this.pictureBoxRight.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxRight.Name = "pictureBoxRight";
            this.pictureBoxRight.Size = new System.Drawing.Size(572, 270);
            this.pictureBoxRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRight.TabIndex = 21;
            this.pictureBoxRight.TabStop = false;
            this.pictureBoxRight.Click += new System.EventHandler(this.PictureBoxRight_Click);
            // 
            // labelXmin
            // 
            this.labelXmin.AutoSize = true;
            this.labelXmin.Location = new System.Drawing.Point(641, 311);
            this.labelXmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelXmin.Name = "labelXmin";
            this.labelXmin.Size = new System.Drawing.Size(49, 17);
            this.labelXmin.TabIndex = 37;
            this.labelXmin.Text = "-190.5";
            // 
            // labelYmin
            // 
            this.labelYmin.AutoSize = true;
            this.labelYmin.Location = new System.Drawing.Point(8, 603);
            this.labelYmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelYmin.Name = "labelYmin";
            this.labelYmin.Size = new System.Drawing.Size(57, 17);
            this.labelYmin.TabIndex = 36;
            this.labelYmin.Text = "-167.64";
            // 
            // labelZmin
            // 
            this.labelZmin.AutoSize = true;
            this.labelZmin.Location = new System.Drawing.Point(596, 288);
            this.labelZmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZmin.Name = "labelZmin";
            this.labelZmin.Size = new System.Drawing.Size(41, 17);
            this.labelZmin.TabIndex = 35;
            this.labelZmin.Text = "-2.54";
            // 
            // labelYmax
            // 
            this.labelYmax.AutoSize = true;
            this.labelYmax.Location = new System.Drawing.Point(549, 603);
            this.labelYmax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelYmax.Name = "labelYmax";
            this.labelYmax.Size = new System.Drawing.Size(44, 17);
            this.labelYmax.TabIndex = 34;
            this.labelYmax.Text = "165.1";
            // 
            // labelXmax
            // 
            this.labelXmax.AutoSize = true;
            this.labelXmax.Location = new System.Drawing.Point(1143, 313);
            this.labelXmax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelXmax.Name = "labelXmax";
            this.labelXmax.Size = new System.Drawing.Size(44, 17);
            this.labelXmax.TabIndex = 32;
            this.labelXmax.Text = "190.5";
            // 
            // labelZmax
            // 
            this.labelZmax.AutoSize = true;
            this.labelZmax.Location = new System.Drawing.Point(595, 62);
            this.labelZmax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZmax.Name = "labelZmax";
            this.labelZmax.Size = new System.Drawing.Size(44, 17);
            this.labelZmax.TabIndex = 30;
            this.labelZmax.Text = "457.2";
            // 
            // labelX2
            // 
            this.labelX2.AutoSize = true;
            this.labelX2.Location = new System.Drawing.Point(4, 331);
            this.labelX2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(17, 17);
            this.labelX2.TabIndex = 29;
            this.labelX2.Text = "X";
            // 
            // labelY2
            // 
            this.labelY2.AutoSize = true;
            this.labelY2.Location = new System.Drawing.Point(599, 603);
            this.labelY2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelY2.Name = "labelY2";
            this.labelY2.Size = new System.Drawing.Size(17, 17);
            this.labelY2.TabIndex = 28;
            this.labelY2.Text = "Y";
            // 
            // labelX1
            // 
            this.labelX1.AutoSize = true;
            this.labelX1.Location = new System.Drawing.Point(1189, 313);
            this.labelX1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(17, 17);
            this.labelX1.TabIndex = 26;
            this.labelX1.Text = "X";
            // 
            // labelY1
            // 
            this.labelY1.AutoSize = true;
            this.labelY1.Location = new System.Drawing.Point(596, 313);
            this.labelY1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelY1.Name = "labelY1";
            this.labelY1.Size = new System.Drawing.Size(17, 17);
            this.labelY1.TabIndex = 25;
            this.labelY1.Text = "Y";
            // 
            // labelZ2
            // 
            this.labelZ2.AutoSize = true;
            this.labelZ2.Location = new System.Drawing.Point(609, 39);
            this.labelZ2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZ2.Name = "labelZ2";
            this.labelZ2.Size = new System.Drawing.Size(17, 17);
            this.labelZ2.TabIndex = 24;
            this.labelZ2.Text = "Z";
            // 
            // richTextBoxLocationInfo
            // 
            this.richTextBoxLocationInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxLocationInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBoxLocationInfo.Location = new System.Drawing.Point(637, 331);
            this.richTextBoxLocationInfo.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBoxLocationInfo.Name = "richTextBoxLocationInfo";
            this.richTextBoxLocationInfo.ReadOnly = true;
            this.richTextBoxLocationInfo.Size = new System.Drawing.Size(572, 287);
            this.richTextBoxLocationInfo.TabIndex = 20;
            this.richTextBoxLocationInfo.Text = "";
            // 
            // statusStrip5
            // 
            this.statusStrip5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarLocation,
            this.toolStripStatusLabelLocation});
            this.statusStrip5.Location = new System.Drawing.Point(4, 625);
            this.statusStrip5.Name = "statusStrip5";
            this.statusStrip5.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip5.Size = new System.Drawing.Size(1211, 29);
            this.statusStrip5.TabIndex = 4;
            this.statusStrip5.Text = "statusStrip1";
            // 
            // toolStripProgressBarLocation
            // 
            this.toolStripProgressBarLocation.MarqueeAnimationSpeed = 10;
            this.toolStripProgressBarLocation.Name = "toolStripProgressBarLocation";
            this.toolStripProgressBarLocation.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarLocation.Step = 1;
            // 
            // toolStripStatusLabelLocation
            // 
            this.toolStripStatusLabelLocation.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabelLocation.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelLocation.Name = "toolStripStatusLabelLocation";
            this.toolStripStatusLabelLocation.Size = new System.Drawing.Size(202, 24);
            this.toolStripStatusLabelLocation.Text = "Массив данных не создан  ";
            // 
            // labelZ1
            // 
            this.labelZ1.AutoSize = true;
            this.labelZ1.Location = new System.Drawing.Point(4, 39);
            this.labelZ1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZ1.Name = "labelZ1";
            this.labelZ1.Size = new System.Drawing.Size(17, 17);
            this.labelZ1.TabIndex = 23;
            this.labelZ1.Text = "Z";
            // 
            // toolStripLocation
            // 
            this.toolStripLocation.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripLocation.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonPack,
            this.toolStripSeparator42,
            this.toolStripSeparator43,
            this.toolStripComboBoxListModels,
            this.toolStripButtonDelete,
            this.toolStripSeparator44,
            this.toolStripSeparator45,
            this.toolStripButtonLocalAnalysis,
            this.toolStripSeparator46,
            this.toolStripSeparator47,
            this.toolStripButtonLocalSettings,
            this.toolStripSeparator48,
            this.toolStripSeparator49,
            this.toolStripLabel3,
            this.toolStripTextBoxStep,
            this.toolStripSeparator51,
            this.toolStripSeparator50,
            this.toolStripButtonRGB1,
            this.toolStripSeparator54,
            this.toolStripButtonRGB2,
            this.toolStripSeparator52,
            this.toolStripSeparator53});
            this.toolStripLocation.Location = new System.Drawing.Point(4, 4);
            this.toolStripLocation.Name = "toolStripLocation";
            this.toolStripLocation.Size = new System.Drawing.Size(1211, 28);
            this.toolStripLocation.TabIndex = 3;
            this.toolStripLocation.Text = "toolStrip5";
            // 
            // toolStripButtonPack
            // 
            this.toolStripButtonPack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonPack.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonPack.Image")));
            this.toolStripButtonPack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonPack.Name = "toolStripButtonPack";
            this.toolStripButtonPack.Size = new System.Drawing.Size(101, 25);
            this.toolStripButtonPack.Text = "Размещение";
            this.toolStripButtonPack.Click += new System.EventHandler(this.ToolStripButtonPack_Click);
            // 
            // toolStripSeparator42
            // 
            this.toolStripSeparator42.Name = "toolStripSeparator42";
            this.toolStripSeparator42.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator43
            // 
            this.toolStripSeparator43.Name = "toolStripSeparator43";
            this.toolStripSeparator43.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBoxListModels
            // 
            this.toolStripComboBoxListModels.Name = "toolStripComboBoxListModels";
            this.toolStripComboBoxListModels.Size = new System.Drawing.Size(332, 28);
            this.toolStripComboBoxListModels.Text = "Выбор модели...";
            // 
            // toolStripButtonDelete
            // 
            this.toolStripButtonDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonDelete.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonDelete.Image")));
            this.toolStripButtonDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonDelete.Name = "toolStripButtonDelete";
            this.toolStripButtonDelete.Size = new System.Drawing.Size(24, 25);
            this.toolStripButtonDelete.Text = "Удаление";
            this.toolStripButtonDelete.ToolTipText = "Удаление текущей модели";
            this.toolStripButtonDelete.Click += new System.EventHandler(this.ToolStripButtonDelete_Click);
            // 
            // toolStripSeparator44
            // 
            this.toolStripSeparator44.Name = "toolStripSeparator44";
            this.toolStripSeparator44.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator45
            // 
            this.toolStripSeparator45.Name = "toolStripSeparator45";
            this.toolStripSeparator45.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonLocalAnalysis
            // 
            this.toolStripButtonLocalAnalysis.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLocalAnalysis.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLocalAnalysis.Image")));
            this.toolStripButtonLocalAnalysis.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLocalAnalysis.Name = "toolStripButtonLocalAnalysis";
            this.toolStripButtonLocalAnalysis.Size = new System.Drawing.Size(64, 25);
            this.toolStripButtonLocalAnalysis.Text = "Анализ";
            this.toolStripButtonLocalAnalysis.ToolTipText = "Анализ размещения моделей";
            this.toolStripButtonLocalAnalysis.Click += new System.EventHandler(this.toolStripButtonLocalAnalysis_Click);
            // 
            // toolStripSeparator46
            // 
            this.toolStripSeparator46.Name = "toolStripSeparator46";
            this.toolStripSeparator46.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator47
            // 
            this.toolStripSeparator47.Name = "toolStripSeparator47";
            this.toolStripSeparator47.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonLocalSettings
            // 
            this.toolStripButtonLocalSettings.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLocalSettings.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLocalSettings.Image")));
            this.toolStripButtonLocalSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLocalSettings.Name = "toolStripButtonLocalSettings";
            this.toolStripButtonLocalSettings.Size = new System.Drawing.Size(94, 25);
            this.toolStripButtonLocalSettings.Text = "Параметры";
            this.toolStripButtonLocalSettings.ToolTipText = "Параметры установки";
            this.toolStripButtonLocalSettings.Click += new System.EventHandler(this.ToolStripButtonLocalSettings_Click);
            // 
            // toolStripSeparator48
            // 
            this.toolStripSeparator48.Name = "toolStripSeparator48";
            this.toolStripSeparator48.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator49
            // 
            this.toolStripSeparator49.Name = "toolStripSeparator49";
            this.toolStripSeparator49.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(37, 25);
            this.toolStripLabel3.Text = "Шаг";
            this.toolStripLabel3.ToolTipText = "Шаг перемещения";
            // 
            // toolStripTextBoxStep
            // 
            this.toolStripTextBoxStep.MaxLength = 6;
            this.toolStripTextBoxStep.Name = "toolStripTextBoxStep";
            this.toolStripTextBoxStep.Size = new System.Drawing.Size(65, 28);
            this.toolStripTextBoxStep.Text = "2";
            this.toolStripTextBoxStep.ToolTipText = "Шаг перемещения (визуализации), мм";
            this.toolStripTextBoxStep.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToolStripTextBoxStep_KeyDown);
            this.toolStripTextBoxStep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ToolStripTextBoxStep_KeyPress);
            // 
            // toolStripSeparator51
            // 
            this.toolStripSeparator51.Name = "toolStripSeparator51";
            this.toolStripSeparator51.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator50
            // 
            this.toolStripSeparator50.Name = "toolStripSeparator50";
            this.toolStripSeparator50.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonRGB1
            // 
            this.toolStripButtonRGB1.BackColor = System.Drawing.Color.Orange;
            this.toolStripButtonRGB1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonRGB1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonRGB1.Image")));
            this.toolStripButtonRGB1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRGB1.Name = "toolStripButtonRGB1";
            this.toolStripButtonRGB1.Size = new System.Drawing.Size(62, 25);
            this.toolStripButtonRGB1.Text = "RGB V0";
            this.toolStripButtonRGB1.ToolTipText = "RGB незаполненного объема";
            this.toolStripButtonRGB1.Click += new System.EventHandler(this.ToolStripButtonRGB1_Click);
            // 
            // toolStripSeparator54
            // 
            this.toolStripSeparator54.Name = "toolStripSeparator54";
            this.toolStripSeparator54.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonRGB2
            // 
            this.toolStripButtonRGB2.BackColor = System.Drawing.Color.DarkBlue;
            this.toolStripButtonRGB2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonRGB2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.toolStripButtonRGB2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonRGB2.Image")));
            this.toolStripButtonRGB2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRGB2.Name = "toolStripButtonRGB2";
            this.toolStripButtonRGB2.Size = new System.Drawing.Size(62, 25);
            this.toolStripButtonRGB2.Text = "RGB V1";
            this.toolStripButtonRGB2.ToolTipText = "Цвет для заполненного объема";
            this.toolStripButtonRGB2.Click += new System.EventHandler(this.ToolStripButtonRGB2_Click);
            // 
            // toolStripSeparator52
            // 
            this.toolStripSeparator52.Name = "toolStripSeparator52";
            this.toolStripSeparator52.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator53
            // 
            this.toolStripSeparator53.Name = "toolStripSeparator53";
            this.toolStripSeparator53.Size = new System.Drawing.Size(6, 28);
            // 
            // AnalVox
            // 
            this.AnalVox.AccessibleName = "AnalVox";
            this.AnalVox.Controls.Add(this.textBoxDataHistogram);
            this.AnalVox.Controls.Add(this.toolStrip2);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelX);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelZ);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelY);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelXYZRelative);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelXYZ);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelXRelation);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelZRelation);
            this.AnalVox.Controls.Add(this.chartHistogramVoxelYRelation);
            this.AnalVox.Controls.Add(this.label29);
            this.AnalVox.Controls.Add(this.label23);
            this.AnalVox.Controls.Add(this.panel4);
            this.AnalVox.Controls.Add(this.textBoxSizeY2);
            this.AnalVox.Controls.Add(this.textBoxSizeX2);
            this.AnalVox.Controls.Add(this.textBoxSizeZ2);
            this.AnalVox.Controls.Add(this.panel3);
            this.AnalVox.Location = new System.Drawing.Point(4, 25);
            this.AnalVox.Margin = new System.Windows.Forms.Padding(4);
            this.AnalVox.Name = "AnalVox";
            this.AnalVox.Size = new System.Drawing.Size(1219, 658);
            this.AnalVox.TabIndex = 4;
            this.AnalVox.Text = "Анализ воксельной модели";
            this.AnalVox.UseVisualStyleBackColor = true;
            this.AnalVox.Enter += new System.EventHandler(this.AnalVox_Enter);
            // 
            // textBoxDataHistogram
            // 
            this.textBoxDataHistogram.Location = new System.Drawing.Point(727, 229);
            this.textBoxDataHistogram.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDataHistogram.Multiline = true;
            this.textBoxDataHistogram.Name = "textBoxDataHistogram";
            this.textBoxDataHistogram.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDataHistogram.Size = new System.Drawing.Size(491, 198);
            this.textBoxDataHistogram.TabIndex = 36;
            this.textBoxDataHistogram.Visible = false;
            // 
            // toolStrip2
            // 
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonStatAnal,
            this.toolStripSeparator12,
            this.toolStripSeparator13,
            this.toolStripComboBoxShowAnalysis,
            this.toolStripSeparator14,
            this.toolStripSeparator15,
            this.toolStripButtonShowStatisticalDataX,
            this.toolStripSeparator18,
            this.toolStripButtonShowStatisticalDataY,
            this.toolStripSeparator20,
            this.toolStripButtonShowStatisticalDataZ,
            this.toolStripSeparator19,
            this.toolStripButtonShowHistogramXYZ,
            this.toolStripSeparator66,
            this.toolStripButtonShowHistogram3D,
            this.toolStripSeparator16,
            this.toolStripSeparator22,
            this.toolStripButtonAbsolute,
            this.toolStripSeparator65,
            this.toolStripButtonRelative});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1219, 28);
            this.toolStrip2.TabIndex = 2;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripButtonStatAnal
            // 
            this.toolStripButtonStatAnal.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonStatAnal.Enabled = false;
            this.toolStripButtonStatAnal.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonStatAnal.Image")));
            this.toolStripButtonStatAnal.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStatAnal.Name = "toolStripButtonStatAnal";
            this.toolStripButtonStatAnal.Size = new System.Drawing.Size(174, 25);
            this.toolStripButtonStatAnal.Text = "Статистический анализ";
            this.toolStripButtonStatAnal.Click += new System.EventHandler(this.ToolStripButton5_Click_1);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBoxShowAnalysis
            // 
            this.toolStripComboBoxShowAnalysis.Enabled = false;
            this.toolStripComboBoxShowAnalysis.Items.AddRange(new object[] {
            "1. Воксели модели",
            "2. Свободное пространство"});
            this.toolStripComboBoxShowAnalysis.Name = "toolStripComboBoxShowAnalysis";
            this.toolStripComboBoxShowAnalysis.Size = new System.Drawing.Size(199, 28);
            this.toolStripComboBoxShowAnalysis.Text = "1. Воксели модели";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonShowStatisticalDataX
            // 
            this.toolStripButtonShowStatisticalDataX.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonShowStatisticalDataX.Enabled = false;
            this.toolStripButtonShowStatisticalDataX.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonShowStatisticalDataX.Image")));
            this.toolStripButtonShowStatisticalDataX.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.toolStripButtonShowStatisticalDataX.Name = "toolStripButtonShowStatisticalDataX";
            this.toolStripButtonShowStatisticalDataX.Size = new System.Drawing.Size(92, 25);
            this.toolStripButtonShowStatisticalDataX.Text = "ширина (Х)";
            this.toolStripButtonShowStatisticalDataX.ToolTipText = "Распределение вокселей по ширине (Х)";
            this.toolStripButtonShowStatisticalDataX.Click += new System.EventHandler(this.ToolStripButtonShowStatisticalDataX_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonShowStatisticalDataY
            // 
            this.toolStripButtonShowStatisticalDataY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonShowStatisticalDataY.Enabled = false;
            this.toolStripButtonShowStatisticalDataY.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonShowStatisticalDataY.Image")));
            this.toolStripButtonShowStatisticalDataY.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonShowStatisticalDataY.Name = "toolStripButtonShowStatisticalDataY";
            this.toolStripButtonShowStatisticalDataY.Size = new System.Drawing.Size(77, 25);
            this.toolStripButtonShowStatisticalDataY.Text = "длина (Y)";
            this.toolStripButtonShowStatisticalDataY.ToolTipText = "Распределение вокселей по длине (Y)";
            this.toolStripButtonShowStatisticalDataY.Click += new System.EventHandler(this.ToolStripButtonShowStatisticalDataY_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonShowStatisticalDataZ
            // 
            this.toolStripButtonShowStatisticalDataZ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonShowStatisticalDataZ.Enabled = false;
            this.toolStripButtonShowStatisticalDataZ.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonShowStatisticalDataZ.Image")));
            this.toolStripButtonShowStatisticalDataZ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonShowStatisticalDataZ.Name = "toolStripButtonShowStatisticalDataZ";
            this.toolStripButtonShowStatisticalDataZ.Size = new System.Drawing.Size(85, 25);
            this.toolStripButtonShowStatisticalDataZ.Text = "высота (Z)";
            this.toolStripButtonShowStatisticalDataZ.ToolTipText = "Распределение вокселей по высоте (Z)";
            this.toolStripButtonShowStatisticalDataZ.Click += new System.EventHandler(this.ToolStripButtonShowStatisticalDataZ_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonShowHistogramXYZ
            // 
            this.toolStripButtonShowHistogramXYZ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonShowHistogramXYZ.Enabled = false;
            this.toolStripButtonShowHistogramXYZ.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonShowHistogramXYZ.Image")));
            this.toolStripButtonShowHistogramXYZ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonShowHistogramXYZ.Name = "toolStripButtonShowHistogramXYZ";
            this.toolStripButtonShowHistogramXYZ.Size = new System.Drawing.Size(47, 25);
            this.toolStripButtonShowHistogramXYZ.Text = "X Y Z";
            this.toolStripButtonShowHistogramXYZ.ToolTipText = "Гистограммы по осям X, Y, Z";
            this.toolStripButtonShowHistogramXYZ.Click += new System.EventHandler(this.ToolStripButtonShowHistogramXYZ_Click);
            // 
            // toolStripSeparator66
            // 
            this.toolStripSeparator66.Name = "toolStripSeparator66";
            this.toolStripSeparator66.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonShowHistogram3D
            // 
            this.toolStripButtonShowHistogram3D.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonShowHistogram3D.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonShowHistogram3D.Image")));
            this.toolStripButtonShowHistogram3D.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonShowHistogram3D.Name = "toolStripButtonShowHistogram3D";
            this.toolStripButtonShowHistogram3D.Size = new System.Drawing.Size(32, 25);
            this.toolStripButtonShowHistogram3D.Text = "3D";
            this.toolStripButtonShowHistogram3D.ToolTipText = "Анализ объемного распределения";
            this.toolStripButtonShowHistogram3D.Click += new System.EventHandler(this.ToolStripButton3D_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonAbsolute
            // 
            this.toolStripButtonAbsolute.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonAbsolute.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripButtonAbsolute.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAbsolute.Image")));
            this.toolStripButtonAbsolute.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAbsolute.Name = "toolStripButtonAbsolute";
            this.toolStripButtonAbsolute.Size = new System.Drawing.Size(98, 25);
            this.toolStripButtonAbsolute.Text = "Абс. кол-во";
            this.toolStripButtonAbsolute.ToolTipText = "Абсолютное количество";
            this.toolStripButtonAbsolute.Click += new System.EventHandler(this.ToolStripButtonAbsolute_Click);
            // 
            // toolStripSeparator65
            // 
            this.toolStripSeparator65.Name = "toolStripSeparator65";
            this.toolStripSeparator65.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButtonRelative
            // 
            this.toolStripButtonRelative.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonRelative.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonRelative.Image")));
            this.toolStripButtonRelative.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRelative.Name = "toolStripButtonRelative";
            this.toolStripButtonRelative.Size = new System.Drawing.Size(141, 25);
            this.toolStripButtonRelative.Text = "Относ. габар. р-ра";
            this.toolStripButtonRelative.ToolTipText = "Относительно габаритного размера";
            this.toolStripButtonRelative.Click += new System.EventHandler(this.ToolStripButtonRelative_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(563, 38);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(253, 17);
            this.label29.TabIndex = 34;
            this.label29.Text = "Статистические характеристики";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(25, 38);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(263, 17);
            this.label23.TabIndex = 29;
            this.label23.Text = "Исходные данные для гистограмм";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.label37);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Controls.Add(this.label34);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.textBoxMax);
            this.panel4.Controls.Add(this.textBoxInterval);
            this.panel4.Controls.Add(this.textBoxDispersion);
            this.panel4.Controls.Add(this.textBoxStandardDeviation);
            this.panel4.Controls.Add(this.textBoxAverage);
            this.panel4.Controls.Add(this.textBoxMean);
            this.panel4.Controls.Add(this.textBoxSkewness);
            this.panel4.Controls.Add(this.textBoxMedian);
            this.panel4.Controls.Add(this.textBoxMode);
            this.panel4.Controls.Add(this.textBoxCoefficientOfVariation);
            this.panel4.Controls.Add(this.textBoxCoefficientOfExcess);
            this.panel4.Controls.Add(this.textBoxMin);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Location = new System.Drawing.Point(547, 49);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(671, 172);
            this.panel4.TabIndex = 33;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(357, 112);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(114, 17);
            this.label39.TabIndex = 53;
            this.label39.Text = "Коэф. вариации";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(179, 59);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(137, 17);
            this.label38.TabIndex = 52;
            this.label38.Text = "Среднеквадр. откл.";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(555, 6);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(51, 17);
            this.label37.TabIndex = 51;
            this.label37.Text = "Меана";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(547, 112);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(67, 17);
            this.label36.TabIndex = 50;
            this.label36.Text = "Медиана";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(559, 59);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(43, 17);
            this.label35.TabIndex = 49;
            this.label35.Text = "Мода";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(348, 6);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(131, 17);
            this.label34.TabIndex = 48;
            this.label34.Text = "Коэф. асимметрии";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(357, 59);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(110, 17);
            this.label33.TabIndex = 47;
            this.label33.Text = "Коэф. эксцесса";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(45, 112);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 17);
            this.label32.TabIndex = 46;
            this.label32.Text = "Интервал";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(207, 6);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(81, 17);
            this.label31.TabIndex = 45;
            this.label31.Text = "Дисперсия";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(189, 112);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(117, 17);
            this.label30.TabIndex = 44;
            this.label30.Text = "Среднее арифм.";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(29, 59);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(101, 17);
            this.label28.TabIndex = 43;
            this.label28.Text = "Максим. знач.";
            // 
            // textBoxDispersion
            // 
            this.textBoxDispersion.Location = new System.Drawing.Point(183, 27);
            this.textBoxDispersion.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDispersion.Name = "textBoxDispersion";
            this.textBoxDispersion.ReadOnly = true;
            this.textBoxDispersion.Size = new System.Drawing.Size(137, 22);
            this.textBoxDispersion.TabIndex = 39;
            this.textBoxDispersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxStandardDeviation
            // 
            this.textBoxStandardDeviation.Location = new System.Drawing.Point(183, 80);
            this.textBoxStandardDeviation.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxStandardDeviation.Name = "textBoxStandardDeviation";
            this.textBoxStandardDeviation.ReadOnly = true;
            this.textBoxStandardDeviation.Size = new System.Drawing.Size(137, 22);
            this.textBoxStandardDeviation.TabIndex = 38;
            this.textBoxStandardDeviation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxAverage
            // 
            this.textBoxAverage.Location = new System.Drawing.Point(183, 133);
            this.textBoxAverage.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAverage.Name = "textBoxAverage";
            this.textBoxAverage.ReadOnly = true;
            this.textBoxAverage.Size = new System.Drawing.Size(137, 22);
            this.textBoxAverage.TabIndex = 37;
            this.textBoxAverage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMean
            // 
            this.textBoxMean.Location = new System.Drawing.Point(515, 27);
            this.textBoxMean.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMean.Name = "textBoxMean";
            this.textBoxMean.ReadOnly = true;
            this.textBoxMean.Size = new System.Drawing.Size(137, 22);
            this.textBoxMean.TabIndex = 35;
            this.textBoxMean.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSkewness
            // 
            this.textBoxSkewness.Location = new System.Drawing.Point(349, 27);
            this.textBoxSkewness.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSkewness.Name = "textBoxSkewness";
            this.textBoxSkewness.ReadOnly = true;
            this.textBoxSkewness.Size = new System.Drawing.Size(137, 22);
            this.textBoxSkewness.TabIndex = 35;
            this.textBoxSkewness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMedian
            // 
            this.textBoxMedian.Location = new System.Drawing.Point(515, 133);
            this.textBoxMedian.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMedian.Name = "textBoxMedian";
            this.textBoxMedian.ReadOnly = true;
            this.textBoxMedian.Size = new System.Drawing.Size(137, 22);
            this.textBoxMedian.TabIndex = 34;
            this.textBoxMedian.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMode
            // 
            this.textBoxMode.Location = new System.Drawing.Point(515, 80);
            this.textBoxMode.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMode.Name = "textBoxMode";
            this.textBoxMode.ReadOnly = true;
            this.textBoxMode.Size = new System.Drawing.Size(137, 22);
            this.textBoxMode.TabIndex = 33;
            this.textBoxMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCoefficientOfVariation
            // 
            this.textBoxCoefficientOfVariation.Location = new System.Drawing.Point(349, 133);
            this.textBoxCoefficientOfVariation.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCoefficientOfVariation.Name = "textBoxCoefficientOfVariation";
            this.textBoxCoefficientOfVariation.ReadOnly = true;
            this.textBoxCoefficientOfVariation.Size = new System.Drawing.Size(137, 22);
            this.textBoxCoefficientOfVariation.TabIndex = 34;
            this.textBoxCoefficientOfVariation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxCoefficientOfExcess
            // 
            this.textBoxCoefficientOfExcess.Location = new System.Drawing.Point(349, 80);
            this.textBoxCoefficientOfExcess.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCoefficientOfExcess.Name = "textBoxCoefficientOfExcess";
            this.textBoxCoefficientOfExcess.ReadOnly = true;
            this.textBoxCoefficientOfExcess.Size = new System.Drawing.Size(137, 22);
            this.textBoxCoefficientOfExcess.TabIndex = 33;
            this.textBoxCoefficientOfExcess.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(33, 6);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 17);
            this.label27.TabIndex = 31;
            this.label27.Text = "Миним. знач.";
            // 
            // textBoxSizeY2
            // 
            this.textBoxSizeY2.Location = new System.Drawing.Point(291, 79);
            this.textBoxSizeY2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeY2.Name = "textBoxSizeY2";
            this.textBoxSizeY2.ReadOnly = true;
            this.textBoxSizeY2.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeY2.TabIndex = 20;
            this.textBoxSizeY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSizeX2
            // 
            this.textBoxSizeX2.Location = new System.Drawing.Point(167, 79);
            this.textBoxSizeX2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeX2.Name = "textBoxSizeX2";
            this.textBoxSizeX2.ReadOnly = true;
            this.textBoxSizeX2.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeX2.TabIndex = 19;
            this.textBoxSizeX2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSizeZ2
            // 
            this.textBoxSizeZ2.Location = new System.Drawing.Point(416, 79);
            this.textBoxSizeZ2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeZ2.Name = "textBoxSizeZ2";
            this.textBoxSizeZ2.ReadOnly = true;
            this.textBoxSizeZ2.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeZ2.TabIndex = 21;
            this.textBoxSizeZ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.textBoxSizeIntervalsZ);
            this.panel3.Controls.Add(this.textBoxSizeIntervalsY);
            this.panel3.Controls.Add(this.textBoxSizeIntervalsX);
            this.panel3.Controls.Add(this.numericUpDownNumIntZ);
            this.panel3.Controls.Add(this.numericUpDownNumIntY);
            this.panel3.Controls.Add(this.numericUpDownNumIntX);
            this.panel3.Controls.Add(this.checkBoxNumInterval);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Location = new System.Drawing.Point(11, 49);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(527, 172);
            this.panel3.TabIndex = 28;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(431, 6);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(72, 17);
            this.label24.TabIndex = 1;
            this.label24.Text = "Ось Z, мм";
            // 
            // textBoxSizeIntervalsZ
            // 
            this.textBoxSizeIntervalsZ.Location = new System.Drawing.Point(403, 133);
            this.textBoxSizeIntervalsZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeIntervalsZ.Name = "textBoxSizeIntervalsZ";
            this.textBoxSizeIntervalsZ.ReadOnly = true;
            this.textBoxSizeIntervalsZ.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeIntervalsZ.TabIndex = 22;
            this.textBoxSizeIntervalsZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSizeIntervalsY
            // 
            this.textBoxSizeIntervalsY.Location = new System.Drawing.Point(279, 133);
            this.textBoxSizeIntervalsY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeIntervalsY.Name = "textBoxSizeIntervalsY";
            this.textBoxSizeIntervalsY.ReadOnly = true;
            this.textBoxSizeIntervalsY.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeIntervalsY.TabIndex = 21;
            this.textBoxSizeIntervalsY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxSizeIntervalsX
            // 
            this.textBoxSizeIntervalsX.Location = new System.Drawing.Point(155, 133);
            this.textBoxSizeIntervalsX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeIntervalsX.Name = "textBoxSizeIntervalsX";
            this.textBoxSizeIntervalsX.ReadOnly = true;
            this.textBoxSizeIntervalsX.Size = new System.Drawing.Size(103, 22);
            this.textBoxSizeIntervalsX.TabIndex = 20;
            this.textBoxSizeIntervalsX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 138);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 17);
            this.label19.TabIndex = 5;
            this.label19.Text = "Размер интерв.";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 85);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 17);
            this.label20.TabIndex = 4;
            this.label20.Text = "Кол-во интерв.";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(8, 31);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 17);
            this.label22.TabIndex = 2;
            this.label22.Text = "Размеры модели";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(291, 5);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 17);
            this.label25.TabIndex = 1;
            this.label25.Text = "Ось Y, мм";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(167, 6);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 17);
            this.label26.TabIndex = 0;
            this.label26.Text = "Ось Х, мм";
            // 
            // Vox_model
            // 
            this.Vox_model.AccessibleName = "Vox_model";
            this.Vox_model.Controls.Add(this.label18);
            this.Vox_model.Controls.Add(this.label16);
            this.Vox_model.Controls.Add(this.textBoxTotalVox);
            this.Vox_model.Controls.Add(this.textBoxSizeZ);
            this.Vox_model.Controls.Add(this.textBoxSizeY);
            this.Vox_model.Controls.Add(this.textBoxSizeX);
            this.Vox_model.Controls.Add(this.textBoxMaxZ);
            this.Vox_model.Controls.Add(this.textBoxMaxY);
            this.Vox_model.Controls.Add(this.textBoxMaxX);
            this.Vox_model.Controls.Add(this.textBoxMinY);
            this.Vox_model.Controls.Add(this.textBoxMinX);
            this.Vox_model.Controls.Add(this.textBoxMinZ);
            this.Vox_model.Controls.Add(this.richTextBoxInfo);
            this.Vox_model.Controls.Add(this.statusStrip_CreateVox);
            this.Vox_model.Controls.Add(this.panel1);
            this.Vox_model.Controls.Add(this.toolStrip1);
            this.Vox_model.Controls.Add(this.panel2);
            this.Vox_model.Location = new System.Drawing.Point(4, 25);
            this.Vox_model.Margin = new System.Windows.Forms.Padding(4);
            this.Vox_model.Name = "Vox_model";
            this.Vox_model.Size = new System.Drawing.Size(1219, 658);
            this.Vox_model.TabIndex = 3;
            this.Vox_model.Text = "Создание воксельной модели";
            this.Vox_model.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(644, 350);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(155, 17);
            this.label18.TabIndex = 29;
            this.label18.Text = "Воксельная модель";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(35, 347);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(142, 17);
            this.label16.TabIndex = 18;
            this.label16.Text = "Исходные данные";
            // 
            // textBoxSizeZ
            // 
            this.textBoxSizeZ.Location = new System.Drawing.Point(444, 471);
            this.textBoxSizeZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeZ.Name = "textBoxSizeZ";
            this.textBoxSizeZ.ReadOnly = true;
            this.textBoxSizeZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxSizeZ.TabIndex = 11;
            this.textBoxSizeZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxSizeZ.TextChanged += new System.EventHandler(this.TextBoxSizeZ_TextChanged);
            // 
            // textBoxSizeY
            // 
            this.textBoxSizeY.Location = new System.Drawing.Point(300, 471);
            this.textBoxSizeY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeY.Name = "textBoxSizeY";
            this.textBoxSizeY.ReadOnly = true;
            this.textBoxSizeY.Size = new System.Drawing.Size(125, 22);
            this.textBoxSizeY.TabIndex = 10;
            this.textBoxSizeY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxSizeY.TextChanged += new System.EventHandler(this.TextBoxSizeY_TextChanged);
            // 
            // textBoxSizeX
            // 
            this.textBoxSizeX.Location = new System.Drawing.Point(156, 471);
            this.textBoxSizeX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSizeX.Name = "textBoxSizeX";
            this.textBoxSizeX.ReadOnly = true;
            this.textBoxSizeX.Size = new System.Drawing.Size(125, 22);
            this.textBoxSizeX.TabIndex = 9;
            this.textBoxSizeX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBoxSizeX.TextChanged += new System.EventHandler(this.TextBoxSizeX_TextChanged);
            // 
            // textBoxMaxZ
            // 
            this.textBoxMaxZ.Location = new System.Drawing.Point(444, 428);
            this.textBoxMaxZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMaxZ.Name = "textBoxMaxZ";
            this.textBoxMaxZ.ReadOnly = true;
            this.textBoxMaxZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxMaxZ.TabIndex = 8;
            this.textBoxMaxZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMaxY
            // 
            this.textBoxMaxY.Location = new System.Drawing.Point(300, 428);
            this.textBoxMaxY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMaxY.Name = "textBoxMaxY";
            this.textBoxMaxY.ReadOnly = true;
            this.textBoxMaxY.Size = new System.Drawing.Size(125, 22);
            this.textBoxMaxY.TabIndex = 7;
            this.textBoxMaxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMaxX
            // 
            this.textBoxMaxX.Location = new System.Drawing.Point(156, 428);
            this.textBoxMaxX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMaxX.Name = "textBoxMaxX";
            this.textBoxMaxX.ReadOnly = true;
            this.textBoxMaxX.Size = new System.Drawing.Size(125, 22);
            this.textBoxMaxX.TabIndex = 6;
            this.textBoxMaxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMinY
            // 
            this.textBoxMinY.Location = new System.Drawing.Point(300, 385);
            this.textBoxMinY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMinY.Name = "textBoxMinY";
            this.textBoxMinY.ReadOnly = true;
            this.textBoxMinY.Size = new System.Drawing.Size(125, 22);
            this.textBoxMinY.TabIndex = 4;
            this.textBoxMinY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMinX
            // 
            this.textBoxMinX.Location = new System.Drawing.Point(156, 385);
            this.textBoxMinX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMinX.Name = "textBoxMinX";
            this.textBoxMinX.ReadOnly = true;
            this.textBoxMinX.Size = new System.Drawing.Size(125, 22);
            this.textBoxMinX.TabIndex = 3;
            this.textBoxMinX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxMinZ
            // 
            this.textBoxMinZ.Location = new System.Drawing.Point(444, 385);
            this.textBoxMinZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMinZ.Name = "textBoxMinZ";
            this.textBoxMinZ.ReadOnly = true;
            this.textBoxMinZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxMinZ.TabIndex = 5;
            this.textBoxMinZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // richTextBoxInfo
            // 
            this.richTextBoxInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBoxInfo.Location = new System.Drawing.Point(4, 34);
            this.richTextBoxInfo.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBoxInfo.Name = "richTextBoxInfo";
            this.richTextBoxInfo.ReadOnly = true;
            this.richTextBoxInfo.Size = new System.Drawing.Size(1207, 301);
            this.richTextBoxInfo.TabIndex = 2;
            this.richTextBoxInfo.Text = "";
            // 
            // statusStrip_CreateVox
            // 
            this.statusStrip_CreateVox.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip_CreateVox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarCreateVoxel,
            this.toolStripStatusLabelCreateVoxel});
            this.statusStrip_CreateVox.Location = new System.Drawing.Point(0, 629);
            this.statusStrip_CreateVox.Name = "statusStrip_CreateVox";
            this.statusStrip_CreateVox.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip_CreateVox.Size = new System.Drawing.Size(1219, 29);
            this.statusStrip_CreateVox.TabIndex = 1;
            this.statusStrip_CreateVox.Text = "statusStrip1";
            // 
            // toolStripProgressBarCreateVoxel
            // 
            this.toolStripProgressBarCreateVoxel.MarqueeAnimationSpeed = 10;
            this.toolStripProgressBarCreateVoxel.Name = "toolStripProgressBarCreateVoxel";
            this.toolStripProgressBarCreateVoxel.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarCreateVoxel.Step = 1;
            // 
            // toolStripStatusLabelCreateVoxel
            // 
            this.toolStripStatusLabelCreateVoxel.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabelCreateVoxel.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelCreateVoxel.Name = "toolStripStatusLabelCreateVoxel";
            this.toolStripStatusLabelCreateVoxel.Size = new System.Drawing.Size(202, 24);
            this.toolStripStatusLabelCreateVoxel.Text = "Массив данных не создан  ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.numericUpDownVoxZ);
            this.panel1.Controls.Add(this.numericUpDownVoxY);
            this.panel1.Controls.Add(this.numericUpDownVoxX);
            this.panel1.Controls.Add(this.checkBoxVox);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(20, 357);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(566, 251);
            this.panel1.TabIndex = 16;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 212);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(228, 17);
            this.label15.TabIndex = 6;
            this.label15.Text = "Расчетное количество вокселей:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 164);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Воксель";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 118);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Размеры";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 75);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "Макс.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 32);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Мин.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(447, 6);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ось Z, мм";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(305, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ось Y, мм";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ось Х, мм";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Calculate_size,
            this.toolStripSeparator4,
            this.toolStripSeparator5,
            this.toolStripButtonCreateVoxModel,
            this.toolStripSeparator6,
            this.toolStripSeparator7,
            this.toolStripButtonASC,
            this.toolStripSeparator9,
            this.toolStripButtonVerification,
            this.toolStripSeparator10,
            this.toolStripSeparator11,
            this.toolStripButtonSaveVoxModel,
            this.toolStripSeparator41,
            this.toolStripButtonOpenVoxModel,
            this.toolStripSeparator8,
            this.toolStripSeparator40});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1219, 27);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Calculate_size
            // 
            this.Calculate_size.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Calculate_size.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Calculate_size.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Calculate_size.Name = "Calculate_size";
            this.Calculate_size.Size = new System.Drawing.Size(98, 24);
            this.Calculate_size.Text = "Исх. данные";
            this.Calculate_size.ToolTipText = "Исходные данные для расчетов";
            this.Calculate_size.Click += new System.EventHandler(this.Calculate_size_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButtonCreateVoxModel
            // 
            this.toolStripButtonCreateVoxModel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonCreateVoxModel.Enabled = false;
            this.toolStripButtonCreateVoxModel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCreateVoxModel.Name = "toolStripButtonCreateVoxModel";
            this.toolStripButtonCreateVoxModel.Size = new System.Drawing.Size(223, 24);
            this.toolStripButtonCreateVoxModel.Text = "Создание воксельной модели";
            this.toolStripButtonCreateVoxModel.Click += new System.EventHandler(this.ToolStripButtonCreateVoxModel_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButtonASC
            // 
            this.toolStripButtonASC.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonASC.Enabled = false;
            this.toolStripButtonASC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonASC.Name = "toolStripButtonASC";
            this.toolStripButtonASC.Size = new System.Drawing.Size(157, 24);
            this.toolStripButtonASC.Text = "Сохранить файл ASC";
            this.toolStripButtonASC.ToolTipText = "Сохранение воксельной модели в ASC-файле";
            this.toolStripButtonASC.Click += new System.EventHandler(this.ToolStripButton3_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButtonVerification
            // 
            this.toolStripButtonVerification.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonVerification.Enabled = false;
            this.toolStripButtonVerification.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonVerification.Name = "toolStripButtonVerification";
            this.toolStripButtonVerification.Size = new System.Drawing.Size(82, 24);
            this.toolStripButtonVerification.Text = "Проверка";
            this.toolStripButtonVerification.ToolTipText = "Проверка воксельной модели";
            this.toolStripButtonVerification.Click += new System.EventHandler(this.ToolStripButtonVerification_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButtonSaveVoxModel
            // 
            this.toolStripButtonSaveVoxModel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonSaveVoxModel.Enabled = false;
            this.toolStripButtonSaveVoxModel.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveVoxModel.Image")));
            this.toolStripButtonSaveVoxModel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveVoxModel.Name = "toolStripButtonSaveVoxModel";
            this.toolStripButtonSaveVoxModel.Size = new System.Drawing.Size(143, 24);
            this.toolStripButtonSaveVoxModel.Text = "Сохранить модель";
            this.toolStripButtonSaveVoxModel.Click += new System.EventHandler(this.ToolStripButton6_Click);
            // 
            // toolStripSeparator41
            // 
            this.toolStripSeparator41.Name = "toolStripSeparator41";
            this.toolStripSeparator41.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButtonOpenVoxModel
            // 
            this.toolStripButtonOpenVoxModel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonOpenVoxModel.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonOpenVoxModel.Image")));
            this.toolStripButtonOpenVoxModel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOpenVoxModel.Name = "toolStripButtonOpenVoxModel";
            this.toolStripButtonOpenVoxModel.Size = new System.Drawing.Size(127, 24);
            this.toolStripButtonOpenVoxModel.Text = "Открыть модель";
            this.toolStripButtonOpenVoxModel.Click += new System.EventHandler(this.ToolStripButtonOpenVoxModel_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripSeparator40
            // 
            this.toolStripSeparator40.Name = "toolStripSeparator40";
            this.toolStripSeparator40.Size = new System.Drawing.Size(6, 27);
            // 
            // panel2
            // 
            this.panel2.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBoxErrorZ);
            this.panel2.Controls.Add(this.textBoxErrorY);
            this.panel2.Controls.Add(this.textBoxErrorX);
            this.panel2.Controls.Add(this.textBoxTotalVoxRez);
            this.panel2.Controls.Add(this.textBoxVoxSizeZ);
            this.panel2.Controls.Add(this.textBoxVoxSizeY);
            this.panel2.Controls.Add(this.textBoxVoxSizeX);
            this.panel2.Controls.Add(this.textBoxVoxMaxZ);
            this.panel2.Controls.Add(this.textBoxVoxMaxY);
            this.panel2.Controls.Add(this.textBoxVoxMaxX);
            this.panel2.Controls.Add(this.textBoxVoxMinY);
            this.panel2.Controls.Add(this.textBoxVoxMinX);
            this.panel2.Controls.Add(this.textBoxVoxMinZ);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Location = new System.Drawing.Point(629, 357);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(566, 251);
            this.panel2.TabIndex = 17;
            // 
            // textBoxErrorZ
            // 
            this.textBoxErrorZ.Location = new System.Drawing.Point(421, 162);
            this.textBoxErrorZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxErrorZ.Name = "textBoxErrorZ";
            this.textBoxErrorZ.ReadOnly = true;
            this.textBoxErrorZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxErrorZ.TabIndex = 28;
            this.textBoxErrorZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxErrorY
            // 
            this.textBoxErrorY.Location = new System.Drawing.Point(277, 162);
            this.textBoxErrorY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxErrorY.Name = "textBoxErrorY";
            this.textBoxErrorY.ReadOnly = true;
            this.textBoxErrorY.Size = new System.Drawing.Size(125, 22);
            this.textBoxErrorY.TabIndex = 27;
            this.textBoxErrorY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxErrorX
            // 
            this.textBoxErrorX.Location = new System.Drawing.Point(133, 162);
            this.textBoxErrorX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxErrorX.Name = "textBoxErrorX";
            this.textBoxErrorX.ReadOnly = true;
            this.textBoxErrorX.Size = new System.Drawing.Size(125, 22);
            this.textBoxErrorX.TabIndex = 26;
            this.textBoxErrorX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxSizeZ
            // 
            this.textBoxVoxSizeZ.Location = new System.Drawing.Point(421, 114);
            this.textBoxVoxSizeZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxSizeZ.Name = "textBoxVoxSizeZ";
            this.textBoxVoxSizeZ.ReadOnly = true;
            this.textBoxVoxSizeZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxSizeZ.TabIndex = 24;
            this.textBoxVoxSizeZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxSizeY
            // 
            this.textBoxVoxSizeY.Location = new System.Drawing.Point(277, 114);
            this.textBoxVoxSizeY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxSizeY.Name = "textBoxVoxSizeY";
            this.textBoxVoxSizeY.ReadOnly = true;
            this.textBoxVoxSizeY.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxSizeY.TabIndex = 23;
            this.textBoxVoxSizeY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxSizeX
            // 
            this.textBoxVoxSizeX.Location = new System.Drawing.Point(133, 114);
            this.textBoxVoxSizeX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxSizeX.Name = "textBoxVoxSizeX";
            this.textBoxVoxSizeX.ReadOnly = true;
            this.textBoxVoxSizeX.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxSizeX.TabIndex = 22;
            this.textBoxVoxSizeX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMaxZ
            // 
            this.textBoxVoxMaxZ.Location = new System.Drawing.Point(421, 71);
            this.textBoxVoxMaxZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMaxZ.Name = "textBoxVoxMaxZ";
            this.textBoxVoxMaxZ.ReadOnly = true;
            this.textBoxVoxMaxZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMaxZ.TabIndex = 21;
            this.textBoxVoxMaxZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMaxY
            // 
            this.textBoxVoxMaxY.Location = new System.Drawing.Point(277, 71);
            this.textBoxVoxMaxY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMaxY.Name = "textBoxVoxMaxY";
            this.textBoxVoxMaxY.ReadOnly = true;
            this.textBoxVoxMaxY.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMaxY.TabIndex = 20;
            this.textBoxVoxMaxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMaxX
            // 
            this.textBoxVoxMaxX.Location = new System.Drawing.Point(133, 71);
            this.textBoxVoxMaxX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMaxX.Name = "textBoxVoxMaxX";
            this.textBoxVoxMaxX.ReadOnly = true;
            this.textBoxVoxMaxX.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMaxX.TabIndex = 19;
            this.textBoxVoxMaxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMinY
            // 
            this.textBoxVoxMinY.Location = new System.Drawing.Point(277, 28);
            this.textBoxVoxMinY.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMinY.Name = "textBoxVoxMinY";
            this.textBoxVoxMinY.ReadOnly = true;
            this.textBoxVoxMinY.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMinY.TabIndex = 17;
            this.textBoxVoxMinY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMinX
            // 
            this.textBoxVoxMinX.Location = new System.Drawing.Point(133, 28);
            this.textBoxVoxMinX.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMinX.Name = "textBoxVoxMinX";
            this.textBoxVoxMinX.ReadOnly = true;
            this.textBoxVoxMinX.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMinX.TabIndex = 16;
            this.textBoxVoxMinX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxVoxMinZ
            // 
            this.textBoxVoxMinZ.Location = new System.Drawing.Point(421, 28);
            this.textBoxVoxMinZ.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxVoxMinZ.Name = "textBoxVoxMinZ";
            this.textBoxVoxMinZ.ReadOnly = true;
            this.textBoxVoxMinZ.Size = new System.Drawing.Size(125, 22);
            this.textBoxVoxMinZ.TabIndex = 18;
            this.textBoxVoxMinZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 212);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(201, 17);
            this.label17.TabIndex = 14;
            this.label17.Text = "Количество/объем вокселей:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 121);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 4;
            this.label9.Text = "Размеры";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 75);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 17);
            this.label10.TabIndex = 3;
            this.label10.Text = "Макс.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 32);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Мин.";
            // 
            // ImportSTL
            // 
            this.ImportSTL.Controls.Add(this.statusStrip1);
            this.ImportSTL.Controls.Add(this.dataGridView1);
            this.ImportSTL.Controls.Add(this.bindingNavigator1);
            this.ImportSTL.Location = new System.Drawing.Point(4, 25);
            this.ImportSTL.Margin = new System.Windows.Forms.Padding(4);
            this.ImportSTL.Name = "ImportSTL";
            this.ImportSTL.Size = new System.Drawing.Size(1219, 658);
            this.ImportSTL.TabIndex = 0;
            this.ImportSTL.Text = "Импорт STL в БД";
            this.ImportSTL.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarCreateTable,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 629);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1219, 29);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBarCreateTable
            // 
            this.toolStripProgressBarCreateTable.Name = "toolStripProgressBarCreateTable";
            this.toolStripProgressBarCreateTable.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarCreateTable.Step = 1;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(194, 24);
            this.toolStripStatusLabel2.Text = "Массив данных не создан ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 31);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1229, 609);
            this.dataGridView1.TabIndex = 1;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.CountItem = null;
            this.bindingNavigator1.CountItemFormat = "/ {0}";
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripSeparator1,
            this.toolStripComboBox3,
            this.toolStripSeparator21,
            this.toolStripSeparator17,
            this.toolStripButton4,
            this.toolStripButtonSave,
            this.toolStripTextBox2});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = null;
            this.bindingNavigator1.MoveLastItem = null;
            this.bindingNavigator1.MoveNextItem = null;
            this.bindingNavigator1.MovePreviousItem = null;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = null;
            this.bindingNavigator1.Size = new System.Drawing.Size(1219, 28);
            this.bindingNavigator1.TabIndex = 2;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(307, 25);
            this.toolStripButton2.Text = "Создание таблицы данных треугольников";
            this.toolStripButton2.Click += new System.EventHandler(this.ToolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBox3
            // 
            this.toolStripComboBox3.DropDownWidth = 250;
            this.toolStripComboBox3.Items.AddRange(new object[] {
            "1. Просмотр в таблице",
            "2. Просмотр и записать в файл",
            "3. Записать в массив для расчетов"});
            this.toolStripComboBox3.Name = "toolStripComboBox3";
            this.toolStripComboBox3.Size = new System.Drawing.Size(292, 28);
            this.toolStripComboBox3.Text = "3. Записать в массив для расчетов";
            this.toolStripComboBox3.ToolTipText = "Выбор операции";
            this.toolStripComboBox3.TextChanged += new System.EventHandler(this.ToolStripComboBox3_TextChanged);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(24, 25);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Расчет свойств";
            this.toolStripButton4.Click += new System.EventHandler(this.ToolStripButton4_Click);
            // 
            // toolStripButtonSave
            // 
            this.toolStripButtonSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSave.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave.Image")));
            this.toolStripButtonSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave.Name = "toolStripButtonSave";
            this.toolStripButtonSave.Size = new System.Drawing.Size(24, 25);
            this.toolStripButtonSave.Text = "Создание массива для расчетов";
            this.toolStripButtonSave.ToolTipText = "Сохранение БД";
            this.toolStripButtonSave.Click += new System.EventHandler(this.ToolStripButton5_Click);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(132, 28);
            this.toolStripTextBox2.Text = "10";
            // 
            // OpenSTL
            // 
            this.OpenSTL.Controls.Add(this.richTextBox_review);
            this.OpenSTL.Controls.Add(this.toolStrip_OpenSTL);
            this.OpenSTL.Controls.Add(this.statusStrip_OpenSTL);
            this.OpenSTL.Location = new System.Drawing.Point(4, 25);
            this.OpenSTL.Margin = new System.Windows.Forms.Padding(4);
            this.OpenSTL.Name = "OpenSTL";
            this.OpenSTL.Size = new System.Drawing.Size(1219, 658);
            this.OpenSTL.TabIndex = 0;
            this.OpenSTL.Text = "Открыть STL";
            this.OpenSTL.UseVisualStyleBackColor = true;
            // 
            // richTextBox_review
            // 
            this.richTextBox_review.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox_review.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_review.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox_review.Location = new System.Drawing.Point(0, 28);
            this.richTextBox_review.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox_review.Name = "richTextBox_review";
            this.richTextBox_review.Size = new System.Drawing.Size(1219, 601);
            this.richTextBox_review.TabIndex = 0;
            this.richTextBox_review.Text = "Не выбран файл...";
            this.richTextBox_review.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // toolStrip_OpenSTL
            // 
            this.toolStrip_OpenSTL.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip_OpenSTL.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip_OpenSTL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator62,
            this.toolStripTextBoxFileName,
            this.toolStripSeparator3,
            this.toolStripTextBoxVol,
            this.toolStripComboBox1,
            this.toolStripSeparator37,
            this.toolStripComboBox2,
            this.toolStripSeparator35,
            this.toolStripDropDownButton1,
            this.toolStripSeparator36,
            this.toolStripSeparator63});
            this.toolStrip_OpenSTL.Location = new System.Drawing.Point(0, 0);
            this.toolStrip_OpenSTL.Name = "toolStrip_OpenSTL";
            this.toolStrip_OpenSTL.Size = new System.Drawing.Size(1219, 28);
            this.toolStrip_OpenSTL.TabIndex = 1;
            this.toolStrip_OpenSTL.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Red;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(71, 25);
            this.toolStripButton1.Text = "Открыть";
            this.toolStripButton1.ToolTipText = "Выбрать STL-файл";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // toolStripSeparator62
            // 
            this.toolStripSeparator62.Name = "toolStripSeparator62";
            this.toolStripSeparator62.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripTextBoxFileName
            // 
            this.toolStripTextBoxFileName.AutoToolTip = true;
            this.toolStripTextBoxFileName.Name = "toolStripTextBoxFileName";
            this.toolStripTextBoxFileName.ReadOnly = true;
            this.toolStripTextBoxFileName.Size = new System.Drawing.Size(399, 28);
            this.toolStripTextBoxFileName.ToolTipText = "Путь к файлу";
            this.toolStripTextBoxFileName.Click += new System.EventHandler(this.ToolStripTextBoxFileName_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripTextBoxVol
            // 
            this.toolStripTextBoxVol.AutoToolTip = true;
            this.toolStripTextBoxVol.MaxLength = 3;
            this.toolStripTextBoxVol.Name = "toolStripTextBoxVol";
            this.toolStripTextBoxVol.ReadOnly = true;
            this.toolStripTextBoxVol.Size = new System.Drawing.Size(52, 28);
            this.toolStripTextBoxVol.Text = "100";
            this.toolStripTextBoxVol.ToolTipText = "Количество строк для просмотра (1...999)";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.AutoToolTip = true;
            this.toolStripComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "количество строк",
            "весь файл"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(159, 28);
            this.toolStripComboBox1.Text = "количество строк";
            this.toolStripComboBox1.ToolTipText = "0";
            this.toolStripComboBox1.TextChanged += new System.EventHandler(this.ToolStripComboBox1_TextChanged);
            // 
            // toolStripSeparator37
            // 
            this.toolStripSeparator37.Name = "toolStripSeparator37";
            this.toolStripSeparator37.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripComboBox2
            // 
            this.toolStripComboBox2.AutoToolTip = true;
            this.toolStripComboBox2.DropDownWidth = 220;
            this.toolStripComboBox2.IntegralHeight = false;
            this.toolStripComboBox2.Items.AddRange(new object[] {
            "1. Текстовый формат файла (ASCII)",
            "2. Бинарный формат файла (Binary)"});
            this.toolStripComboBox2.MaxDropDownItems = 2;
            this.toolStripComboBox2.Name = "toolStripComboBox2";
            this.toolStripComboBox2.Size = new System.Drawing.Size(299, 28);
            this.toolStripComboBox2.Text = "2. Бинарный формат файла (Binary)";
            this.toolStripComboBox2.ToolTipText = "Выбор STL формата";
            // 
            // toolStripSeparator35
            // 
            this.toolStripSeparator35.Name = "toolStripSeparator35";
            this.toolStripSeparator35.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.блокнотToolStripMenuItem,
            this.magicsToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(123, 25);
            this.toolStripDropDownButton1.Text = "Просмотр...";
            // 
            // блокнотToolStripMenuItem
            // 
            this.блокнотToolStripMenuItem.Name = "блокнотToolStripMenuItem";
            this.блокнотToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.блокнотToolStripMenuItem.Text = "Блокнот";
            this.блокнотToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // magicsToolStripMenuItem
            // 
            this.magicsToolStripMenuItem.Name = "magicsToolStripMenuItem";
            this.magicsToolStripMenuItem.Size = new System.Drawing.Size(141, 26);
            this.magicsToolStripMenuItem.Text = "Magics";
            this.magicsToolStripMenuItem.Click += new System.EventHandler(this.MagicsToolStripMenuItem_Click);
            // 
            // toolStripSeparator36
            // 
            this.toolStripSeparator36.Name = "toolStripSeparator36";
            this.toolStripSeparator36.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripSeparator63
            // 
            this.toolStripSeparator63.Name = "toolStripSeparator63";
            this.toolStripSeparator63.Size = new System.Drawing.Size(6, 28);
            // 
            // statusStrip_OpenSTL
            // 
            this.statusStrip_OpenSTL.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip_OpenSTL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBarOpenSTL,
            this.toolStripStatusLabel_time_loud,
            this.toolStripStatusLabel_info});
            this.statusStrip_OpenSTL.Location = new System.Drawing.Point(0, 629);
            this.statusStrip_OpenSTL.Name = "statusStrip_OpenSTL";
            this.statusStrip_OpenSTL.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip_OpenSTL.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.statusStrip_OpenSTL.Size = new System.Drawing.Size(1219, 29);
            this.statusStrip_OpenSTL.TabIndex = 2;
            this.statusStrip_OpenSTL.Text = "statusStrip1";
            // 
            // toolStripProgressBarOpenSTL
            // 
            this.toolStripProgressBarOpenSTL.MarqueeAnimationSpeed = 50;
            this.toolStripProgressBarOpenSTL.Name = "toolStripProgressBarOpenSTL";
            this.toolStripProgressBarOpenSTL.Size = new System.Drawing.Size(533, 23);
            this.toolStripProgressBarOpenSTL.Step = 1;
            // 
            // toolStripStatusLabel_time_loud
            // 
            this.toolStripStatusLabel_time_loud.Name = "toolStripStatusLabel_time_loud";
            this.toolStripStatusLabel_time_loud.Size = new System.Drawing.Size(13, 24);
            this.toolStripStatusLabel_time_loud.Text = " ";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(178, 24);
            this.toolStripStatusLabel_info.Text = "Количество символов: 0";
            // 
            // tabControlCreationVoxelModel
            // 
            this.tabControlCreationVoxelModel.Controls.Add(this.OpenSTL);
            this.tabControlCreationVoxelModel.Controls.Add(this.ImportSTL);
            this.tabControlCreationVoxelModel.Controls.Add(this.Vox_model);
            this.tabControlCreationVoxelModel.Controls.Add(this.AnalVox);
            this.tabControlCreationVoxelModel.Controls.Add(this.AnalLocation);
            this.tabControlCreationVoxelModel.Controls.Add(this.AnalLayer);
            this.tabControlCreationVoxelModel.Controls.Add(this.analOrient);
            this.tabControlCreationVoxelModel.Controls.Add(this.AnalColorVisual);
            this.tabControlCreationVoxelModel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlCreationVoxelModel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControlCreationVoxelModel.Location = new System.Drawing.Point(0, 0);
            this.tabControlCreationVoxelModel.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlCreationVoxelModel.Name = "tabControlCreationVoxelModel";
            this.tabControlCreationVoxelModel.SelectedIndex = 0;
            this.tabControlCreationVoxelModel.Size = new System.Drawing.Size(1227, 687);
            this.tabControlCreationVoxelModel.TabIndex = 0;
            // 
            // NumLayer
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.NumLayer.DefaultCellStyle = dataGridViewCellStyle1;
            this.NumLayer.FillWeight = 55F;
            this.NumLayer.Frozen = true;
            this.NumLayer.HeaderText = "Номер";
            this.NumLayer.MaxInputLength = 8;
            this.NumLayer.Name = "NumLayer";
            this.NumLayer.ReadOnly = true;
            this.NumLayer.ToolTipText = "Номер слоя";
            this.NumLayer.Width = 55;
            // 
            // HeightLayer
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.HeightLayer.DefaultCellStyle = dataGridViewCellStyle2;
            this.HeightLayer.FillWeight = 50F;
            this.HeightLayer.Frozen = true;
            this.HeightLayer.HeaderText = "h";
            this.HeightLayer.MaxInputLength = 8;
            this.HeightLayer.Name = "HeightLayer";
            this.HeightLayer.ReadOnly = true;
            this.HeightLayer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HeightLayer.ToolTipText = "Высота слоя";
            this.HeightLayer.Width = 50;
            // 
            // HeightPlaсement
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.HeightPlaсement.DefaultCellStyle = dataGridViewCellStyle3;
            this.HeightPlaсement.FillWeight = 50F;
            this.HeightPlaсement.Frozen = true;
            this.HeightPlaсement.HeaderText = "Z";
            this.HeightPlaсement.MaxInputLength = 8;
            this.HeightPlaсement.MinimumWidth = 40;
            this.HeightPlaсement.Name = "HeightPlaсement";
            this.HeightPlaсement.ReadOnly = true;
            this.HeightPlaсement.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HeightPlaсement.ToolTipText = "Координата расположения слоя по оси Z";
            this.HeightPlaсement.Width = 50;
            // 
            // P
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.NullValue = null;
            this.P.DefaultCellStyle = dataGridViewCellStyle4;
            this.P.FillWeight = 65F;
            this.P.Frozen = true;
            this.P.HeaderText = "Периметр";
            this.P.MaxInputLength = 10;
            this.P.Name = "P";
            this.P.ReadOnly = true;
            this.P.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.P.ToolTipText = "Периметр контура";
            this.P.Width = 65;
            // 
            // Ssection
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Ssection.DefaultCellStyle = dataGridViewCellStyle5;
            this.Ssection.FillWeight = 80F;
            this.Ssection.Frozen = true;
            this.Ssection.HeaderText = "Площадь";
            this.Ssection.MaxInputLength = 12;
            this.Ssection.MinimumWidth = 55;
            this.Ssection.Name = "Ssection";
            this.Ssection.ReadOnly = true;
            this.Ssection.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Ssection.ToolTipText = "Площадь сечения модели";
            this.Ssection.Width = 80;
            // 
            // centroidOfArea
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.centroidOfArea.DefaultCellStyle = dataGridViewCellStyle6;
            this.centroidOfArea.FillWeight = 120F;
            this.centroidOfArea.HeaderText = "Центр тяжести";
            this.centroidOfArea.MaxInputLength = 20;
            this.centroidOfArea.Name = "centroidOfArea";
            this.centroidOfArea.ReadOnly = true;
            this.centroidOfArea.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.centroidOfArea.ToolTipText = "Центр тяжести сечения";
            this.centroidOfArea.Width = 140;
            // 
            // Delta
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Delta.DefaultCellStyle = dataGridViewCellStyle7;
            this.Delta.HeaderText = "Смещение L0";
            this.Delta.MaxInputLength = 20;
            this.Delta.Name = "Delta";
            this.Delta.ReadOnly = true;
            this.Delta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Delta.ToolTipText = "Величина смещения центра тяжести сечения от общего центра";
            // 
            // Fractal_Size_Scale
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Fractal_Size_Scale.DefaultCellStyle = dataGridViewCellStyle8;
            this.Fractal_Size_Scale.HeaderText = "Фракт.разм.(метод масштабов)";
            this.Fractal_Size_Scale.MaxInputLength = 20;
            this.Fractal_Size_Scale.Name = "Fractal_Size_Scale";
            this.Fractal_Size_Scale.ReadOnly = true;
            this.Fractal_Size_Scale.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Fractal_Size_Scale.ToolTipText = "Фрактальная размерность (метод масштабов)";
            // 
            // Fractal_Size_Square
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Fractal_Size_Square.DefaultCellStyle = dataGridViewCellStyle9;
            this.Fractal_Size_Square.HeaderText = "Фракт.разм.(клет.метод)";
            this.Fractal_Size_Square.MaxInputLength = 20;
            this.Fractal_Size_Square.Name = "Fractal_Size_Square";
            this.Fractal_Size_Square.ReadOnly = true;
            this.Fractal_Size_Square.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Fractal_Size_Square.ToolTipText = "Фрактальная размерность (клеточный метод)";
            // 
            // Nz
            // 
            this.Nz.HeaderText = "Гистограмма ";
            this.Nz.MinimumWidth = 50;
            this.Nz.Name = "Nz";
            this.Nz.ReadOnly = true;
            this.Nz.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Nz.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Nz.Text = "Nz (угол между векторами Z и нормали грани)";
            // 
            // Aadjacent
            // 
            this.Aadjacent.HeaderText = "Гистограмма ";
            this.Aadjacent.Name = "Aadjacent";
            this.Aadjacent.ReadOnly = true;
            this.Aadjacent.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Aadjacent.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Aadjacent.Text = "Смежный угол между элементами контура";
            // 
            // NzMinInterval
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzMinInterval.DefaultCellStyle = dataGridViewCellStyle10;
            this.NzMinInterval.HeaderText = "Мин. Nz";
            this.NzMinInterval.MaxInputLength = 20;
            this.NzMinInterval.Name = "NzMinInterval";
            this.NzMinInterval.ReadOnly = true;
            this.NzMinInterval.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzMinInterval.ToolTipText = "Минимальная величина";
            // 
            // NzMaxInterval
            // 
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzMaxInterval.DefaultCellStyle = dataGridViewCellStyle11;
            this.NzMaxInterval.HeaderText = "Макс. Nz";
            this.NzMaxInterval.MaxInputLength = 20;
            this.NzMaxInterval.Name = "NzMaxInterval";
            this.NzMaxInterval.ReadOnly = true;
            this.NzMaxInterval.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzMaxInterval.ToolTipText = "Максимальная величина";
            // 
            // NzRange
            // 
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzRange.DefaultCellStyle = dataGridViewCellStyle12;
            this.NzRange.HeaderText = "Размах Nz";
            this.NzRange.MaxInputLength = 20;
            this.NzRange.Name = "NzRange";
            this.NzRange.ReadOnly = true;
            this.NzRange.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzRange.ToolTipText = "Размах величин";
            // 
            // NzDispersion
            // 
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzDispersion.DefaultCellStyle = dataGridViewCellStyle13;
            this.NzDispersion.HeaderText = "Дисперсия Nz";
            this.NzDispersion.MaxInputLength = 20;
            this.NzDispersion.Name = "NzDispersion";
            this.NzDispersion.ReadOnly = true;
            this.NzDispersion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzDispersion.ToolTipText = "Дисперсия";
            // 
            // NzSigma
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzSigma.DefaultCellStyle = dataGridViewCellStyle14;
            this.NzSigma.HeaderText = "Среднекв.отклон. Nz";
            this.NzSigma.MaxInputLength = 20;
            this.NzSigma.Name = "NzSigma";
            this.NzSigma.ReadOnly = true;
            this.NzSigma.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzSigma.ToolTipText = "Среднеквадратическое.отклонение";
            // 
            // NzMean
            // 
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzMean.DefaultCellStyle = dataGridViewCellStyle15;
            this.NzMean.HeaderText = "Ср. арифм. Nz";
            this.NzMean.MaxInputLength = 20;
            this.NzMean.Name = "NzMean";
            this.NzMean.ReadOnly = true;
            this.NzMean.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzMean.ToolTipText = "Среднеарифметическое значение";
            // 
            // NzKasim
            // 
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzKasim.DefaultCellStyle = dataGridViewCellStyle16;
            this.NzKasim.HeaderText = "Коэф. асиметрии Nz";
            this.NzKasim.MaxInputLength = 20;
            this.NzKasim.Name = "NzKasim";
            this.NzKasim.ReadOnly = true;
            this.NzKasim.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzKasim.ToolTipText = "Коэффициент асиметрии";
            // 
            // NzKeks
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzKeks.DefaultCellStyle = dataGridViewCellStyle17;
            this.NzKeks.HeaderText = "Коэф. эксцесса Nz";
            this.NzKeks.MaxInputLength = 20;
            this.NzKeks.Name = "NzKeks";
            this.NzKeks.ReadOnly = true;
            this.NzKeks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NzKeks.ToolTipText = "Коэффициент эксцесса";
            // 
            // NzKv
            // 
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzKv.DefaultCellStyle = dataGridViewCellStyle18;
            this.NzKv.HeaderText = "Коэффициент вариации Nz";
            this.NzKv.MaxInputLength = 20;
            this.NzKv.Name = "NzKv";
            this.NzKv.ReadOnly = true;
            this.NzKv.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // NzMeana
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzMeana.DefaultCellStyle = dataGridViewCellStyle19;
            this.NzMeana.HeaderText = "Меана Nz";
            this.NzMeana.MaxInputLength = 20;
            this.NzMeana.Name = "NzMeana";
            this.NzMeana.ReadOnly = true;
            this.NzMeana.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // NzModa
            // 
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzModa.DefaultCellStyle = dataGridViewCellStyle20;
            this.NzModa.HeaderText = "Мода Nz";
            this.NzModa.MaxInputLength = 20;
            this.NzModa.Name = "NzModa";
            this.NzModa.ReadOnly = true;
            this.NzModa.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // NzMediana
            // 
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.NzMediana.DefaultCellStyle = dataGridViewCellStyle21;
            this.NzMediana.HeaderText = "Медиана Nz";
            this.NzMediana.MaxInputLength = 20;
            this.NzMediana.Name = "NzMediana";
            this.NzMediana.ReadOnly = true;
            this.NzMediana.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AMinInterval
            // 
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AMinInterval.DefaultCellStyle = dataGridViewCellStyle22;
            this.AMinInterval.HeaderText = "Мин. А";
            this.AMinInterval.MaxInputLength = 20;
            this.AMinInterval.Name = "AMinInterval";
            this.AMinInterval.ReadOnly = true;
            this.AMinInterval.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AMinInterval.ToolTipText = "Минимальная величина";
            // 
            // AMaxInterval
            // 
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AMaxInterval.DefaultCellStyle = dataGridViewCellStyle23;
            this.AMaxInterval.HeaderText = "Макс. А";
            this.AMaxInterval.MaxInputLength = 20;
            this.AMaxInterval.Name = "AMaxInterval";
            this.AMaxInterval.ReadOnly = true;
            this.AMaxInterval.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AMaxInterval.ToolTipText = "Максимальная величина";
            // 
            // ARange
            // 
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ARange.DefaultCellStyle = dataGridViewCellStyle24;
            this.ARange.HeaderText = "Размах А";
            this.ARange.MaxInputLength = 20;
            this.ARange.Name = "ARange";
            this.ARange.ReadOnly = true;
            this.ARange.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ARange.ToolTipText = "Размах";
            // 
            // ADispersion
            // 
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ADispersion.DefaultCellStyle = dataGridViewCellStyle25;
            this.ADispersion.HeaderText = "Дисперсия А";
            this.ADispersion.MaxInputLength = 20;
            this.ADispersion.Name = "ADispersion";
            this.ADispersion.ReadOnly = true;
            this.ADispersion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ADispersion.ToolTipText = "Дисперсия";
            // 
            // ASigma
            // 
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ASigma.DefaultCellStyle = dataGridViewCellStyle26;
            this.ASigma.HeaderText = "Среднекв.отклон. А";
            this.ASigma.MaxInputLength = 20;
            this.ASigma.Name = "ASigma";
            this.ASigma.ReadOnly = true;
            this.ASigma.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ASigma.ToolTipText = "Среднеквадратическое отклонение";
            // 
            // AMean
            // 
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AMean.DefaultCellStyle = dataGridViewCellStyle27;
            this.AMean.HeaderText = "Ср. арифм. А";
            this.AMean.MaxInputLength = 20;
            this.AMean.Name = "AMean";
            this.AMean.ReadOnly = true;
            this.AMean.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AMean.ToolTipText = "Среднеарифметическое значение";
            // 
            // AKasim
            // 
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AKasim.DefaultCellStyle = dataGridViewCellStyle28;
            this.AKasim.HeaderText = "Коэф. асиметрии А";
            this.AKasim.MaxInputLength = 20;
            this.AKasim.Name = "AKasim";
            this.AKasim.ReadOnly = true;
            this.AKasim.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AKasim.ToolTipText = "Коэффициент асиметрии";
            // 
            // AKeks
            // 
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AKeks.DefaultCellStyle = dataGridViewCellStyle29;
            this.AKeks.HeaderText = "Коэф. эксцесса А";
            this.AKeks.MaxInputLength = 20;
            this.AKeks.Name = "AKeks";
            this.AKeks.ReadOnly = true;
            this.AKeks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AKeks.ToolTipText = "Коэффициент эксцесса";
            // 
            // AKv
            // 
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AKv.DefaultCellStyle = dataGridViewCellStyle30;
            this.AKv.HeaderText = "Коэф. вариации А";
            this.AKv.MaxInputLength = 20;
            this.AKv.Name = "AKv";
            this.AKv.ReadOnly = true;
            this.AKv.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AKv.ToolTipText = "Коэффициент вариации";
            // 
            // AMeana
            // 
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AMeana.DefaultCellStyle = dataGridViewCellStyle31;
            this.AMeana.HeaderText = "Меана А";
            this.AMeana.MaxInputLength = 20;
            this.AMeana.Name = "AMeana";
            this.AMeana.ReadOnly = true;
            this.AMeana.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AModa
            // 
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AModa.DefaultCellStyle = dataGridViewCellStyle32;
            this.AModa.HeaderText = "Мода А";
            this.AModa.MaxInputLength = 20;
            this.AModa.Name = "AModa";
            this.AModa.ReadOnly = true;
            this.AModa.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AMediana
            // 
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AMediana.DefaultCellStyle = dataGridViewCellStyle33;
            this.AMediana.HeaderText = "Медиана А";
            this.AMediana.MaxInputLength = 20;
            this.AMediana.Name = "AMediana";
            this.AMediana.ReadOnly = true;
            this.AMediana.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EMinInterval
            // 
            this.EMinInterval.HeaderText = "Мин. Е";
            this.EMinInterval.MaxInputLength = 20;
            this.EMinInterval.Name = "EMinInterval";
            this.EMinInterval.ReadOnly = true;
            this.EMinInterval.ToolTipText = "Минимальная величина отклонения формы";
            // 
            // EMaxInterval
            // 
            this.EMaxInterval.HeaderText = "Макс. Е";
            this.EMaxInterval.MaxInputLength = 20;
            this.EMaxInterval.Name = "EMaxInterval";
            this.EMaxInterval.ReadOnly = true;
            this.EMaxInterval.ToolTipText = "Максимальная величина отклонения формы";
            // 
            // ERange
            // 
            this.ERange.HeaderText = "Размах Е";
            this.ERange.MaxInputLength = 20;
            this.ERange.Name = "ERange";
            this.ERange.ReadOnly = true;
            this.ERange.ToolTipText = "Размах отклонения формы";
            // 
            // EDispersion
            // 
            this.EDispersion.HeaderText = "Дисперсия E";
            this.EDispersion.MaxInputLength = 20;
            this.EDispersion.Name = "EDispersion";
            this.EDispersion.ReadOnly = true;
            this.EDispersion.ToolTipText = "Дисперсия отклонения формы";
            // 
            // ESigma
            // 
            this.ESigma.HeaderText = "Среднекв.отклон. Е";
            this.ESigma.MaxInputLength = 20;
            this.ESigma.Name = "ESigma";
            this.ESigma.ReadOnly = true;
            this.ESigma.ToolTipText = "Среднеквадратическое отклонение";
            // 
            // EMean
            // 
            this.EMean.HeaderText = "Ср. арифм. E";
            this.EMean.MaxInputLength = 20;
            this.EMean.Name = "EMean";
            this.EMean.ReadOnly = true;
            this.EMean.ToolTipText = "Среднеарифметическое значение";
            // 
            // EKasim
            // 
            this.EKasim.HeaderText = "Коэф. асиметрии E";
            this.EKasim.MaxInputLength = 20;
            this.EKasim.Name = "EKasim";
            this.EKasim.ReadOnly = true;
            this.EKasim.ToolTipText = "Коэффициент асиметрии";
            // 
            // EKeks
            // 
            this.EKeks.HeaderText = "Коэф. эксцесса E";
            this.EKeks.MaxInputLength = 20;
            this.EKeks.Name = "EKeks";
            this.EKeks.ReadOnly = true;
            this.EKeks.ToolTipText = "Коэффициент эксцесса";
            // 
            // EKv
            // 
            this.EKv.HeaderText = "Коэф. вариации E";
            this.EKv.MaxInputLength = 20;
            this.EKv.Name = "EKv";
            this.EKv.ReadOnly = true;
            this.EKv.ToolTipText = "Коэффициент вариации";
            // 
            // EMeana
            // 
            this.EMeana.HeaderText = "Меана E";
            this.EMeana.MaxInputLength = 20;
            this.EMeana.Name = "EMeana";
            this.EMeana.ReadOnly = true;
            this.EMeana.ToolTipText = "Меана";
            // 
            // EModa
            // 
            this.EModa.HeaderText = "Мода E";
            this.EModa.MaxInputLength = 20;
            this.EModa.Name = "EModa";
            this.EModa.ReadOnly = true;
            this.EModa.ToolTipText = "Мода";
            // 
            // EMediana
            // 
            this.EMediana.HeaderText = "Медиана E";
            this.EMediana.MaxInputLength = 20;
            this.EMediana.Name = "EMediana";
            this.EMediana.ReadOnly = true;
            this.EMediana.ToolTipText = "Медиана";
            // 
            // checkBoxAnalysisErrorForm
            // 
            this.checkBoxAnalysisErrorForm.AutoSize = true;
            this.checkBoxAnalysisErrorForm.Location = new System.Drawing.Point(227, 438);
            this.checkBoxAnalysisErrorForm.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxAnalysisErrorForm.Name = "checkBoxAnalysisErrorForm";
            this.checkBoxAnalysisErrorForm.Size = new System.Drawing.Size(168, 21);
            this.checkBoxAnalysisErrorForm.TabIndex = 36;
            this.checkBoxAnalysisErrorForm.Text = "Анализ погрешности";
            this.toolTip1.SetToolTip(this.checkBoxAnalysisErrorForm, "Анализ погрешности формы");
            this.checkBoxAnalysisErrorForm.UseVisualStyleBackColor = true;
            // 
            // FormAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1227, 687);
            this.Controls.Add(this.tabControlCreationVoxelModel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1246, 727);
            this.Name = "FormAnalysis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStripHistogram.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLayerInt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntVisual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownG1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownG2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownStep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntOrientation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varAngleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varAngleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varAngleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varAngleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varAngleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varAngleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varRelSMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1varRelSMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varRelSMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2varRelSMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varRelSMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3varRelSMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumIntZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelYRelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelZRelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXRelation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXYZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelXYZRelative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartHistogramVoxelX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVoxZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountFractalAnalysis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCurentFractalAnalysis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRatioRtoL)).EndInit();
            this.contextMenuStripdataGrid.ResumeLayout(false);
            this.AnalLayer.ResumeLayout(false);
            this.AnalLayer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSetLayer)).EndInit();
            this.statusStripLayerAnalysis.ResumeLayout(false);
            this.statusStripLayerAnalysis.PerformLayout();
            this.panelReviewContourSection.ResumeLayout(false);
            this.panelReviewContourSection.PerformLayout();
            this.toolStripLayerAnalysis.ResumeLayout(false);
            this.toolStripLayerAnalysis.PerformLayout();
            this.AnalColorVisual.ResumeLayout(false);
            this.AnalColorVisual.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIntervals)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVariantsVisualization)).EndInit();
            this.toolStripColorVisual.ResumeLayout(false);
            this.toolStripColorVisual.PerformLayout();
            this.analOrient.ResumeLayout(false);
            this.analOrient.PerformLayout();
            this.statusStrip3.ResumeLayout(false);
            this.statusStrip3.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrientation)).EndInit();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.AnalLocation.ResumeLayout(false);
            this.AnalLocation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFront)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRight)).EndInit();
            this.statusStrip5.ResumeLayout(false);
            this.statusStrip5.PerformLayout();
            this.toolStripLocation.ResumeLayout(false);
            this.toolStripLocation.PerformLayout();
            this.AnalVox.ResumeLayout(false);
            this.AnalVox.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Vox_model.ResumeLayout(false);
            this.Vox_model.PerformLayout();
            this.statusStrip_CreateVox.ResumeLayout(false);
            this.statusStrip_CreateVox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ImportSTL.ResumeLayout(false);
            this.ImportSTL.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.OpenSTL.ResumeLayout(false);
            this.OpenSTL.PerformLayout();
            this.toolStrip_OpenSTL.ResumeLayout(false);
            this.toolStrip_OpenSTL.PerformLayout();
            this.statusStrip_OpenSTL.ResumeLayout(false);
            this.statusStrip_OpenSTL.PerformLayout();
            this.tabControlCreationVoxelModel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SaveFileDialog saveFileDialogU;
        private System.Windows.Forms.OpenFileDialog openFileDialogU;
        private System.Windows.Forms.Timer timer1;
        //private System.Windows.Forms.BindingSource sysParamBindingSource;
        //private SLSDataSet sLSDataSet;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripHistogram;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem исходныеДанныепоказатьскрытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox ToolStripMenuItemColorSсhemе;
        private System.Windows.Forms.ToolStripComboBox ToolStripMenuItemTypeDiagram;
        private System.Windows.Forms.SaveFileDialog saveFileDialogPly;
        public System.Windows.Forms.ColorDialog colorDialogSelect;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripdataGrid;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemShow;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemReduce;
        public System.Windows.Forms.TabPage AnalLayer;
        private System.Windows.Forms.StatusStrip statusStripLayerAnalysis;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarLayerAnalysis;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLayerAnalysis;
        private System.Windows.Forms.DataGridView dataGridViewSetLayer;
        private System.Windows.Forms.Label labelCountInt;
        private System.Windows.Forms.NumericUpDown numericUpDownLayerInt;
        private System.Windows.Forms.CheckBox checkBoxOneOrAll;
        private System.Windows.Forms.CheckBox checkBoxPreview;
        private System.Windows.Forms.Panel panelReviewContourSection;
        private System.Windows.Forms.ToolStrip toolStripLayerAnalysis;
        private System.Windows.Forms.ToolStripButton toolStripButtonLayerCreate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator55;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxLayerAnalysis;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator56;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxMinStep;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator57;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxMaxStep;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator61;
        private System.Windows.Forms.ToolStripButton toolStripButtonColorLine;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxScale;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator58;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator59;
        private System.Windows.Forms.ToolStripButton toolStripButtonLayerAnalysis;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator60;
        private System.Windows.Forms.ToolStripButton toolStripButtonLayerSave;
        /// <summary>
        /// Подсистема цветовой визуализации
        /// </summary>
        public System.Windows.Forms.TabPage AnalColorVisual;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarVisualization;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelColorVisual;
        private System.Windows.Forms.Button buttonXls;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridViewIntervals;
        private System.Windows.Forms.DataGridViewTextBoxColumn Begin;
        private System.Windows.Forms.DataGridViewTextBoxColumn R;
        private System.Windows.Forms.DataGridViewTextBoxColumn G;
        private System.Windows.Forms.DataGridViewTextBoxColumn B;
        private System.Windows.Forms.DataGridViewTextBoxColumn H;
        private System.Windows.Forms.DataGridViewTextBoxColumn S;
        private System.Windows.Forms.DataGridViewTextBoxColumn V;
        private System.Windows.Forms.DataGridViewButtonColumn SetColor;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.CheckBox checkBoxGist;
        private System.Windows.Forms.NumericUpDown numericUpDownStep;
        private System.Windows.Forms.Label labelStep;
        private System.Windows.Forms.NumericUpDown numericUpDownB2;
        private System.Windows.Forms.NumericUpDown numericUpDownG2;
        private System.Windows.Forms.NumericUpDown numericUpDownR2;
        private System.Windows.Forms.Label labelRGB2;
        private System.Windows.Forms.NumericUpDown numericUpDownB1;
        private System.Windows.Forms.NumericUpDown numericUpDownG1;
        private System.Windows.Forms.NumericUpDown numericUpDownR1;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBoxSizeInt;
        private System.Windows.Forms.TextBox textBoxRazmahPar;
        private System.Windows.Forms.NumericUpDown numericUpDownIntVisual;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label labelRGB1;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.DataGridView dataGridViewVariantsVisualization;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomVar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parametr;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameFile;
        private System.Windows.Forms.DataGridViewButtonColumn ButtonOpenFile;
        private System.Windows.Forms.DataGridViewButtonColumn ReviewGist;
        private System.Windows.Forms.DataGridViewTextBoxColumn R1;
        private System.Windows.Forms.DataGridViewTextBoxColumn G1;
        private System.Windows.Forms.DataGridViewTextBoxColumn B1;
        private System.Windows.Forms.DataGridViewTextBoxColumn R2;
        private System.Windows.Forms.DataGridViewTextBoxColumn G2;
        private System.Windows.Forms.DataGridViewTextBoxColumn B2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColIntervals;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn Range;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dispersion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sigma;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mean;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kasim;
        private System.Windows.Forms.DataGridViewTextBoxColumn Keks;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Meana;
        private System.Windows.Forms.DataGridViewTextBoxColumn Moda;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mediana;
        private System.Windows.Forms.ToolStrip toolStripColorVisual;
        private System.Windows.Forms.ToolStripButton toolStripButtonСalculate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator23;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxStrategicVisual;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator26;
        private System.Windows.Forms.ToolStripButton toolStripButtonColorVisual;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator30;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator29;
        private System.Windows.Forms.ToolStripButton toolStripButtonSavePLY;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator27;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator28;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxSelestFormatFile;
        public System.Windows.Forms.TabPage analOrient;
        private System.Windows.Forms.StatusStrip statusStrip3;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarOrientation;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelInphoOrientation;
        private System.Windows.Forms.Button buttonXlsOrient;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox checkBoxAndOrAddCondition;
        private System.Windows.Forms.CheckBox checkBox3varAddH;
        private System.Windows.Forms.CheckBox checkBox2varAddH;
        private System.Windows.Forms.CheckBox checkBox1varAddH;
        private System.Windows.Forms.NumericUpDown numericUpDownHMax;
        private System.Windows.Forms.NumericUpDown numericUpDownHMin;
        private System.Windows.Forms.Label labelRangeH;
        private System.Windows.Forms.NumericUpDown numericUpDown3varRelSMax;
        private System.Windows.Forms.NumericUpDown numericUpDown3varRelSMin;
        private System.Windows.Forms.NumericUpDown numericUpDown2varRelSMax;
        private System.Windows.Forms.NumericUpDown numericUpDown2varRelSMin;
        private System.Windows.Forms.NumericUpDown numericUpDown1varRelSMax;
        private System.Windows.Forms.NumericUpDown numericUpDown1varRelSMin;
        private System.Windows.Forms.Label labelRelSMax;
        private System.Windows.Forms.Label labelRelSMin;
        private System.Windows.Forms.Label label3varRelS;
        private System.Windows.Forms.Label label2varRelS;
        private System.Windows.Forms.Label label1varRelS;
        private System.Windows.Forms.Label labelAngleMax;
        private System.Windows.Forms.Label labelAngleMin;
        private System.Windows.Forms.NumericUpDown numericUpDown3varAngleMax;
        private System.Windows.Forms.NumericUpDown numericUpDown3varAngleMin;
        private System.Windows.Forms.NumericUpDown numericUpDown2varAngleMax;
        private System.Windows.Forms.NumericUpDown numericUpDown2varAngleMin;
        private System.Windows.Forms.NumericUpDown numericUpDown1varAngleMax;
        private System.Windows.Forms.NumericUpDown numericUpDown1varAngleMin;
        private System.Windows.Forms.CheckBox checkBox3var;
        private System.Windows.Forms.CheckBox checkBox2var;
        private System.Windows.Forms.CheckBox checkBox1var;
        private System.Windows.Forms.Label label3varRangeAngle;
        private System.Windows.Forms.Label label2varRangeAngle;
        private System.Windows.Forms.Label label1varRangeAngle;
        private System.Windows.Forms.NumericUpDown numericUpDown3varB;
        private System.Windows.Forms.NumericUpDown numericUpDown3varG;
        private System.Windows.Forms.NumericUpDown numericUpDown3varR;
        private System.Windows.Forms.NumericUpDown numericUpDown2varB;
        private System.Windows.Forms.NumericUpDown numericUpDown2varG;
        private System.Windows.Forms.NumericUpDown numericUpDown2varR;
        private System.Windows.Forms.NumericUpDown numericUpDown1varB;
        private System.Windows.Forms.NumericUpDown numericUpDown1varG;
        private System.Windows.Forms.NumericUpDown numericUpDown1varR;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelG;
        private System.Windows.Forms.Label labelR;
        private System.Windows.Forms.Label label3var;
        private System.Windows.Forms.TextBox textBoxIntOrient;
        private System.Windows.Forms.TextBox textBoxRangeOrient;
        private System.Windows.Forms.NumericUpDown numericUpDownIntOrientation;
        private System.Windows.Forms.Label labelCountIntOrientation;
        private System.Windows.Forms.Label label2var;
        private System.Windows.Forms.Label label1var;
        private System.Windows.Forms.DataGridView dataGridViewOrientation;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton toolStripButtonCalculateOrientation;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator25;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator24;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxVarCount;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator31;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxDX;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxDY;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator33;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator32;
        private System.Windows.Forms.ToolStripButton toolStripButtonColorAnalysis;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator34;
        private System.Windows.Forms.ToolStripButton toolStripButtonExpression;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator39;
        public System.Windows.Forms.TabPage AnalLocation;
        private System.Windows.Forms.PictureBox pictureBoxTop;
        private System.Windows.Forms.PictureBox pictureBoxFront;
        private System.Windows.Forms.PictureBox pictureBoxRight;
        private System.Windows.Forms.Label labelXmin;
        private System.Windows.Forms.Label labelYmin;
        private System.Windows.Forms.Label labelZmin;
        private System.Windows.Forms.Label labelYmax;
        private System.Windows.Forms.Label labelXmax;
        private System.Windows.Forms.Label labelZmax;
        private System.Windows.Forms.Label labelX2;
        private System.Windows.Forms.Label labelY2;
        private System.Windows.Forms.Label labelX1;
        private System.Windows.Forms.Label labelY1;
        private System.Windows.Forms.Label labelZ2;
        private System.Windows.Forms.RichTextBox richTextBoxLocationInfo;
        private System.Windows.Forms.StatusStrip statusStrip5;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarLocation;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLocation;
        private System.Windows.Forms.Label labelZ1;
        private System.Windows.Forms.ToolStrip toolStripLocation;
        private System.Windows.Forms.ToolStripButton toolStripButtonPack;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator42;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator43;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxListModels;
        private System.Windows.Forms.ToolStripButton toolStripButtonDelete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator44;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator45;
        private System.Windows.Forms.ToolStripButton toolStripButtonLocalAnalysis;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator46;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator47;
        private System.Windows.Forms.ToolStripButton toolStripButtonLocalSettings;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator48;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator49;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxStep;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator51;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator50;
        private System.Windows.Forms.ToolStripButton toolStripButtonRGB1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator54;
        private System.Windows.Forms.ToolStripButton toolStripButtonRGB2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator52;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator53;
        public System.Windows.Forms.TabPage AnalVox;
        private System.Windows.Forms.TextBox textBoxDataHistogram;
        private System.Windows.Forms.TextBox textBoxSizeY2;
        private System.Windows.Forms.TextBox textBoxSizeX2;
        private System.Windows.Forms.TextBox textBoxSizeZ2;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripButtonStatAnal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxShowAnalysis;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowStatisticalDataX;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowStatisticalDataY;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowStatisticalDataZ;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowHistogramXYZ;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripButton toolStripButtonAbsolute;
        private System.Windows.Forms.ToolStripButton toolStripButtonRelative;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelX;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelZ;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelY;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelXYZRelative;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelXYZ;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelXRelation;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelZRelation;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartHistogramVoxelYRelation;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxMax;
        private System.Windows.Forms.TextBox textBoxInterval;
        private System.Windows.Forms.TextBox textBoxDispersion;
        private System.Windows.Forms.TextBox textBoxStandardDeviation;
        private System.Windows.Forms.TextBox textBoxAverage;
        private System.Windows.Forms.TextBox textBoxMean;
        private System.Windows.Forms.TextBox textBoxSkewness;
        private System.Windows.Forms.TextBox textBoxMedian;
        private System.Windows.Forms.TextBox textBoxMode;
        private System.Windows.Forms.TextBox textBoxCoefficientOfVariation;
        private System.Windows.Forms.TextBox textBoxCoefficientOfExcess;
        private System.Windows.Forms.TextBox textBoxMin;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxSizeIntervalsZ;
        private System.Windows.Forms.TextBox textBoxSizeIntervalsY;
        private System.Windows.Forms.TextBox textBoxSizeIntervalsX;
        private System.Windows.Forms.NumericUpDown numericUpDownNumIntZ;
        private System.Windows.Forms.NumericUpDown numericUpDownNumIntY;
        private System.Windows.Forms.NumericUpDown numericUpDownNumIntX;
        private System.Windows.Forms.CheckBox checkBoxNumInterval;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        public System.Windows.Forms.TabPage Vox_model;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxTotalVox;
        private System.Windows.Forms.TextBox textBoxSizeZ;
        private System.Windows.Forms.TextBox textBoxSizeY;
        private System.Windows.Forms.TextBox textBoxSizeX;
        private System.Windows.Forms.TextBox textBoxMaxZ;
        private System.Windows.Forms.TextBox textBoxMaxY;
        private System.Windows.Forms.TextBox textBoxMaxX;
        private System.Windows.Forms.TextBox textBoxMinY;
        private System.Windows.Forms.TextBox textBoxMinX;
        private System.Windows.Forms.TextBox textBoxMinZ;
        private System.Windows.Forms.RichTextBox richTextBoxInfo;
        private System.Windows.Forms.StatusStrip statusStrip_CreateVox;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarCreateVoxel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCreateVoxel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown numericUpDownVoxZ;
        private System.Windows.Forms.NumericUpDown numericUpDownVoxY;
        private System.Windows.Forms.NumericUpDown numericUpDownVoxX;
        private System.Windows.Forms.CheckBox checkBoxVox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Calculate_size;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButtonCreateVoxModel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStripButtonASC;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolStripButtonVerification;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveVoxModel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator41;
        private System.Windows.Forms.ToolStripButton toolStripButtonOpenVoxModel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator40;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxErrorZ;
        private System.Windows.Forms.TextBox textBoxErrorY;
        private System.Windows.Forms.TextBox textBoxErrorX;
        private System.Windows.Forms.TextBox textBoxTotalVoxRez;
        private System.Windows.Forms.TextBox textBoxVoxSizeZ;
        private System.Windows.Forms.TextBox textBoxVoxSizeY;
        private System.Windows.Forms.TextBox textBoxVoxSizeX;
        private System.Windows.Forms.TextBox textBoxVoxMaxZ;
        private System.Windows.Forms.TextBox textBoxVoxMaxY;
        private System.Windows.Forms.TextBox textBoxVoxMaxX;
        private System.Windows.Forms.TextBox textBoxVoxMinY;
        private System.Windows.Forms.TextBox textBoxVoxMinX;
        private System.Windows.Forms.TextBox textBoxVoxMinZ;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage ImportSTL;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBarCreateTable;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.TabPage OpenSTL;
        private System.Windows.Forms.RichTextBox richTextBox_review;
        private System.Windows.Forms.ToolStrip toolStrip_OpenSTL;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxFileName;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxVol;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem блокнотToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem magicsToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip_OpenSTL;
        public System.Windows.Forms.ToolStripProgressBar toolStripProgressBarOpenSTL;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_time_loud;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        public System.Windows.Forms.TabControl tabControlCreationVoxelModel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator62;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator37;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator35;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator36;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator63;
        private System.Windows.Forms.DataGridViewTextBoxColumn VariantOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnHeight;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reaserch1varRelS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reaserch2varRelS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reaserch3varRelS;
        private System.Windows.Forms.DataGridViewButtonColumn ReviewGistOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountIntOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinIntervalOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxIntervalOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn RangeOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn sOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn EOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn KaOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn KeOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn KvOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn MeanaOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModaOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn MedianaOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn XOrient;
        private System.Windows.Forms.DataGridViewTextBoxColumn YOrient;
        private System.Windows.Forms.DataGridViewButtonColumn Save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator38;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator64;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator65;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator66;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowHistogram3D;
        private System.Windows.Forms.Label labelCountContour;
        private System.Windows.Forms.CheckBox checkBoxAbsOrRel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator67;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator68;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator69;
        private System.Windows.Forms.NumericUpDown numericUpDownCurentFractalAnalysis;
        private System.Windows.Forms.NumericUpDown numericUpDownCountFractalAnalysis;
        private System.Windows.Forms.NumericUpDown numericUpDownRatioRtoL;
        private System.Windows.Forms.CheckBox checkBoxVisualAnalysis;
        private System.Windows.Forms.CheckBox checkBoxMethod;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxLimitF;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxError;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator70;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxTypeTrim;
        private System.Windows.Forms.CheckBox checkBoxFractalAnalysis;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxCountColumnForSave;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumLayer;
        private System.Windows.Forms.DataGridViewTextBoxColumn HeightLayer;
        private System.Windows.Forms.DataGridViewTextBoxColumn HeightPlaсement;
        private System.Windows.Forms.DataGridViewTextBoxColumn P;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ssection;
        private System.Windows.Forms.DataGridViewTextBoxColumn centroidOfArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn Delta;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fractal_Size_Scale;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fractal_Size_Square;
        private System.Windows.Forms.DataGridViewButtonColumn Nz;
        private System.Windows.Forms.DataGridViewButtonColumn Aadjacent;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzMinInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzMaxInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzRange;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzDispersion;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzSigma;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzMean;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzKasim;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzKeks;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzKv;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzMeana;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzModa;
        private System.Windows.Forms.DataGridViewTextBoxColumn NzMediana;
        private System.Windows.Forms.DataGridViewTextBoxColumn AMinInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn AMaxInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn ARange;
        private System.Windows.Forms.DataGridViewTextBoxColumn ADispersion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ASigma;
        private System.Windows.Forms.DataGridViewTextBoxColumn AMean;
        private System.Windows.Forms.DataGridViewTextBoxColumn AKasim;
        private System.Windows.Forms.DataGridViewTextBoxColumn AKeks;
        private System.Windows.Forms.DataGridViewTextBoxColumn AKv;
        private System.Windows.Forms.DataGridViewTextBoxColumn AMeana;
        private System.Windows.Forms.DataGridViewTextBoxColumn AModa;
        private System.Windows.Forms.DataGridViewTextBoxColumn AMediana;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMinInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMaxInterval;
        private System.Windows.Forms.DataGridViewTextBoxColumn ERange;
        private System.Windows.Forms.DataGridViewTextBoxColumn EDispersion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESigma;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMean;
        private System.Windows.Forms.DataGridViewTextBoxColumn EKasim;
        private System.Windows.Forms.DataGridViewTextBoxColumn EKeks;
        private System.Windows.Forms.DataGridViewTextBoxColumn EKv;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMeana;
        private System.Windows.Forms.DataGridViewTextBoxColumn EModa;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMediana;
        private System.Windows.Forms.CheckBox checkBoxAnalysisErrorForm;
    }
}

