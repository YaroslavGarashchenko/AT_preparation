﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PreAddTech
{
    /// <summary>
    /// Список методов определения фрактальной размерности {0 - клеточный, 1 - масштабов }
    /// </summary>
    public enum FractalMethod { cell, scale };

    /// <summary>
    /// Усечение гистограммы плотности распределения
    /// </summary>
    public enum TrimHistogram {no, leftTrim, rightTrim, allTrim };

    /// <summary>
    /// Внутренний/внешний контур
    /// </summary>
    enum Inout { inside, outer };
}
