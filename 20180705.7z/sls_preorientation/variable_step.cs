﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PreAddTech
{
    class VariableStep
    {
        //Метод 1 для определения набора слоев с переменным шагом построения
        public List<float> Method1(List<Base_stl> listSTL, float minZ, float maxZ, float resolution)
        {
            return new List<float>();
        }
    }
}
